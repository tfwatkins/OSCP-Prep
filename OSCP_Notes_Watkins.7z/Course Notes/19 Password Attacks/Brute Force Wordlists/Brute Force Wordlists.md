Brute force wordlist- Dictionary files containing every possible PW that matches a specific pattern

Ex.
`cat dumped.pass.txt`
david: Abc$#123
mike: Jud()666
Judy: Hol&&278

Pattern:
```
[Capital Letter] [2 x lower case letters] [2 x special chars] [3 x numeric]
```

**Crunch** is a pw wordlist generator.

Crunch Placeholders-

Placeholder Character: Translation
**@**: Lower case alpha characters
**,**: Upper case alpha characters
**%**: Numeric characters
**^**: Special characters including space

Generate the pw list to our specs, with a min/max of 8 chars:
`crunch 8 8 -t ,@@^^%%%`

We can also define char sets.

Ex.
Create a brute force wordlist for pw between 4 and 6 chars containing only 0-9 and A-F, output to crunch.txt
`crunch 4 6 0123456789ABCDEF -o crunch.txt`

We can also generate pw based on pre-defined char sets like those defined in **/usr/share/crunch/charset.lst** and choose **mixedalpha** to include upper and lowercase chars:
`crunch 4 6 -f /usr/share/crunch/charset.lst mixalpha -o crunch.txt`