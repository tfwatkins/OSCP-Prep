aka Dictionary files. 

Prioriteze specifity and precision.

**/usr/share/wordlists**

Many online also. 


Ex.
We are attacing a company that deals with nanotech. 
We identify a low level pw of *Nanobot93*

Create a custom wordlist that uses similar patterns and product names. 

We can manually brows or use **cewl** to scrape target website and create wordlists:
`cewl www.megacorpone.com -m 6 -w megacorp-cewl.txt`
**-m 6** Minimum of 6 chars
**-w** output file

We could write a bash script to create a pw list meeting our supposed requirements (word plus 2 numbers), or we could use **John The Ripper (JTR)**

Edit the **/etc/john/john.conf** config file and locate the *\[List.Rules:Wordlist]* sement where wordlist mutation rules are defined. Append a new rule: A two digit sequence zero to 99 after each word on the list:

`sudo nano /etc/john/john.conf`
```
...
# Wordlist mode rules
[List.Rules:Wordlist]
# Try words as they are
:
# Lowercase every pure alphanumeric word
-c >3 !?X l Q
# Capitalize every pure alphanumeric word
-c (?a >2 !?X c Q
# Lowercase and pluralize pure alphabetic words
...
# Try the second half of split passwords
-s x_
-s-c x_ M l Q
# Add two numbers to the end of each password
$[0-9]$[0-9]
...
```

Invoke John and mutate the word list:
`john --wordlist=megacorp-cewl.txt --rules --stdout > mutated.txt`


