Note: PW attacks against multiploe network services are noisy:
- Multiple failed login attempts generate logs and warnings
- Lockout policies may be in effect

Depending on protocol and cracking tool, we can increase num of logni threads to boost attack speed. RDP and SMB generally have restrictions on speed and this would instead slow down the process..

Balance risk vs reward. RDP is slower than HTTP, but a successful RDP attack is higher yield generally. 

We must match uname and PW, but also "honor" the protocol authentication process. 

Tools:
- THC-Hydra
- Medusa
- Crowbar
- spray

All have similar speeds and capabilities, but may be more effective against different protocols and services.