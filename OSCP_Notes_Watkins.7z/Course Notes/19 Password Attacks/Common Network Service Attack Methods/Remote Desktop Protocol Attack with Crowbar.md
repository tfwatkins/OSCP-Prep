Formally known as Levye designed to leverage SSH keys rather than PWs. 

One of the few tools taht can relieable handle RDP on modern Windows versions. 

Invoke crowbar:
`crowbar -b rdp -s 10.11.0.22/32 -u admin -C ~/password-file.txt -n 1`
**-b** protocol
**-s** Target server
**-u** username
**-C** wordlist
**-n** number of threads