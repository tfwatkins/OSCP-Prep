Dictionary- Using wordlist. Faster, less coverage. 
Bruteforce- Slower, more pw coverage

Once we gain (priveleged) access and extract pw hashes, we can:
- Crack hashes for clear-text pws
- Pass-The-Hash attack in Windows using only uname and hash