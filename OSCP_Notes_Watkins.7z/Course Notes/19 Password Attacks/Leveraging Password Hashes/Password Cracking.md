If salt is involved in authentication, password cracking can by impossible. 

However, experience shows that it is usually possible to capture the hash along with the salt, whether from a DB that contains both or from a config or binary that uses a single salt for all hashes values. When both hash and salt are known, cracking decreases dramatically in complexitiy. 

Running **john** in brute force mode, passing a file containing our hashes:
`sudo john hash.txt --format=NT`

Providing a wordlist to John:
`john --wordlist=/usr/share/wordlists/rockyou.txt hash.txt --format=NT`

Appliying JTRs word mangling rules:
`john --rules --wordlist=/usr/share/wordlists/rockyou.txt hash.txt --
format=NT`


Cracking Linux-based PW with JTR using **unshadow** to combing **passwd** and **shadow** files:
`unshadow passwd-file.txt shadow-file.txt`
`unshadow passwd-file.txt shadow-file.txt > unshadowed.txt`
`john --rules --wordlist=/usr/share/wordlists/rockyou.txt unshadowed.txt`

Newer version of JTR are multi-threaded by default, but older versions use a single CPU core. There are alternatives to speed up the process:
**--fork** uses multiple processes to make use of more CPU cores
**--node** Splits the work across multiple machines

Ex. Two machines each with an 8-core CPU
Machine one: **--fork=8** and **-node=1-8/16**
Splits the wordlist into 16 parts and process the first 8 locally
Machine two: **--fork=8** and **--node=9-16**


***
Attackers can precompute hashes for passwords and store them in a Rainbow Table. Enormously space intensive but very fast.
***

Note that JtR is limited by CPU speed. 

Hashcat on the other hand can utilize both CPU and GPU processing power and crack very quickly. It's options generally mirror JtR's.