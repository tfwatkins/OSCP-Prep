Pass-the-Hash (PtH) allows remote target authentication by using valud username:NTLM/LM hash rather than a clear text pw. 

This is possilbe due ot the fact that NTLM/LM hashes are NOT salted and remain static between sessions. This allows authentication on multiple targets once we discover a credential combo. 

What you are looking for:
- A local admin account enabled on multiple systems.

We exploita  vuln on one system and gain SYSTEM privs, dump local LM and NTLM hashes. 

**pth-winexe** is a PtH toolkit (modified version of winexe) which authenticates via SMB.

***
Note that to execute a command like cmd on a remote PC via SMB, admin privs are required. Due to authentication to admin share C$ and the subsequent creation of a windows service.
***

Invoke **pth-winexe** and authenticate to our target with previously dumped hash:
`pth-winexe -U
offsec%aad3b435b51404eeaad3b435b51404ee:2892d26cdf84d7a70e2eb3b9f05c425e //10.11.0.22
cmd`
**-U** Specify username and hash along with SMB share in UNC (in UNC format)
**cmd** Command to execute

Behind the scenes, the format of the NTLM hash was changed into a NetNTLM v1 or v2 during authentication. We can capture these using MiTM or poisoning and either crack or relay them. 

Some apps like IE or Windows Defender use WPAD (Web Proxy Auto-Discovery) to detect proxy settings. 

If we are on the local network, we can poison request and force NetNTLM authentication with a tool like **Responder.py** which creates a rogue WPAD server. 

***
Don't do this in the labs, highly disruptive to other students!
***