Cryptographic hash functino is a one-way function implementing an algorithm that given a block of data returns a fixed-size bit string called a "hash value" or "message digest". 

Most systems that use PW auth store then locally on the matchine. Most are stored as hashes. 

During auth, PW given by user are hashed and compared to stored message digest. 

Identifying type of hash withouth furthem info on program or mechanism may be impossible. The **Openwall** website may help id the source. 

Considerations:
- length of hash
- char set
- special chars

**hashid** is a tool that can help id hashes:
`hashid c43ee559d69bc7f691fe2fbfe8a5ef0a`

Analyze hash from **/etc/shadow**
`sudo grep root /etc/shadow`
```
root:$6$Rw99zZ2B$AZwfboPWM6z2tiBeK.EL74sivucCa8YhCrXGCBoVdeYUGsf8iwNxJkr.wTLDjI5poygaU
cLaWtP/gewQkO7jT/:17564:0:99999:7:::
```
**$6** references a SHA-512 algorithm
Next subfield is **salt**- Used with cleartext pw to generate a hash. Salt is a random value designed to decrease the usefulness of hash-lookup tables. 

### windows
Hashed user pw stored in SAM. SYSKEY (windows NT 4.0 SP3) partiall encrypts SAM to deter offline db pw attacks. 

Windows NT-based OS up to and including Windows 2003 store two different pw hashes:
LAN  Manager (LM)- Based on DES
NT LAN Manager (NTLM)- MD4

LM is very weak- No longer than 7 chars split into two strings, each hashed seperately. Converted to upper-case before being hashed. No salts, so lookups feasible. 

For Vista on, LM is disabled and uses NTLM: Case sensitive, supports all unicde chars, does not split hashes

Note that NTLM hashes stored in SAM are still not salted. 

SAM cannot be copied until OS os running due to WIndows Kernel keeping an exclusive file system lock on the file. 

Mimkats can mount in-memory attacks to dump SAM.

Mimikatz facilitates password hash extraction from LSASS process memory where they are cached.

LSASS is a priv process running under SYSTEM, so we need to launch Mimikatz from admin command prompt. Execute two commands:

`privilege::debug`  Enables SeDebugPrivilge access right required to tamper with another process. If this fails, mimikatz was most likely not executed under admin privs. 
`token::elevate `  Elevate security token from high-integrity (admin) to SYSTEM. If mimikatz launched from a SYSTEM shell, not required.

We can then dump the contents of the SAM:
`lsadump::sam`


***
Other hash dumping tools, including pwdump, fgdump,577 and Windows
Credential Editor (wce)578 work well against older Windows operating systems
like Windows XP and Windows Server 2003.
***