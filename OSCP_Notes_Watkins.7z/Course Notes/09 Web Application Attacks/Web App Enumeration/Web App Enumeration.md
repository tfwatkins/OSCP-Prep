Attempt to discover technologly "stack":
- Programming language and frameworks
- Web Server Software
- Database Software
- Server OS

# Inspecting URLs
File extensions (sometimes part of a url) can reveal the language it's written in. 
Ex.
**.php** is straightforward
**.jsp, .do, .htlm** can all be Javascript.. less straightforward

Less common today since *routes* allow devs to map a URI to a section of code, and logically determine what content is returned, making URI extensions irrelevant. 

# Inspecting Page Content
*Firefox Debugger tool*- Found in Web Developer menu or with `ctrl + shift + k`
Displays resources and content. May display:
Javascript Frameworks, hidden input fields, comments, client-side controls wthin html, Javascript, etc. 

If code is "minified", can expand with the *Pretty Print Source* doulbe brackets button. 
*Inspector* can drill down into specific page content. 

Can right click elements of a page (like an email field) and *inspect* them to pull up that portion of the web page code. This is helpful for finding hidden form fields in HTML source. 

# Viewing Response Headers
We can use two types of tools to search server responses: 
Proxy- Intercepts requests and responses between client and webserver
Network Tool-  from the Web Dev menu (page must be reloaded to get traffic)

Headers that start with "X-" are non-standard HTTP headers. Often include info on the app stack. 
Ex. "x-amz-cf-id" header indicates Amazon CloudFront.

# Inspecting Sitemaps
Sitemaps allow search engine bots to crawl and index their sites. Files also include directoves on which URLs NOT to crawl... which are usually sensitive pages or admin consoles. 

Two most common:
- **robots.txt**
- **sitemap.xml**

We can retrieve sitemaps with curl:
`curl https://www.google.com/robots.txt`

```
User-agent: *
Disallow: /search
Allow: /search/about
Allow: /search/static
Allow: /search/howsearchworks
Disallow: /sdch
Disallow: /groups
Disallow: /index.html?
Disallow: /?
Allow: /?hl=
...
```

# Locating Administrative Consoles
Generally accessible via a particular URL and often listening on a TCP port. 

Two common examples:
- *manager* for *Tomcat* hosted at **/manager/html**
- *phpMyAdmin* for MySQL hosted at **/phpmyadmin**

Can be restricted to local access or hosted on custom TCP ports, but usually have default configurations. Application Server Software documentation can reveal these locations. 