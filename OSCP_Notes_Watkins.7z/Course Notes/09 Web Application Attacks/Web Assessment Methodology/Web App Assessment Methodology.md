What does the app do?
What language is it written in?
What server software is the app running on?

Increase permissions within app
Pivot to another app or target