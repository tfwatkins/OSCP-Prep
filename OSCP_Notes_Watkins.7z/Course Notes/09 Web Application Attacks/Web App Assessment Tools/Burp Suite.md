# Burp Suite
GUI collection of tools for web app testing and a powerful proxy tool. Community edition contains manual testing tools, commercial edition has additional features such as a web app vuln scanner. 

**Burp Commercial is FORBIDDEN on the OSCP exam, and not neccessary.**

`burpsuite` Launch burp.

Temporary Project -> Next

## Proxy

Can intercept any request sent from the browser before it's passed on to the server. 
We can change almost any value.

Note: Disable **intercept**, as it requires you to manually forward each request to it's desintation. Alternatively, click **Drop** to **not** send the request. 

Default interface is 127.0.0.1:8080 for the Burp proxy listener.

You can toggle intercept to run on startup:
User options > misc. > proxy interception

### FoxyProxy

We can use FoxyProxy as a simple way to send data through Burp.

Setup a new proxy.
Type: HTTP
Name: Burp
Address: 127.0.0.1
Port: 8080

With the proxy enabled, go Proxy->Http History
Then browse to any website in firefox. 

**If the browser hangs, Intercept is probably enabled.**

### Removing captive portal
detectportal.firefox.com will show up in proxy history unless you take steps to remove it. It's a *captive portal* that is essentially a firefox gateway. 
Search:
**about::config** click to accpet risk
**network.captive-portal-service.enabled** and change value to false
***

### HTTPS
We will only be able to view HTTP traffic. Browsing to HTTPS traffic will generate an invalid cert warning. 

We can easily have burp generate it's own SSL/TLS cert, essentially MiTM ourselves to capture the traffic:

Proxy->options > proxy listeners > Regenrerate CA cert
Click yes and restart burp
TO import new cert: http://burp
Find and save the **cacert.der** file to local machine
Drop the file into firefox and click *Trust to Id Websites* and ok.
Browse to HTTPS and it should load without a warning and with traffic in burps HTTP history tab.

### Repeater
We can modify, request, resend them and review responses. 
Right click a request in HTTP History and Send to Repeater (ctrl+r)
