Open source vuln scanner. 

Not designed for stealth and will send many request and embed information into the User-Agent header. 

Nikto can scan multiple servers, ports and pages. Heavy scans on commercial sites can take **hours**. 

Two options to control scan duration:
**-maxtime** option which will cutoff the scan at the specified time
**-T** Tuning, which is for controlling the type of tests we wan tto run. 

Nikto is very good at catching low-hanging fruit, reporting non-standard server headers and catching configuration errors. 

Lets scan:

`nikto -host=http://megacorpone.com -maxtime=30s`