
# DIRB
Web content scanner that uses a wordlist to find directories and pages by issuing request to the server. Can ID valid web pages even if the main index page is missing. 

Defaults to "interesting" directories but can be setup to search for specific directories, use custom dicts or set custom cookie or header on each request, etc. 

`dirb http://megacorpone.com -r -z 10` Standard dirb command
**-r** scan non-recursively
**-z 10** add 10 ms delay to each request

We generally start with a non-recursive search to get an idea of the layout (especially against large targets) and then recursively search into interesting directories. Smaller targets can just be r-searched from the jump.

**DirBuster** is a Java app similar to DIRB but offers multi-threading and a GUI-Based interface. 