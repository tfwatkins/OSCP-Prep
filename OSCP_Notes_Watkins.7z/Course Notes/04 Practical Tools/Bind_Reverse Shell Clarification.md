***
**reverse shell is something you send**
**bind shell is something you setup**
***
"Send a reverse shell from your Windows machine to your Kali machine"
- that means Kali is executing commands on Windows and Kali has the listening socket


"Setup a bind shell on your Windows machine and access it from your Kali machine" 
- that means Kali is executing commands on Windows and Windows has the listening socket

  