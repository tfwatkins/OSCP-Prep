Commonly used command-line packet analyzer. Can capture and read existing pcaps.
***
 **Local user permissions determine ability to capture network traffic.**
***

`sudo tcpdump -r password_cracking_filtered.pcap`
Open a pcap to read, with sudo permissions

https://www.offensive-security.com/pwk-online/password_cracking_filtered.pcap

`sudo tcpdump -n -r password_cracking_filtered.pcap | awk -F" " '{print $3 " > " $5} ' | sort | uniq -c | head
` Filter the pcap to see the 1st and 3rd fields (source and dest IP, seperated by a >)
**-n** skip dns name lookups
**sort** sort results
**uniq -c** display unique results
**head** top 10 results

`sudo tcpdump -n src host 172.16.40.10 -r https://www.offensive-security.com/pwk-online/password_cracking_filtered.pcap` Display a specific source host

`sudo tcpdump -n dst host 172.16.40.10 or src host 172.16.40.10 -r password_cracking_filtered.pcap` Display a specific dst host or src host

`sudo tcpdump -n port 81 -r password_cracking_filtered.pcap` specify a port

`sudo tcpdump -nX -r password_cracking_filtered.pcap` Display in both hex and ascii format

## Advanced Header Filtering

Lets assume that the ACK and PSH flags are turned on, as the fourth and fifth bit of the 14th byte of a TCP header:

CEUAPRSF
WCRCSSYI
REGKHTNN
00011000 = 24 in decimal

`echo "$((2#00011000))"` Outputs binary bits to decimal (24).

This can be represended in tcpdump as:
**tcp[13] = 24** The 14th byte is the 13th index.

`sudo tcpdump -A -n 'tcp[13] = 24' -r password_cracking_filtered.pcap` Filter for only HTTP request and responses with the ACK or PSH flags set.
**-A** print in ascii
