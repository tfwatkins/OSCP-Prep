## For Loops

```
for var-name in <list>
do
	<action>
done
```

`for ip in $(seq 1 10); do echo 10.11.1.$ip; done` Print first 10 IPs addresses of the subnet

`for i in {1..10}; do echo 10.11.1.$i;done` Using *brace expansion* aka a *sequence extension*. 

## While Loops

```
while [ <some test> ]
do
<perform an action>
done
```

Ex.
```
#!/bin/bash
# while loop example
counter=1
while [ $counter -le 10 ]
do
	echo "10.11.1.$counter"
	((counter++))
done
```


Double parenthesis performs arithmetic and evaluation at same time.