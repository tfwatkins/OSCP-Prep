Situation: Running portscans on a network, focusing on Port 80

`sudo nmap -A -p80 --open 10.11.1.0/24 -oG nmap-scan_10.11.1.1-254` 
**-A** Agressive scanning
**-p** specify port or range
**--open** return open ports only
**-oG** save results in a grepable format

```
Starting Nmap 7.60 ( https://nmap.org ) at 2019-03-18 18:57 EDT
Nmap scan report for 10.11.1.8
Host is up (0.030s latency).
PORT STATE SERVICE VERSION
80/tcp open http Apache httpd 2.0.52 ((CentOS))
| http-methods:
|_ Potentially risky methods: TRACE
| http-robots.txt: 2 disallowed entries
|_/internal/ /tmp/
|_http-server-header: Apache/2.0.52 (CentOS)
|_http-title: Site doesn't have a title (text/html; charset=UTF-8).
MAC Address: 00:50:56:89:20:34 (VMware)
Warning: OSScan results may be unreliable because we could not find at least 1 open an
Device type: general purpose|WAP|firewall|proxy server|PBX
Running (JUST GUESSING): Linux 2.6.X (92%), ZoneAlarm embedded (90%), Cisco embedded
Aggressive OS guesses: Linux 2.6.18 (92%), Linux 2.6.9 (92%), Linux 2.6.9 - 2.6.27 (90

No exact OS matches for host (test conditions non-ideal).
Network Distance: 1 hop

TRACEROUTE
HOP RTT ADDRESS
1 30.19 ms 10.11.1.8
Nmap scan report for 10.11.1.10
Host is up (0.030s latency).

PORT STATE SERVICE VERSION
80/tcp open http Microsoft IIS httpd 6.0
| http-methods:
|_ Potentially risky methods: TRACE
|_http-server-header: Microsoft-IIS/6.0
|_http-title: Under Construction
MAC Address: 00:50:56:89:06:D0 (VMware)
Warning: OSScan results may be unreliable because we could not find at least 1 open an
Device type: general purpose|WAP
Running (JUST GUESSING): Microsoft Windows 2003|XP|2000 (89%), Apple embedded (86%)
OS CPE: cpe:/o:microsoft:windows_server_2003::sp2 cpe:/o:microsoft:windows_xp::sp3 cpe
No exact OS matches for host (test conditions non-ideal).
Network Distance: 1 hop
Service Info: OS: Windows; CPE: cpe:/o:microsoft:windows
TRACEROUTE
HOP RTT ADDRESS
1 30.41 ms 10.11.1.10
```

Clean it up:
`cat nmap-scan_10.11.1.1-254 | grep 80 | grep -v "Nmap" | awk '{print
$2}'`
Focus on port 80, reverse grep out the Nmap, and only print the IPs with awk

```
10.11.1.8
10.11.1.10
10.11.1.13
10.11.1.14
10.11.1.22
10.11.1.24
10.11.1.31
10.11.1.39
10.11.1.49
10.11.1.50
10.11.1.71
...
```

Next, we will use **cutycap**, a Qt Webkit web page rendering capture utility. **-url** specifies the target site and **-out** specifies output file:

`for ip in $(cat nmap-scan_10.11.1.1-254 | grep 80 | grep -v "Nmap" |
awk '{print $2}'); do cutycapt --url=$ip --out=$ip.png;done`

```
kali@kali:~/temp$ ls -1 *.png
10.11.1.10.png
10.11.1.115.png
10.11.1.116.png
10.11.1.128.png
10.11.1.13.png
10.11.1.133.png
10.11.1.14.png
10.11.1.202.png
10.11.1.209.png
10.11.1.217.png
...
```
Results of the above one liner

We can put these images into a quick HTML file using this script:
```
#!/bin/bash
# Bash script to examine the scan results through HTML.
echo "<HTML><BODY><BR>" > web.html
ls -1 *.png | awk -F : '{ print $1":\n<BR><IMG SRC=\""$1""$2"\" width=600><BR>"}' >>
web.html
echo "</BODY></HTML>" >> web.html

```


