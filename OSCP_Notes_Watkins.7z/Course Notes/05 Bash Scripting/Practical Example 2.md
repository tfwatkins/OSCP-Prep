Scenario:
In the middle of a pentest we realize the Windows machine may be vulnerabe to an exploit, but we can't remember the full name. It begins with the letter a, f or d.

We could manually google search exploit-db but we can also automate this task in searchsploit:

`searchsploit afd windows -w -t`
```
--------------------------------------------------------------------------------------
Exploit Title | URL
--------------------------------------------------------------------------------------
Microsoft Windows (x86) - 'afd.sys' Privil | https://www.exploit-db.com/exploits/40564
Microsoft Windows - 'AfdJoinLeaf' Privileg | https://www.exploit-db.com/exploits/21844
Microsoft Windows - 'afd.sys' Local Kernel | https://www.exploit-db.com/exploits/18755
Microsoft Windows 7 (x64) - 'afd.sys' Dang | https://www.exploit-db.com/exploits/39525
Microsoft Windows 7 (x86) - 'afd.sys' Dang | https://www.exploit-db.com/exploits/39446
Microsoft Windows 7 Kernel - Pool-Based Ou | https://www.exploit-db.com/exploits/42009
Microsoft Windows XP - 'afd.sys' Local Ker | https://www.exploit-db.com/exploits/17133
Microsoft Windows XP/2003 - 'afd.sys' Priv | https://www.exploit-db.com/exploits/6757
Microsoft Windows XP/2003 - 'afd.sys' Priv | https://www.exploit-db.com/exploits/18176
--------------------------------------------------------------------------------------
```

Let's trim the results:
`searchsploit afd windows -w -t | grep http | cut -f 2 -d "|"`
```
https://www.exploit-db.com/exploits/40564
https://www.exploit-db.com/exploits/21844
https://www.exploit-db.com/exploits/18755
https://www.exploit-db.com/exploits/39525
https://www.exploit-db.com/exploits/39446
https://www.exploit-db.com/exploits/42009
https://www.exploit-db.com/exploits/17133
https://www.exploit-db.com/exploits/18176
https://www.exploit-db.com/exploits/6757
```

We could just download all the files, but what we are really after is the "raw" code. Looking at the page we see they are fommatted like so:
*/raw/40564* for example.

`for e in $(searchsploit afd windows -w -t | grep http | cut -f 2 -d "|");
do exp_name=$(echo $e | cut -d "/" -f 5) && url=$(echo $e | sed 's/exploits/raw/') &&
wget -q --no-check-certificate $url -O $exp_name; done`

For loop interates through the urls we grabbed. Inside the loop, *exp_name* is set to each name of each exploit, the url is set with sed we wget to locally save each exploit with it's own name.


We can easily turn this into a bash script for later use:
```
#!/bin/bash
# Bash script to search for a given exploit and download all matches.
for e in $(searchsploit afd windows -w -t | grep http | cut -f 2 -d "|")
do
exp_name=$(echo $e | cut -d "/" -f 5)
url=$(echo $e | sed 's/exploits/raw/')
wget -q --no-check-certificate $url -O $exp_name
done
```