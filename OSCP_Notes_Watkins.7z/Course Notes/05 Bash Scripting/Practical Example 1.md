## Find all subdomains and corresponding IPs

`wget www.megacorpone.com`

```
URL transformed to HTTPS due to an HSTS policy
--2018-03-18 17:56:53-- http://www.megacorpone.com/
Resolving www.megacorpone.com (www.megacorpone.com)... 38.100.193.76
Connecting to www.megacorpone.com (www.megacorpone.com)|38.100.193.76|:80... connected
HTTP request sent, awaiting response... 200 OK

Length: 12520 (12K) [text/html]
Saving to: ‘index.html’

index.html 100%[===================>] 12.23K --.-KB/s in 0s
2018-03-18 17:56:54 (2.56 MB/s) - ‘index.html’ saved [12520/12520]
kali@kali:~$ ls -l index.html
-rw-r--r-- 1 kali kali 12520 Mar 18 17:56 index.html
```

Narrow in on lines we need and lose ones we done

`grep "href" index.html` Extract all lines containing HTML links

`grep "href=" index.html | grep "\.megacorpone" | grep -v`

```
"www\.megacorpone\.com" | head
...
<li><a
href="http://support.megacorpone.com/ticket/requests/index.html">Nanoprocessors</a></l
i>
<li><a
href="http://syslog.megacorpone.com/logs/sys/view.php">Perlin VanHook Chemical
Dispersal</a></li>
<li><a href="http://test.megacorpone.com/demo/index.php">What are
the ethics behind MegaCorp One?</a></li>
...
```
Utilize grep to grab lines indicating existence of a subdomain and **-v** to strip lines containing the megacorpone.com domain we already knew about.

`grep "href=" index.html | grep "\.megacorpone" | grep -v`

```
"www\.megacorpone\.com" | awk -F "http://" '{print $2}'
admin.megacorpone.com/admin/index.html">Cell Regeneration</a></li>
intranet.megacorpone.com/pear/">Immune Systems Supplements</a></li>
mail.megacorpone.com/menu/">Micromachine Cyberisation Repair</a></li>
mail2.megacorpone.com/smtp/relay/">Nanomite Based Weaponry Systems</a></li>
siem.megacorpone.com/home/">Nanoprobe Based Entity Assimilation</a></li>
support.megacorpone.com/ticket/requests/index.html">Nanoprocessors</a></li>
...
```
Utilize awk to get rid of extra HTML around our links

`grep "href=" index.html | grep "\.megacorpone" | grep -v`
```
"www\.megacorpone\.com" | awk -F "http://" '{print $2}' | cut -d "/" -f 1
admin.megacorpone.com
intranet.megacorpone.com
mail.megacorpone.com
mail2.megacorpone.com
siem.megacorpone.com
support.megacorpone.com
...
```
Utilize cut to leave us with the full domain names

`grep -o '[^/]*\.megacorpone\.com' index.html | sort -u > list.txt`

```
kali@kali:~$ cat list.txt
admin.megacorpone.com
beta.megacorpone.com
intranet.megacorpone.com
mail2.megacorpone.com
mail.megacorpone.com
siem.megacorpone.com
support.megacorpone.com
...
```
A regex oneline that will carve out the megacorpone.com subdomains.
` [^/]\*` Negated set that searches for any number of chars not including a forward slash.  

Don't forget to escape the period!

### Discover IPs with host
`for url in $(cat list.txt); do host $url; done`
```
admin.megacorpone.com has address 38.100.193.83
beta.megacorpone.com has address 38.100.193.88
...
```

`for url in $(cat list.txt); do host $url; done | grep "has address" | cut
-d " " -f 4 | sort -u`
```
173.246.47.170
38.100.193.66
38.100.193.67
38.100.193.73
38.100.193.76
38.100.193.77
38.100.193.79
38.100.193.83
38.100.193.84
38.100.193.87
38.100.193.88
38.100.193.89
```
Use grep, cut and sort to carve out only the IPs and order them

