```
function function_name {
commands ...
}
```

alternatively
```
function () {
commands...
}
```

## Return values:
Functions by default return an exit status:
0 for success
non-zero for failure

You can simulate a traditional return by setting a global variable inside the function and accessing it with: **$?**

ex. 
```
return_me() {
	echo "Hello!"
	return $RANDOM
}

echo "The previous function returned: $?"
```

Using a return statement without the $RANDOM argument would return an exit status

##Variable Scope

You can give a global variable local scope by preceding it with *local*

ex.
```
#!/bin/bash
# var scope example

name2 is $name2"
name2="Lucas"

name_change() {
	local name1="Edward"

	echo "Inside of this function, name1 is $name1 and 
}
echo "Before the function call, name1 is $name1 and name2 is $name2"
name_change
echo "After the function call, name1 is $name1 and name2 is $name2"
```