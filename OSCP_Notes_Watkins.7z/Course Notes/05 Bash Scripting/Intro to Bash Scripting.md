Bash scripts have extension **.sh** and begin with **#!/bin/bash**. 
They must have executable permissions set to be run.

Example Script: **hello_world.sh**
```
#!/bin/bash
# Hello World Bash Script
echo "Hello world!"
```

**#!/bin/bash**- Sets the absolute path to the interpeter, used to run script. 
**#** Indicates a comment
`chmod +x hello_world.sh`
`./hello_world.sh`