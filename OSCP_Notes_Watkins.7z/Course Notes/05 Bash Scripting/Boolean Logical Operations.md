**&&** AND
 **||**  OR
 
 Can be put inbetween commands, so the 2nd only exeuctes if the first returns true:
 
 `grep $user2 /etc/passwd && echo "$user2 found!"`
 
 ## Combining with decision logic
 
 
 ```
 if [ $USER == 'kali' ] && [ $HOSTNAME == 'kali' ]
then
echo "Multiple statements are true!"
else
echo "Not much to see here..."
fi
 ```
 