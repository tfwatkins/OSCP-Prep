`first_name=Good` Declares a simple variable with a name=value configuration

`echo $first_name` use the variable

Variables must be connected with: **_**  o r **" "** or **' '**

Single quotes- Treat every character literally
Double quotes- Treat MOST characters literally except: "$", "\`" and "\\", which will be substituted and expanded.

You can also set a variable name to a command:
`user=$(whoami)` Command Substitution
Alternatively use backticks:
```user=`whoami`	```

***
Note that command substitution happens in a subshell, and changes to variables in the subshell will not alter variables in the master process
***

**using the -x modifier for additional debug output:**
#!bin/bash -x 
Command Executed in a subshell will be denoted with with a "++", whereas command executed in the current shell will have a "+".

## Arguments

**Special Bash Variables:**
***
Variable Name   Description
\$0 						The name of the Bash script
\$1 - $9 			  The first 9 arguments to the Bash script
\$# 						Number of arguments passed to the Bash script
\$@ 					  All arguments passed to the Bash script
\$? 					   The exit status of the most recently run process
\$\$ 					   The process ID of the current script
\$USER 			  The username of the user running the script
\$HOSTNAME 	The hostname of the machine
\$RANDOM 	   A random number
\$LINENO 		 The current line number in the script
***

## Reading User Input

**read** Command used in a script to read userinput and assign it to a variable

```
echo "Enter a number"

read answer

echo "Your number was $answer"
```

**-p** Specify a prompt
**-s** Make user input silent (good for capturing creds)
**-sp** Silent user input with a prompt