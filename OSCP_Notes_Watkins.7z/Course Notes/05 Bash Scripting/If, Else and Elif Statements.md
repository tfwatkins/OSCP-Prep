## General Structure
```
if [ <some condition> ]
then
	<perform action>
fi
```

example:

```
#!/bin/bash
# if statement example
read -p "What is your age: " age
if [ $age -lt 16 ]
then
echo "You might need parental permission to take this course!"
fi
```

**-lt** less than

## Operators
![9c8d05dc7acf2c7cac67fd7991889579.png](../../../../_resources/9c8d05dc7acf2c7cac67fd7991889579.png)

## If, then

```
if [ <some test> ]
then
<perform action>
else
<perform another action>
fi
```

## If, then, else
```
if [ <some test> ]
then
<perform action>
elif [ <some test> ]
then
<perform different action>
else
<perform yet another different action>
fi
```