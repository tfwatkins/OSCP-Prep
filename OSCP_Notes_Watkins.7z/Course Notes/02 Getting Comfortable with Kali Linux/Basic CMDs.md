`passwd <user>` Change user password
`whoami` Display current user
`man -k passwd` Keyword search
`man -k '^passwd?'` Regex to match entire line and avoid substring matches
`man 5 passwd` Goto a specific page of a man
`apropos <string>` Serach man pages for a keyword description (Equivalent to man -k)
`mkdir -p` Make file with required parent directories
`rm -rf` Remove file recursively
`which <file>` Searches through directories defined in $PATH for a given file name. Returns full path.
`locate <filename>` Searches a built-in DB named **locate.db** rather than the hard disk itself. Regularly updated by cron.
`updatedb` Manually updates **locate.db**
`find / -name sbd*` Recursively search root file system directory to look for any file that starts with letters "sbd"
- Main advantage of **find** over **locate** is that it can serach for files and directories by age, size, owner, file type, timestamp, permissions and more.


	



