## apt update and upgrade
`apt update` Update the local apt cache
`apt upgrade` Upgrade installed packages and core system to latest versions
`apt upgrade metasploit framework` Upgrade a specifi package
***
It's best practice to snapshot your machine before upgrading your kali installation
***

## apt-cache search and apt show
`apt-cache search pure-ftpd` Search local repos for pure-ftpd application
`apt show resource-agents` Examine information related to the resource-agents package

## apt install
`apt install pure-ftpd` Install application
`apt remove --purge pure-ftpd` Completed remove package, also removing config files left behind by apt remove alone. 

## dpkg
`dpkg -i <filename>` Core tool to install a package. Preferred when operating offline. Does not install any dependencies. 