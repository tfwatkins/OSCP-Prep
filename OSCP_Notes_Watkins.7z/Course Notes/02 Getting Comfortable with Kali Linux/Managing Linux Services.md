Kali prevents many standard network services from loading at boot time to avoid open ports be default. As well as providing for black and whitelisting services.
***
## SSH Service
TCP based and listens on port 22.

`systemctl` Used to enable/disable most services in Kali
`systemctl start ssh` Start the ssh service
`ss -antlp | grep sshd` Verify SSH service is running and listening on port TCP 22
`systemctl enable ssh` Configure SSH to start at boot time

## HTTP Service
Apache HTTP is TCP based on port 80
`systemctl start apache2` Start apache service
`ss -antlp | grep apache` Verify apache is running
`systemctl enable apache2` Start apache at runtime

* `systemctl list-unit-files` Use to see a table of all available services





