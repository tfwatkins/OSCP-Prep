We can use process of elimination to determine which chars a bad. In this case:

\x00 and \x20

