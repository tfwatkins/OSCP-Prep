Recent Linux kernels and compilers have implemented various memory protection techniques. 

Our test version of Crossfire has been compiled without "stack-smashing" protection. 