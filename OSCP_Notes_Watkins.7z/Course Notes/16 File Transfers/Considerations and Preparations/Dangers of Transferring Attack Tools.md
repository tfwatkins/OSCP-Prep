Transferring tools can be dangerous:
- Tools can be abused by malicious 3rd parties
	- MUST document and remove tools
- AV software can/will scan, detect and quarantine tools and alert sys admins.
	- This can cost you a shell or even end the engagement
- In general, use native tools aka LotL