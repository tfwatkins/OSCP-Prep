In previous sections, we located High-value targets and found workstations/servers they are logged into. We gathered PW hashes, recovered existing tickets and leveraged them for Kerberos auth.

We want to use Lat Mvmt to compromise machines our HV targets are logged in to. 

We could crack PW hashes to authenticated to a machine with cleartext pws in order to gain access, however PW cracking takes time and may fail. Additionally, Kerberos and NTLM don't use cleartext PWs directly and native Microsoft tools don't support auth via a PW hash. 

We will explore alternative lat mvmt techs allowin us to auth to a system and gain code execution using only the user's hash or a Kerberos ticket. 