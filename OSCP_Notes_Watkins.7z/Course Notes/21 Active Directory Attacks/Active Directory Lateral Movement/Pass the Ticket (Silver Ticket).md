Previously we used the Overpass The Hash tech (with a captured NTLM hash) to aquire a Kerb TGT, allowing us to auth to Kerberos. 

We can ONLY use the TGT on the machine it was created for, but the TGS offers more flexibility. 

Pass The Ticket takes advantage of TGS which may be exported and re-injected elsewhere on teh network and then used to auth to a specific servcie. 

Additionally, if the ST belongs to the current user, then no admin privs are required. 

This attack does not provide us with any additional access, but does offer flexbility in choosing which machine to use the ticket from. However, if a service is registered with an SPN, scenario becomes more interesting. 

Previously, we demonstrated that we could crack the service account PW hash and obtain the PW from the ST. This PW could then be used to access resources available to the service account.                                                     

However, if the service account is not a local admin on any servers, we would not be able to perform lat mvmt using vectors such as PtH or OPtH and therefor, we need a different approach. 

***
As with Pass the Hash, Overpass the Hash also requires access to the special
admin share called Admin$, which in turn requires local administrative rights on
the target machine.
***

Referencing Kerb auth: 
The app on the server executing in teh context of the service account checks user's perms from teh group membership included in teh service ticket. The user and group perms in the service ticket are not verified by the app though. The app blindly trusts the integrity of the service ticket since it's encrypted with a PW hash (in theory) only known to the service account and the DC. 

Ex.
If we auth against an IIS server that is executing in teh context of the service account *iis_service*, the IIS app will determine which perms we have on the IIS server depending on the group membership preseng in the ST.

However, with the service account pw or it's NTLM hash, we can forge our own ST to access the target resource (IIS APP) with any perms we desire. This custom ticket is known as a **Silver Ticket** and if the SPN is used on multiple servers, the Silver Ticket can be leveraged against all of them.

Mimikatz can craft a silver ticket and inject it straight into memory via **kerberos::golden** command. 

To create a ticket, we first need to obtain the so-called **Security Identifier (SID)** of the domain. A SID is a unique name for any object in AD. 

SID Structure:
```
S-R-I-S
```
**S** Literal 'S' char
**R** Revision Level, usually set to '1'
**I** Identifier-Authority, often '5' with AD
**S** Subauthority value, one or more of these

Ex. SID:
```
S-1-5-21-2536614405-3629634762-1218571035-1116
```
First 3 values "S-1-5" are fairly static within AD. The subauthority value is dynamic and has two parts:
- Domains Numeric Identifier: “21-
2536614405-3629634762-1218571035”
- Relative Identifier (RID): "1116"

We can obtain the SID of the current user with **whoami /user**.
C:\>
`whoami /user`
```
USER INFORMATION
----------------
User Name SID
=========== ==============================================
corp\offsec S-1-5-21-1602875587-2787523311-2599479668-1103
```

Now that we have to domain SID, lets craft a Silver Ticket for the IIS service previously discovered in our lab domain. 

First, flush an existing Kerberos tickets and verify purge:
`kerberos::purge`
`kerberos::list`

Now create the Silver Ticket:
`kerberos::golden /user:offsec /domain:corp.com /sid:S-1-5-21-1602875587-
2787523311-2599479668 /target:CorpWebServer.corp.com /service:HTTP
/rc4:E2B475C11DA2A0748290D87AA966C327 /ptt`
**/user** Target user
**/domain** Target domain
**/sid** Domain sid
**/target** Fully qualified host name of service
**/service:HTTP** Service type
**/rc4** PW hash of the iis_service account
**/ppt** Generate silver ticket injected directly to memory

Verify ticket creation:
`kerberos::list`

we now have a new ST for the SPN *HTTP/CorpWebServer.corp.com* that is laoded into memory and Mimikatz has set group perms for the forged ticket. 

From the perspective of the IIS app, the current user will be both the built-in admin (RID: 500) and a member of several high-priv groups including Domain Admins group. 

***
Note:
To create a silver ticket, we use the password hash and not the cleartext
password. If a kerberoast session presented us with the cleartext password, we
must hash it before using it to generate a silver ticket.
***

Now that the ticket is loaded into memory, we can interact with the service and gain access to any info based on group memberships we put in the Silver Ticket. 

Depending on the type of service, we might also be able to obtain code exeuciton.

