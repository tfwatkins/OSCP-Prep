Pass the Hash (PtH) allows authentication to a remote system or service using a user's NTLM hash instead of the assocaited plaintext PW.

Note: This WILL NOT work for Kerberos auth, only for servers or services using NTLM auth.

There are many 3rd party tools and frameworks that use PtH:
- PsExec from Metaslpot
- Passing-the-hash Toolkit
- Impacket

Mechanisms behind them are more or less the same:
- Attacker connects to victim useing SMB and performs auth using NTLM hash

Most tools that exploit PtH create and start a Windows service (like **cmd.exe** or a PS instance) and communicate with it via **Named Pipes**. This is done using the **Service Control Manager** API.

This tech requires an SMB connection through a firewall (usually TCP 445) and the Windows **File and Print Sharing** feature to be enabled. These are common configurations in internal Enterprise Environments. 

***
When a connection is performed, it normally uses a special admin share called
Admin$. In order to establish a connection to this share, the attacker must
present valid credentials with local administrative permissions. In other words,
this type of lateral movement typically requires local administrative rights.
***

Note that PtH uses the NTLM hash legitimately, but the vuln lies in the fact that we can gain unauthorized access to the password hash of a local admin.

To demonstrate, we can use **pth-winexe** from Passing-The-Hash toolkit. This is similar to when we passed the hash to a non-domain joined user in the PW Attack module:
`pth-winexe -U
Administrator%aad3b435b51404eeaad3b435b51404ee:2892d26cdf84d7a70e2eb3b9f05c425e
//10.11.0.22 cmd`

This method works for AD domain accounts and built-in local admin account. 

Since the 2014 security update, this tech CANNOT be used to auth as any other local admin account. 
