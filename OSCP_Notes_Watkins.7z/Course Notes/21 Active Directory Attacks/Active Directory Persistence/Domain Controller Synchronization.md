Another way to achieve persistence in AD is to steal the PW has for all admin users in the domain. 

To do this, we could move laterally to the DC and mimikatz to dump the pw hash of every user. We could also steal the **NTDS.dit** db file, which is used to copy all of the AD accounts stored on the harddrive, similar to a SAM db used for local account. 

These methods work, but they leave an access trail and require the uploading of tools. There is an alternate way to abuse AD itself to capture hashes remotely from a workstation. 

In prod evironments, domains typcially have more than one DC for redundancy. The Directory Replication Service Remote Protocol uses *replication* to synch these redundant DCs. A DC may request an update for a specific object like an account with **IDL_DRSGetNCChanges** API.

The DC receiving the rquest for an update does NOT verify that the request came from a known DC, but only that the associated SID has approrpiate privs. 

We can attempt to issue a rogue update request to a DC from a user who is a member of the Domain Admins group. 

Ex.
We will log in to the Win 10 client as Jeff_Admin to simulate compromise of a domain admin account and perform replication. 

Dump password hashes for Administrator using DCSync:
`lsadump::dcsync /user:Administrator`
**/user:** Target user to sync, in this case the built-in domain admin account

The dump contains multiple hashes with the last 29 used user PWs, as well as hashes used with AED encryption.

