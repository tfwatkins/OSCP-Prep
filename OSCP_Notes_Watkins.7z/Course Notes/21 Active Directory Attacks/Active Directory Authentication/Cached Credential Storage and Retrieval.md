Microsoft's implementation of Kerberos makes use of single sign-on, so PW hashes must be stored somehwere in order to renew a TGT request. 

In current versions of Win, they are stored in the **Local Security Authority Subsystem Service (LSASS)** memory space. 

If we can gain access, we can crack them for cleartext PWs or just utilize the hashes. 

This is the end goal of an AD attack, but is not straightforward:
- LSASS process is part of OS and runs as SYSTEM
- We need SYSTEM or Local Admin perms to gain access to stored hashes We often need to start off attack with local priv esc.
- Additionally, data structures used to store hashes in memory are not publically documented and are also ecrypted with an LSASS-stored key.

### Mimikatz
Used for extracting credentials and perform AD attacks against Windows endpoints.

***
Note that running **mimikatz** as a standalong app will set off detection signatures. Consider the following options to avoid detection:
- Execute mimikatz directly from memory using an injector like PS 
- Use a built-in tool like Task Manager to dump entire LSASS process memory, move dumped data to a helper machine and from there load data into Mimikatz.
***

Scenario:
Offsec domain user is a local admin, so we can launch cmd prompt with elevated privs. 

C:\Tools\active_directory> 
`mimikatz.exe`
mimikatz #


Use the **SeDebugPrivilege** privilege to allow us to interact with a process owned by another account:
`privilege::debug` 

Use the **Sekurlsa** module to dump creds of all logged-on users:
`sekurlsa::logonpasswords`

Note that the output conatains several types of hashes, this will vary based on functional level of AD implementation.
- For Functional Level of Win2003, NTLM will be only hashing algo
- For WinServ2008+, both NTLM and SHA-1 may be available
- For Win7 and older (or if it's manually set), Wdigest will be avaible
	- If Wdigest is set, mimikatz will reveal cleartext along with PW hashes

Another approach is to exploit kerberos auth by abusing TGT and service tickets. We know that Kerberos TGTs and Service Tickets for user currently logged on to a loca machine are stored for future use. They are also stored in LSASS and we can use mimikatz to interact with and retrieve our own and other users tickets. 

Use **Sekurlsa** to retrieve Kerberos Tickets stored in memory:
`sekurlsa::tickets`

Output shows both TGT and a TGS. Stealing a TGS would allow us to access only particular resources associated with those tickets. Alternatively, armed with a TGT ticket, we could request a TGS for specific resources we want to target inside the domain. 

***
Additionally, Mimikatz can export tickets to the hard drive and import tickets into LSASS. Mimikatz can also extract info related to auth performed through smartcard and pin.
***


