Active Directory supports multiple authentication protocols and techniques and implements authentication to both Windows computers as well as those running Linux and macOS.

***
Active Directory supports several older protocols including WDigest. While these may be useful against older operating systems like Windows 7 or Windows Server 2008 R2, we will only focus on more modern authentication protocols in this section.
***

Active Directory uses either Kerberos or NTLM authentication protocols for most authentication attempts. We will discuss the simpler NTLM protocol first.

### NTLM Auth
NTLM Auth is used when client auths to a server by IP instead of by hostname, or if user attempts to auth to a hostname that isn't registered on the AD integrated DNS server. Also, 3rd part apps may choose to use NTLM Auth instead of Kerberos auth.

**7 Steps of NTLM Auth**
1. Calculate NTLM Hash (On Client)
2. Username (Client -> App Server)
3. Nonce (App server -> Client)
4. Response (encrypted nonce) (Client -> App Server)
5. Response (username and nonce) (App server -> DC)
6. Encrypt nonce with NTLM hahs of user and compare response (DC -> App server)
7. Approve authentication (On DC)

![63956e5e2215339dbcd55564975b3831.png](../../../../../_resources/63956e5e2215339dbcd55564975b3831.png)

First, computer calculates a crypto hash called an NTLM hash from user's PW. Next, client sends uname to server which returns a random value called a nonce/challenge. Client encrypts nonce using NTLM hash and sends this "response" to server.

Server forwards response with uname and nonce to DC. Validation is perfrom by DC that already kowns NTLM hash of all users. DC encrypts challenge itself with NTLM hash of supplied unamea nd comapres it to response it received from server. If two are equal, auth request is successful.

NTLM (like any other hash) cannot be reversed. It is however considered a "fast-hashing" algorithm since short PW's can be cracked in a span of days with modest equipment. 

***
By using cracking software like Hashcat with top-of-the-line graphic processors, it is possible to test over 600 billion NTLM hashes every second. This means that all eight-character passwords may be tested within 2.5 hours and all ninecharacter passwords may be tested within 11 days.
***
