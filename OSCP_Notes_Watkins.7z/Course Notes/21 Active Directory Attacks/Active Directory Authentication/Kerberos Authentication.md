NTLM Auth works through a principle of challenge and response, Windows-based Kerberos works based on a "ticket system."

Kerberos client auth to a service in AD involves the use of the DC in the role of a **Key Distribution Center (KDC)**. 

**6 Steps to Kerberos Auth**:
1. Auth Server Request (Client -> DC)
2. Auth Server Reply (DC -> Client)
3. TGS Request (Client -> DC)
4. TGS Reply (DC -> Client)
5. Application Request (Client -> App Server)
6. Service Auth (App Server -> Client)

![b1e1dc5e88342028e532b1ed84ca70ba.png](../../../../../_resources/b1e1dc5e88342028e532b1ed84ca70ba.png)

When a user logs into a workstation, request is sent to DC (role of KDC) and the DC also maintains the Authentication Server service. This **Authentication Server Request (AS_REQ)** contains encrypted time stamp using hash derived from PW and username of user.

When DC receives the request, it looks up the pw hash associated to user and attempts to decrypt timestamp. If successful and timestamp is not a duplicate (replay attack), auth is considered successful. 

DC replies to client with an **Authentication Server Reply (AS_REP)** containing a *session key* (Kerberos is stateless) and a **Ticket Granting Ticket (TGT)**. Session key is encrypted user users pw hash and may be decrypted by client and reused. TGT contains info about user, group memberships, domain, timestamp, ip and session key. 

To avoid tampering, TGT is encrypted with secret key known only to KDC that CANNOT be decrypted by client. Once client receives session key and TGT, KDC considers client auth complete. By default, *TGT will bevalid for 10 hours*, after which renewal occurs. Renewal does not require use to re-enter password.

When user accesses resources of domain, such as a network share or other app with a registered SPN, it must again contact KDC. 

This time, client constructs a **Ticket Granting Service Request (TGS_REQ)** packet that consist of current user, ts (encrypted by session key), SPN of resource and encrypted TGT.

Next, the **Ticket Granting Service (TGS)** on KDC receives the TGS_REQ and if SPN exist in domain, TGT is decrypted using secret key known only to KDC. Session key is then extracted from TGT and used to decrypt username and timestamp of requiest. KDC performs several checks:
- The TGT must have a valid Timestamp. (no replay detected and request not expired)
- Username from TGS_REQ has to match username from TGT
- Client IP needs ot coincide with TGT IP.

If verification process succeeds, TGS responds to client with a **Ticket Granting Server Reply (TGS_REP)**. Packet contains three parts:
1. SPN to which access is granted
2. Session key to be used between client and SPN
3. **Service Ticket** containing uname and group memberships along with newly crafted session key.

Parts 1 and 2 are encrypted using session key associated with creation of the TGT and the Service Ticket is encrypted using the PW hash of service account registered with the SPN in question.

Once auth process by the KDC completes and client has both session key and service ticket, service auth begins.

Frist, clients send to the app server an **Application Request (AP_REQ)** which includes uname and TS encrypted with session key associated with service ticket along with the service ticket itself. 

App server decryptes service ticket user service accoutn pw hash and extracts uname and session key. Uses session key to decrypt uname from the AP_REQ. If AP_REQ uname matches one decrypted from service ticket, request is accepted. Before access in granted, service inspects supplied group memberships in service ticket and assigns appropriate perms to use, after which access is granted to requested service. 