AD- Serivce allowing sys admins to update and manage OS's, apps, user and data access. 

Main Component:
- DC: A Win 2000-2019 server with **Active Directory Domain Services** role installed
	- Stores all info about how instance of AD is configed
	- Enforces rules that govern objects within a Windows domain and their interactions, and what services and tools are available to end users

***
There are three different versions of Windows server operating systems. The first was the original “desktop experience” version. Server Core,602 introduced with Windows Server 2008 R2, is a minimal server installation without a dedicated graphical interface. Server Nano,603 the most recent version, was introduced in Windows Server 2016 and is even more minimal than Server Core. The standard “desktop experience” and Server Core editions can function as domain controllers. The Nano edition can not.
***

When an AD instance is configed, a **Domain** is created like *corp.com* where corp is org name. We can add objects like computers or users. 

Objects are organized using **Organizational Units (OU)**:
- Containers used to store and group objects

Computer objects represent servers and workstations that are **domain-joined** (part of the domain). 

User objects represent employees. 

All AD objects contain attributes (varied by object type) like fname, lname, uname, pw, etc. 

 Typically, client computers on an internal network are connected to the DC and other internal member servers like DB, file storage, etc. As well as internet-connected web servers that provide content but are also members of the internal domain.
 
 ***
Some orgs will have non-domain-joined machines, especially internet-facing machines. 
***

***
AD has a critical dependency on DNS service. Generally, the DC will also host a DNS server that is authoritative for the given domain. Note that you may also find DNS servers not related to AD that provide lookup service for other computers
***


