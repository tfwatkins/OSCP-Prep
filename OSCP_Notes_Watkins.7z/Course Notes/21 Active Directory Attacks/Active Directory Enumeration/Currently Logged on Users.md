At this point, we can list users with their group members and easily locate Admin users. 

Now we want to find logged-in users that are members fo high-value groups, since those creds will be cached in memory and we could steal and authenticate with them. 

If we can compromise one of the *Domain Admins*, we could eventually take over the ENTIRE DOMAIN. Alternatively, if we can't immediately comprmise a Domain Admin, we could compromise other accounts/machines to eventually gain that level of access.

![cb16eea73145927329467656196955a0.png](../../../../../_resources/cb16eea73145927329467656196955a0.png)

Example:
- Bob is logged in to CLIENT 512 and is Local Admin on all workstations
- Alice is logged in to CLIENT621 and is Local Admin on all servers
- Jeff is logged into SERVER21 and is a member of Domain Admins group

If we manage to compromise Bobs account (via client-side for example), we could privot from CLIENT512 to Alice on Client621 and possible pivot again to compromise Jeff on SERVER21, gaining domain access. 

Thus, we must tailor our enumeration to consider NOT ONLY Domain Admins but also potential avenues of "chained compromise" including a hutn for the so-called **Derivative local Admin**. 

To do this, we need a list of users logged on to a target. We could either interact with target directly or track a user's active logon session on a DC or file server. 

Two most reliable functions that can help achieve this are: 
- **NetWkstaUserEnunm** API 
	- Requires admin privs and returns a list of all users logged on to a target workstations
-  **NetSessionEnum** API
	-  Can be used from a regular domain user and returns a list of active user session on servers like file servers or DCs.

After compromising a domain machine, we should enumerate every computer in the domain and then use **NetWokstaUserEnum** against the obtained list of targets. Note that the API will only list users logged on to a target if we have local admin privs ON THAT TARGET.

Alternatively, we can focus on discovering DCs and file servers (based on server hostnames or open ports) in the network and use **NetSessionEnum** on thsoe servers to enumerate all active user's sessions. 

This will give us a good "exploitation map" to follow to compromise a Domain Admin account. Keep in mind that results obtained from using these APIs will vary depending on current perms fo teh logged-in user and config of AD environment. 

As a very basic example, in this section, we will use the NetWkstaUserEnum API to enumerate local users on the Windows 10 client machine and NetSessionEnum to enumerate the users’ active sessions on the domain controller.

Note that calling an OS API from PS is not straightforward. Other researchers have provided a tech that simplifies and helps avoid endpoint security detection. Most common solution is **PowerView** a PS script thats part of the **PowerShell Empire** framework. 

PowerView stored in **C:\Tools\active_directory** on Win10 client. 
Import:
PS C:\Tools\active_directory>
`Import-Module .\PowerView.ps1`

There are many functions, but we will only use the **Get-NetLoggedon** and **Get-NetSession** functions, which invoke **NetWkstaUserEnum** and **NetSessionEnum** respectively.

First, we enumerate logged-in users with **Get-NetLoggedon** along with **-ComputerName** option to specify target workstation or server. We are targeting the Win10 client so we will use:
PS C:\Tools\active_directory> 
`Get-NetLoggedon -ComputerName client251`

Next, retrieve active session off of DC01. These sessions are performed against DC when a user logs on, but originate from a specific workstation or server, which is what we are enumerating.

We can invoke the Get-NetSession function in a similar fashion using the -ComputerName flag. Recall that this function invokes the Win32 API NetSessionEnum, which will return all active sessions, in our case from the domain controller.
PS C:\Tools\active_directory> 
`Get-NetSession -ComputerName dc01`


