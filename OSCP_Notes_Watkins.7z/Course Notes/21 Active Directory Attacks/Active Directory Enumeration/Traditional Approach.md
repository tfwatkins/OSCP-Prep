Leverage built-in **net.exe** to enumerate local accounts:
`net user`

Enumerate all users in the entire comain:
`net user /domain`

Query a specific user:
`net user jeff_admin /domain`
We are lookiong for membership in **\*Domain Admins**

Enumerate all groups in the domain:
`net group /domain`

Note that **nested groups** exist. A group can be added as a member of another group, which effectively adds all members to the new group. 

Also note that **net.exe** CANNOT list nested groups and only shows direct user members. 