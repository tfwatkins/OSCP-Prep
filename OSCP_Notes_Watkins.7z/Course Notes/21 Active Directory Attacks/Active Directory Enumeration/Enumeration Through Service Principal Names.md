We have enumerated domain users in search of logged in accounts that are members of high value groups. 

An alternative to attacking a domain user account is to target *service accounts*, which may also be members of high value groups. 

When an app is executed, it does so in teh context of an OS user. Services launched by the system istself use the context based on a Service Account. 

In other words, isolated apps can use a set of predefined service accounts:
LocalSystem, LocalService, NetworkService.

For more complex apps, a domain user account may be used to provide needed context while still having access to resources inside the domain. 

When apps like Exchange, SQL or IIS are integrated itno AD, a unique servce instance ID konwn as a **Service Principle Name (SPN)** is used to associate a service on a specific server to a service account in AD.

***
Managed Service Accounts,634 introduced with Windows Server 2008 R2, were designed for complex applications which require tighter integration with Active Directory. Larger applications like SQL and Microsoft Exchange635 often require server redundancy when running to guarantee availability, but Managed Service Accounts cannot support this. To remedy this, Group Managed Service Accounts636 were introduced with Windows Server 2012, but this requires that domain controllers run Windows Server 2012 or higher. Because of this, many organizations still rely on basic Service Accounts.
***

By enumerating all registered SPNs in teh domain, we can get IP addresses and port numbers of apps running on servers integrated with target AD, liminting need for a broad port scan. 

Since info is registered and stored in AD, it's present on the DC. 

We will query the DC for specific service principle names.
***
While Microsoft has not documented a list of searchable SPN’s there are
extensive lists available online.
***

Update PS script to filter for **serviceprinciplename** property for the string *\*http\**, indicating prescense of a registered web server.
```
...
$Searcher.filter="serviceprincipalname=*http*"
...
```
Based on the output, one attribute name, samaccountname is set to iis_service, indicating the presence of a web server and serviceprincipalname is set to HTTP/CorpWebServer.corp.com. This all seems to suggest the presence of a web server.

Lets attempt to resolve the FQDN with **nslookup**:
`nslookup CorpWebServer.corp.com`

From the results, it’s clear that the hostname resolves to an internal IP address, namely the IP address of the domain controller.

If we browse this IP, we find a default IIS web server.

Although a domain controller would normally not host a web server, the student lab is full of surprises.

While the enumeration of service principal names does not produce the web server software or version, it will narrow the search down and allow for either manual detection or tightly scoped port scans.