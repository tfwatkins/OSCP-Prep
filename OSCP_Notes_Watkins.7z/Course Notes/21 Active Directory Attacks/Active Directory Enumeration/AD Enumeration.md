An AD attack typically begins with a successful exploit or client-side attack against either a domain workstation or server followed by AD environment enumeration. 

Once we have a foothold, we do priv esc to gain control of one or more domains. Multiple methods:
- Within AD, admins use groups to assign permissions to member users. We could target high-value groups. 
	- We could compromise a member of the **Domain Admins** group to gain complete control over every single computer in tehe domain.
- We could also gain control of domain by compromising a DC it may be used to modify all domain-joined computers and execute apps on them. 
	- The DC contains ALL pw hashes of every single domain user account

### Assumptions for enumeration:
- We have access to a Win10 workstations
- We have compromised the *Offsec* domain user, which is a member of the local admin group for a domain-joined workstations

First goal is to enumerate users and learn about group memberships in search of a high-value target. We will use tools and techs that DO NOT require administrative access. 

