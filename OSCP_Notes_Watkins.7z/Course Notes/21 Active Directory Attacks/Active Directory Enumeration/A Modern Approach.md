There are modern tools for enumerating like PS cmdlets **Get-ADUser** but they are only installed by default on DCs (as part of RSAT), and while they may be installed on workstation Win7+, they require admin privs to use. 

We can use PS to enumerate though. We will write a script that will query the network for the name of the  Primary DC emulator and the domain, search AD and filter the output to display user accounts and clean up output. 

***
Primary DC emulator is one of 5 operations master roles (OR FSMO roles) performed by DCs. Technically, the property is called PdcRoleOwner and the DC with this property will always have the most updated info about user login and authentication.
***

Script relies on a few components. We will use **DirectorySearcher** object to query AD using LDAP, which is a network protocol understood by DCs and used for comms with 3rd party apps. 

LDAP is an **Active Directory Service Interface (ADSI)** provided (an API) that supports search functions against AD. This will allow us to interface with DC using PS and extract non-priv info about domain objects. 

Script will center around a very specific **LDAP Provider Path** that is the input for **DirectorySearcher**. 

Path prototype:
`LDAP://HostName[:PortNumber][/DistinguishedName]`

We first need to discover the hostname of the DC and the components of the DistinguishedName (DN) using PS. We will use the **Domain** class of the **System.DirectoryServices.ActiveDirectory** namespace. The Domain class contains a method called **GetCurrentDomain** which retrieves the Domain object for the currently logged in user.

Querying for the Domain name, DC name and namespace:
`[System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()`
```
Forest : corp.com
DomainControllers : {DC01.corp.com}
Children : {}
DomainMode : Unknown
DomainModeLevel : 7
Parent :
PdcRoleOwner : DC01.corp.com
RidRoleOwner : DC01.corp.com
InfrastructureRoleOwner : DC01.corp.com
Name : corp.com
```

We can assemble this info into the LDAP Provider Path:
```
$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()

$PDC = ($domainObj.PdcRoleOwner).Name

$SearchString = "LDAP://"
$SearchString += $PDC + "/"

$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"

$SearchString += $DistinguishedName

$SearchString
```

Complete LDAP Provider Path output:
```
LDAP://DC01.corp.com/DC=corp,DC=com
```

We can now instantiate the DirectorySearcher class with the LDAP provider path. We have to specify a **SearchRoot** which is the node in AD hierarchy where searches start.

SearchROot is an object instantiated from the DirectoryEntry class. When now arguments are passed to the constructor, SearchRoot will indicate that every search should return results from the ENTIRE AD.

We add the following to our script:
```
$Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)

$objDomain = New-Object
System.DirectoryServices.DirectoryEntry

$Searcher.SearchRoot = $objDomain
```

Without filters, we would receive ALL objects in the entire domain. 

We can setup filters using teh **samAccountType** attribute, that all user, computer and group objects have. 

Refer to refernces for object numbers, but we will use 0x30000000 (decimal 805306368) to filter property and enumerate all users in teh domain. 

Add to script:
```
$Searcher.filter="samAccountType=805306368"

$Searcher.FindAll()
```
We invoke the **FindAll()** method to conduct a search and find all results for given filter. 

We receive good info, but it could be cleaned up. Since attributes of a user are stored within the *Properties* field, we can use a double loop to print each property on it's own line.

Add to script:
```
Foreach($obj in $Result)
{
	Foreach($prop in $obj.Properties)
	{
		$prop
	}
	Write-Host "------------------------"
}
```

There is a lot of information. We can filter to locate members of a specific group like *Domain Admin* or filter for a specific user like Jeff_Admin. 

We can set any attribute of the object type in the filter property.
Ex. Use name property to create a filter for Jeff_Admin
`$Searcher.filter="name=Jeff_Admin"`


### Final Script:
```
$domainObj = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()

$PDC = ($domainObj.PdcRoleOwner).Name

$SearchString = "LDAP://"

$SearchString += $PDC + "/"

$DistinguishedName = "DC=$($domainObj.Name.Replace('.', ',DC='))"

$SearchString += $DistinguishedName

$Searcher = New-Object System.DirectoryServices.DirectorySearcher([ADSI]$SearchString)

$objDomain = New-Object System.DirectoryServices.DirectoryEntry

$Searcher.SearchRoot = $objDomain

$Searcher.filter="samAccountType=805306368"

$Result = $Searcher.FindAll()

Foreach($obj in $Result)
	{
		Foreach($prop in $obj.Properties)
		{
			$prop
		}
	Write-Host "------------------------"
}



