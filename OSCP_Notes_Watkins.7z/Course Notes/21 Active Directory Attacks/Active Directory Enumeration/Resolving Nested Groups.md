We can use our PS script to unravel nested groups discovered during use of **net.exe**.

First task is to locate all groups in domain and print names. We will create a filter that extracts all records with an ObjectClass set to "Group" and only print the name property for each group instead of all properties:

```
...

$Searcher.SearchRoot = $objDomain

...<Script the same until now>...

$Searcher.filter="(objectClass=Group)"

$Result = $Searcher.FindAll()

Foreach($obj in $Result)
{
	$obj.Properties.name
}
```

Now lets list members of *Secret_Group* by setting filter on the *name* property. We will only display *member* attribute to obtain group members:
```
...

$Searcher.SearchRoot = $objDomain

...<Script the same until now>...

$Searcher.filter="(name=Secret_Group)"

$Result = $Searcher.FindAll()

Foreach($obj in $Result)
{
	$obj.Properties.member
}
```
CN=Nested_Group,OU=CorpGroups,DC=corp,DC=com

According to the output, Nested_Group is a member of Secret_Group. 

To enumerate it's members, we must repeate the steps t list the members of Nested_Group. Just replace in filter and output. :

```
...

$Searcher.SearchRoot = $objDomain

...<Script the same until now>...

$Searcher.filter="(name=Nested_Group)"

$Result = $Searcher.FindAll()

Foreach($obj in $Result)
{
	$obj.Properties.member
}
```
CN=Another_Nested_Group,OU=CorpGroups,DC=corp,DC=com

we find another nested group! Repeate the process:
```
...
$Searcher.SearchRoot = $objDomain
$Searcher.filter="(name=Another_Nested_Group)"
...
```
CN=Adam,OU=Normal,OU=CorpUsers,DC=corp,DC=com

We find that "Adam" is the sole member of Another_Nested_Group. 



