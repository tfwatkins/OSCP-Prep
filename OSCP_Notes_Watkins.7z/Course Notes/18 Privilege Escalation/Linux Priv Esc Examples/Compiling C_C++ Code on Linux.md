Compile the exploit to match system arch:
`gcc 43418.c -o exploit`