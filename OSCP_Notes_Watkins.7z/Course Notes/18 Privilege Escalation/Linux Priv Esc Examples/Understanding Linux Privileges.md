Defining Feature of \*nix:
- Most recources (files, dirs, devices, net comms) are represented in filesystem
	- AKA "Everything is a file"
- Every file (thus every element) has user/group perms: Read, Write and Execute