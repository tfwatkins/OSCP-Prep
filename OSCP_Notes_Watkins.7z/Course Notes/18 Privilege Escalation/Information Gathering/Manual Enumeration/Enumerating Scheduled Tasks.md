When scheduled tasks are misconfigured, or the user-created files are left with insecure permissions, we can modify files that will be executed by the scheduling system at a high privilege level.

Windows- Create and view schedules tasks:
`schtasks /query /FO LIST /v`
**/query** Displays tasks
**/FO LIST** Sets the output format to a simple list
**/v** Verbose output

Linux- Job Schduler = Cron
Cron jobs are schedules under **/etc/cron.\*** with the asterisk represting the frequence the task will run on. Ex. **/etc/cron.daily**

Sys admins often add their own scheduled tasks in the **/etc/crontab**. These tasks often have insecure file permissions and will run as root. 

