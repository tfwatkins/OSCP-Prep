Kernel exploits are built for a VERY specific target, looking to exploit vulns at the core of the target's OS.

Gather operating system and arch info (W):
`systeminfo`

Filter output with findstr:
`systemnifo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"`
**/B** Match patterns at the beginning of a line
**/C** Search for a particular string

On linux the **/etc/issue** and **/etc/\*-release** files contain similar info.

OS version and arch on linux (L):
`uname -a` 
