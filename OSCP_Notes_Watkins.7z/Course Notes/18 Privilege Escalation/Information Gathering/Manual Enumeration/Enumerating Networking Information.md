Review available network interfaces, routes and open ports. 

Could help us determine if target is connected to multiple networks, allowing a pivot. 

Specific virutal interfaces may indicate virtualization or antivirus software. 

We can also investigate port bindings looking for a running service that's only available on a loopback. A privileged program or service on loopback could expand our attack surface.

Windows- Display full tcp/ip config for all adapters:
`ipconfig /all`

Windows- routing tables
`route print`

Windows- Active network connections
`netstat -ano`
**-a** All active TCP connections
**n** display address and port number in numerical form
**o** Onwer PID of each connection

Linux- Network adapter info
`ifconfig a`
`ip a`

Linux- Routing Table
`/sbin/route`
Or
`/sbin/routel`
Depends on version

Linux- Display active network connections and listening ports
`netstat -anp`
OR
`ss -anp`
**-a** all connections
**n**  avoid hostname resolution (may stall command exeuction)
**p** List process name connection belongs to
