On most systems, drives are auto mounted at boot time.
We should not forget about UNMOUNTED drives.
If they exist, check perms.

Windows- list all drives that are either mounted or unmounted but physically connected
`mounvol`

Linux- List all mounted filesystems
`mount`

We can also look at **/etc/fstab** file that list all drives to be mounted at boot time.
***
Keep in mind that the system administrator might have used custom
configurations or scripts to mount drives that are not listed in the /etc/fstab file.
Because of this, it’s good practice to not only scan /etc/fstab, but to also gather
information about mounted drives with mount.
***

We can also use **lsblk** to view all available disks
`/bin/lsblk`

Might reveal partitions tat are not mounted. We might be able to mount those and search for interesting docs, creds or other info.

