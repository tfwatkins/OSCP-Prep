We may have to use an exploit to escalate local privs. We will being by enumerating installed apps, noting the verion of each as well as OS and Patch Level. 

Windows hosts a very powerful utility **wmic** to automate this process. 

WMIC (Windows Management Instrumentation) is for managing data and operations. *It will ONLY list apps installed by Windows Installer.* 

`wmic product get name, version, vendor`
**product** WMI Class Argument
**get** Retrieve specific property values
**name, version, vendor** Properties we are interested in 

WMIC to list system-wide updates by querying the Win32_QuickFixEngineering (qfe) WMI class:
`wmic qfe get Caption, Description, HotFixID, InstalledOn`
A combo of HotFixID and InstalledOn info can provide us with a precise indication of the security posture of the target windows OS.

Linux based systems have a variety of package managers.
Debian Linux- **dpkg**
Red Hat- **rpm**

Debian- List installed apps:
`dpkg -l`

