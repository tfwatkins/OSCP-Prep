Windows- List loaded drivers with **driverquery** and filter inside a PS session, displaying verbose output of selected properties to a CSV.
`powershell`
`driverquery.exe /v /fo csv | ConvertFrom-CSV | Select-Object
‘Display Name’, ‘Start Mode’, Path`

Windows- Request version info of each loaded driver
`Get-WmiObject Win32_PnPSignedDriver | Select-Object DeviceName,
DriverVersion, Manufacturer | Where-Object {$_.DeviceName -like "*VMware*"}`

Linux- Enumerate loaded kernel modules
`lsmod`

Linux- Get more info on a specific module
`/sbin/modinfo <name>`

