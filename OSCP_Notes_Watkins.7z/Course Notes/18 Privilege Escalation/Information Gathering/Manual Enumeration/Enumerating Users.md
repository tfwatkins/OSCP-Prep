Identify User Context (W/L): 
`whoami`

Pass discovered username to net user  to gather more info (W):
`net user <username>`
Pay special attention to "Local Group Memberships"

id for user context (L):
`id`
Shows uid and guid

Gather other users on machine (W):
`net user`

Enumerate users on linux via /etc/passwd (L):
`cat /etc/passwd`





