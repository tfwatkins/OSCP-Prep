 Specific enumerations that reveal OS specific "shortcuts" to PrivEsc.
 
Windows-  
Check the  AlwaysInstallElevated registry setting. If enabled (set to 1) in HKCU or HKLM, any user can run Windows installer packages with elevated privs. 

Query the registry for the AlwaysInstallElevated key value:
`reg query
HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Installer`

`reg query
HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\Installer`

If this setting is enabled, we could craft an MSI file and rut it to elevate our privs.

Linux-
We can search for SUID files. Normally when it runs, an execuatable inherits the perms of the user who runs it. 

If the SUID perms are set, then the binary will instead run with the perms of the OWNER. So if the SUID bit is set, and the owner is root, and local user will be able to execute the binary with elevated privs.

Use find to search for SUID marked binaries:
`find / -perm -u=s -type f 2>/dev/null`
**-type f** find files
**-perm -u=s** SUID bit set
**2>/dev/null** discard error messages

An example of an exploitable binary:
If **/bin/cp** (the copy command) were SUID, we could copy and overwrite sensitive files such as **/etc/passwd**
