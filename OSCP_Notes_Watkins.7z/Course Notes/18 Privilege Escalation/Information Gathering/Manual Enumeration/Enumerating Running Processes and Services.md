Processes running in the context of a privileged account and having either insecure permission or allowing us to interact with them in insecure ways are prime targets for PrivEsc.

Windows:
`tasklist /SVC`
Return precesses that are mapped to a specific windows service
Note that this output does not list processes run by privileged users, you need higher privileges yourself to gather this information. 

Linux:
`ps axu` List system processes including those run by priv users.
**a**, **x** list all processes with or without a tty
**u** list processes in a user readable format.