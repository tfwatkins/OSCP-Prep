Scrips/binaries with insufficient acces restrictions can  potentially be exeucted under the context of a privileged account.

Additionally, sensitive files that are readable by unpriv users may contain creds for a db or a service acccount.

Checking the file perms of each file and directory is NOT feasible. We need to automate. 

Windows- we can use AccessChk from SysInternals.

We will enumerate the Program Files directory for any file/dir that allows the Everyone group Write permissions.


c:\Tools\privilege_escalation\SysinternalsSuite>
`accesschk.exe -uws "Everyone" "C:\Program Files"`
**-u** suppress errors
**-w** search for write access permissions
**-s** perform recursive search

There are additional options that are quite useful.

This can also be accomplished with PowerShell:

PS C:\Tools\privilege_escalation\SysinternalsSuite>
`Get-ChildItem "C:\Program Files" -Recurse | Get-ACL | ?{$_.AccessToString -match "Everyone\sAllow\s\sModify"}`
**Get-Acl** retrieve all perms for given file/dir (wont run recursively)
**Get-ChildItem** used to enumerate everything in the target dir
**AccessToString -match** narrows down results to match specific properties

Linux- ID insecure perms
`find / -writable -type d 2>/dev/null`
**/** root directory
**-writable** specify attributes we are interested in
**-type d** locate directories
**2>/dev/null** Filter errors 