Generally, a firewall's state, profile and rules are only of interest during the remote exploit stage. 

However, sometimes this can be useful during priv esc. 

Ex. If a network service is not remoteyl accessible because it's blocked by the firewall, then it is generally accessible locally via the loopback interface. 

If we can interact with these services locally, we may be able to exploit them to escalate our privs on the local system.

Additionally, we can gather info about inbound/outbound port filtering during this phase to facilitate port forwarding and tunneling when it's time to pvito to an internal network. 

Windows- inspect current firewall profile:
`netsh advfirewall show currentprofile`

Windows- List firewall rules
`netsh advfirewall firewall show rule name=all`
 
 Must have **root** privs on linux to list firewall rules:
 `iptables`
 
 But you may be able to glean some info about the rules as a standard user. 
 
 Ex. The iptables-persistent package on Debian Linux saves firewall rules in specific files under **/etc/iptables/** directory by default. Often use to restore netfilter rules at boot time.  Often left with weak permissions, allowing any user to read them.
 
 We can also search for files created by the **iptables-save** command, used to duymp the fireall config to a file specified by the user.
 
 File is usually input for **iptables-restore** (restores firewall rules at boot time)
 
 If a sys admin has ever run this command, we could search the config directory **/etc** or grap the file system for iptables command to locate the file. If the file has insecure permissions, we could use the contents to infer firewall config rules.
 
 