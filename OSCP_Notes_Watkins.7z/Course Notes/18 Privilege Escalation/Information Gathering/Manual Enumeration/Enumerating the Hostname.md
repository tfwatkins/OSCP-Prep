Hostnames often have an identifiable abbreviation like web, db, or dc.

Discover hostname (W/L):
`hostname`