Exploiting system-level software such as kernel or drivers requires careful attention to OS and version or we risk crashing (BSOD) the machine.

Determine version and arch of target:
`systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"`

We find that we could try to locate native kernel vulns for Windows 7 SP1 x86.. but 3rd party driver exploits are MUCH more common. 

Lets enumerate the drivers:
`driverquery /v`

We find a 3rd party driver: "USBPcap"

Even though a driver is marked as "stopped", we may still be able to interact with it as it is still loaded in the kernel memory space.

Microsoft drivers have a rigorous patch cycle, so 3rd party drivers are often a better attack surface. 

Look for vulns:
`searchsploit USBPcap`

One exploit. It targets our OS, patch level and arch but also targets a specific USBPcap version.

Lets investigate our system to find driver version:
`cd "C:\Program Files"`
`dir`

NOTE: we found a directory in Program Files, but drivers are more often found in:
**C:\Windows\System32\DRIVERS**

Inspect to learn more:
`type USBPcap.inf`

We find the driver version is vulnerable. 

But first we need to compile the code in C.
