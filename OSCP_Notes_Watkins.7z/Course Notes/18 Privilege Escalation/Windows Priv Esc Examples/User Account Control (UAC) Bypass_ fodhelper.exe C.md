There are numerous UAC bypasses. We will look at one for silently elevating Integrity level from med->high.

Most UAC bypasses are specifically targeted for an OS and Version.
Ex. We will use one for Win10 Build 1709

Targeting: fodhelper.exe:
- fodhelper.exe is a support app responsible for managing languaged changes in the OS.
- Launched when a user selects the “Manage optional features” option in the “Apps & features” Windows Settings screen.

fodhelper.exe binary runs as High Integrity on Win10 1709. 

We can leverage this to bypass UAC due to the way fodhelper interacts with the Reg. It interactics with reg keys that can be modified without admin privs.

We will run the fodhelper.exe program and inspect the **application manifest**, which is an XML file with info that lets the OS know how to handle the app when it's tarted. 

Inspect the manifest with **sigcheck** from SysInternals:
`cd C:\Tools\privilege_escalation\SysinternalsSuite`

`sigcheck.exe -a -m
C:\Windows\System32\fodhelper.exe`
**-a** Extended info
**-m** Dump manifest

Results:
- Requires admin access token
- AutoElevate flag is set to true, which allows the executable to auto-elevate to high integrity without prompting admin user for consent. 



We can use Process Monitor from SysInternals  to gather more info on the tool:
***
Process Monitor is an invaluable tool when our goal is to understand how a
specific process interacts with the file system and the Windows registry. It’s an
excellent tool for identifying flaws such as Registry hijacking, DLL hijacking,517
and more.
***

Start **procmon.exe** and run fodhelper.exe and set filters specificaly to focus on activites performed by our target process. We can adjust filters with a search for "Reg".

We are looking for (hopefully) fodhelper to be trying to access reg entries that dont exist. Alter the procmon filter for "NAME NOT FOUND"; an error message indicating what we are looking for.

We have a hit, but we can't modify reg entries in every hive. We will focus on those we can control, HKCU is definitely one. Re-filter procmon for this.

We see the app attempts to query the missing reg key:
**HKCU:\Software\Classes\ms-settings\shell\open\command**

We will modify our check to looks for the path:
**ms-settings\shell\open\command**, under any hive.

Interesting results. Whe fodhelper does not find the key in **HKCU**, it looks for it in **KHCR**. That entry does exist, so access is successful.

Searching **for HKCR:ms-settings\shell\open\command** shows that this entry does exist and is valid.

***
Research:

Based on this observation, and after searching the MSDN documentation519 for this registry key format (application-name\shell\open), we can infer that fodhelper is opening a section of the Windows Settings application (likely the Manage Optional Features presented to the user when fodhelper is launched) through the ms-settings: application protocol.520 An application protocol on

URL-Application mappings can be defined through Registry entries similar to the ms-setting key we found in HKCR (Figure 12 above). In this particular case, the application protocol schema for ms-settings passes the execution to a COM521 object rather than to a program. This can be done by setting the DelegateExecute key value522 to a specific COM class ID as detailed in the MSDN documentation.
***
Fascinating.. but the relevant part is that fodhelper tries to access the ms-setting reg key within KHCU hive first.

We should be able to create the missing key in KHCU:
`REG ADD HKCU\Software\Classes\ms-settings\Shell\Open\command`

Clear the results from procmon (the filters are persistent) and restart fodhelper.exe.

We find that fodhelper attempts to query a value "DelegateExecute" stored in our newly created "command" key. This didn't happen before. We don't want to hijack exeuction through a COM object, so we'll add DelegateExecute entry and leave it's value empty. We are hoping that when fodhelper discovers the empty value, it will forllow the MSDN spects for app protocols and look for programs to launch specified in the **Shell\Open\command\Default key entry.**

Use REG ADD with /v to spec value name and /t to spec type:
`REG ADD HKCU\Software\Classes\ms-settings\Shell\Open\command /v DelegateExecute /t REG_SZ`

Remove the "NAME NOT FOUND" filter in ProcMon and replace it with "SUCCESS".
Restart process.

fodhelper finds the new DelegateExecute entry, sees it's empty, looks for (Default) entry value of Shell\open\command reg key. Default value is created as null automatically. we will replace the empty (default) value with cmd.exe. 

Set a new reg value silently with /f and spec the value with /d "cmd.exe":
`REG ADD HKCU\Software\Classes\ms-settings\Shell\Open\command /d "cmd.exe" /f`

After setting the value and running fodhelper.exe again, we are presented with a command shell. 

Running `whoami /groups` tells us we have achieved a high-integrity command shell. 
