Used when we have write permissions to a service's main and subdirectories but cannot replace files within them.

Each windows service maps to an exe that will be run when service is started.
Most of the time, 3rd party services have software stored under **C:\Program Files**, which contains a "space" character in it's name. This is potentially an opportunity for a PrivEsc attack.

Developers MUST ensure that file or directory paths are explicitely declared with quotations. When a path name is "unquoted", it's open to interpretation. Whitespace will be treated as a potentional argument or option for the exe.

If a service stored in a paht is unquoted, windows will attempt to start the service by building up each "word" of the pathname (seperated by whitespace) until it finds and exe at one of the paths.

Ex: **C:\Program Files\My Program\My Service\service.exe**
- C:\Program.exe
- C:\Program Files\My.exe
- C:\Program Files\My Program\My.exe
- C:\Program Files\My Program\My service\service.exe

We will insert a malicious exe into a directory corresponding with one of these interpreted paths.

When the service runs, it should execute our file with the same privs as the service starts with: Usually NT\SYSTEM.

In this example we could name and place our exe:
- C:\Program.exe
- C:\Program Files\My.exe

However, this would require some unlikely write permissions since standard users don't have write access to these directories by default.

It's much more likely that the softwares main directory (C:\Program Files\My Program\) or subdirectory ((C:\Program Files\My Program\My service) is misconfigured. This makes the follwing the most likely option for placement:
-- C:\Program Files\My Program\My.exe