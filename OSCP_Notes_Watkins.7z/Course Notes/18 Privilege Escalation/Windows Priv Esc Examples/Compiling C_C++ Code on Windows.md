The vast majority of kernel-level exploits are writtin in C/C++ and require compilation.

Ideally we compile on the platform the code is intended to run on, which can be as simple as spinning up a VM that matches our target.

We can also cross-compile.

For this example, we will just compile on Windows using Mingw-w64:
Mingw-w64 will provide us with a GCC compiler.

Run the bat script to setup the PATH variable for the GCC exe:
C:\Program Files\mingw-w64\i686-7.2.0-posix-dwarf-rt_v5-rev1>
`mingw-w64.bat`

The auther doesn't mention anything specifc with compilation, so we compile with no options other than output:
`gcc 41542.c -o exploit.exe`

There are two warnings (no errors), but compilation was successful. 

Transfer the exe and run it. 

Boom, we have NT AUTHORITY\SYSTEM.

