A  barrier between medium and high Integrity levels, prompting for either Administrative Creds or (if already logged in to a priv account) then Admin Consent.

Win- Check group integrity levels:
`whoami /groups`

Lets say we are logged in as Admin. We run whoami and see that this command prompt is operating at a medium integrity level. 

We attempt to change the password for admin user:
`net user admin Ev!lpass`
Access is denied.

Why? We are logged in as Admin...?

Because it requires a "High" integrity level to change an admin user's password.

One way is with PS using the Start-Process cmdlet specifying the "Run as Admin" option.

Use PS to spawn a new cmd.exe process with High Integrity:
`powershell.exe Start-Process cmd.exe -Verb runAs`