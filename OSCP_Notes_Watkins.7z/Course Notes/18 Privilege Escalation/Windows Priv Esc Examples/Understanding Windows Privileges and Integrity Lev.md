### Access Tokens 
Access Tokens are Objects generated when a user is authenticated. Assigned to user, containing information describing the security context and **privileges** of user.

Unique SID assigned to teach object (including tokens) such as a user or group account.

SID generated and maintained by Windows Local Security Authority.

### Integrity Mechanism
Windows security architecture assigns Integrity Levels to app processes and securable objects. Describes the level of trust the OS has in running apps or securable objects.

Dictates actions that an app can perform: ex. read/write local file system. 
APIs can also be blocked from specific integrity levels. 

From Vista Onward, processes run at 4 integrity levels:
- System Integrity Process: SYSTEM rights
- High Integrity Process: Admin rights
- Medium Integrity Process: Standard user rights
- Low Integrity Process: Very restricted rights often used in sandboxed processes




