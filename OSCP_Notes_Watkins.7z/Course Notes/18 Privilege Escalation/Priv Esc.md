We assume we have gained non-priveleged user access.

Every target is "unique" due to differnces in OS versions, patching levels and other factors. Regardless, there are common priv esc approaches.

To leverage these, we will search for:
- Misconfigured services
- Insufficient file permissions
- Restrictions on binaries or services
- Direct Kernel Vulns
- Vulnerable software running with high privileges
- Sensitive info stored in local files
- Registry setttings that always elevate privs before executing a binary
- Installation scripts that may contain hard coded creds
- and more!
