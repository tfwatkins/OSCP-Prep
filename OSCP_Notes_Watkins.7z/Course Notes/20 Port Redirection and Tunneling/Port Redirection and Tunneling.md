Tunneling a Protocol- Encapsulating it within a different protocol. 

We can carry a given protocol over an incompatible delivery network or provide a secure path through an untrusted network. 