Scenario:

Compromised Linux web server has internet access and connects to compromised Linux client.

Linux client DOES NOT have direct web access. Only access to Web Server.

We need to transfer tools to the client in order to coinue to assess the internal network or exfiltrate data. 

![7b178aced6a5aa6d039a8fa5a7573828.png](../../../../../_resources/7b178aced6a5aa6d039a8fa5a7573828.png)

Outbound filtering prevents connectivity and the downloading of tools

Test internet connectivity by pinging and nc'ing to google:
`ping google.com -c 1`

`nc -nvv 216.58.207.142 80`
`GET / HTTP/1.0`

We will SSH to Client and test internet connectivity from there. 

We use the IP address since an actual internet disconnected internal network may not have a working external DNS.

`ssh student@10.11.0.128`
`nc -nvv 216.58.207.142 80`
(UNKNOWN) [216.58.207.142] 80 (http) : No route to host
sent 0, rcvd 0

Test failed. In order to transfer files to an internet connected host, we must first transfer them to Linux web sever and THEN transfer them again to our intended destination. 

Instead, we will use a port forwarding tool called **rinetd** to redirect traffic on our Web Server. 
`sudo apt update && sudo apt install rinetd`

rinted conf file **/etc/rinetd.conf** list forwarding rules and required 4 parameters:
- bindaddress (listening IP)
- bindport (listening port)
- connectaddress (destination address)
- connectport (destination port)

For example:
We can use rinetd to redirect any trffic received by the web server on port 80 to google.com Ip address:
`cat /etc/rinetd.conf`
```
...
# bindadress bindport connectaddress connectport
0.0.0.0 80 216.58.207.142 80
...
```

The rule states that all traffic received on port 80 of the web server, listening on all interfaces (0.0.0.0) regardless of destinatoin will be redirected to 216.58.207.142:80.

Start the service and confirm it's listening with **ss** (socket stats):
`sudo service rinetd restart`
`ss -antp | grep "80"`

Now try to connect to port 80 on the Web Server:
`nc -nvv 10.11.0.4 80`
`GET / HTTP/1.0`
```
...
Set-Cookie: 1P_JAR=2019-08-26-15; expires=Wed, 25-Sep-2019 15:46:18 GMT; path=/;
domain=.google.com
...
```

Connection successful. Looking at *Set-Cookie*, the connection was forwarded.

We can now use this technique to connect from our previously internet-disconnected linux client throough the the linux web server to any internet connect host by simply chaning the **connectaddress** and **connectport** in the web server's **/etc/rinetd.conf** file.

![9f12b7bedc97c5a5f8558b1c8ef7aa5c.png](../../../../../_resources/9f12b7bedc97c5a5f8558b1c8ef7aa5c.png)


