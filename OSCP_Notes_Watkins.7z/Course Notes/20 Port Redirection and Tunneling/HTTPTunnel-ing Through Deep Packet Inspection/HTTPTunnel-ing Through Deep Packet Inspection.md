Thus far we've traversed firewalls based on port filters and stateful inspection. 

Certain deep packet content inspection devices may only allow or dissallow certain protocols, like SSH. If SSH isn't allowed, all the tunnels that rely on it will fail. 

### Scenario:
Comped linux Client, root privs, pw's for root and student. 

Assume deep packet content inspection is implemented to only allow HTTP, so SSH-based tunnels will not work. 

Additionally, firewall ony allows: 80, 443, 1234 inbount and outbound. 
80 and 443 due to it being a webserver and 1234 is an oversight. 

Goal is to initiate an RDP connection from Kali to Win Serv 2016 through compromised Linux server using only HTTP. 

### Plan:
we will rely on **HTTPTunnel** to encapsulate traffic in HTTP requests. 
***
The stunnel597 tool is similar to HTTPTunnel598 and can be used in similar ways. It is a multiplatform GNU/GPL-licensed proxy that encrypts arbitrary TCP
connections with SSL/TLS.
***
`apt-cache search httptunnel`
`sudo apt install httptunnel`

We have an HTTP based shell on teh internal linux server via TCP 443. 

We will create an SSH local port forward bound to port 8888, which will forward all connections to Win Serv on 3389 (RDP). This is allwed since both machines are on the same network and traffic does NOT traverse the deep packet inspection device. However, protocol restrictions create an issue when we attemtp to connect a tunnel from Linux Server to Kali. An SSH tunnel will be blocked.

To Solve: Create an HTTP-based tunnel. *Input* will be Kali (localhost 8080) and *output* will be Linux Client  on listening port 1234 (across the firewall). 

Here HTTP request are decapsulated and traffic handed off to listening port 8888 on Linux Client, which thanks to SSH based local forward is redirected to our Windows targets RDP port.

After, we will initiate an RDP session on Kali 8080. Request is HTTP encapsulated, sent across HTTPTunnel to port 1234 on Linux Client, decapsualted and finally sent to our Windows remote destktop port on the target Win Serv 2016.

![979d771435577a5ee15dc00bf7804663.png](../../../../../_resources/979d771435577a5ee15dc00bf7804663.png)

### Execution:

Create local SSH based port forward between Linux Client and Windows RDP:
`ssh -L 0.0.0.0:8888:192.168.1.110:3389 student@127.0.0.1`
**-L** local port forward from Kali (127.0.0.1) logging in as student
**0.0.0.0:8888** Forward all request on port 8888 
**192.168.1.110:3389** Receive all forwarded request on port 3389

`lab` students pw
`ss -antp | grep "8888"` Check connection

Next, create an HTTPTunnel out from Kali machine. HTTPTunnel uses client **htc** and server **hts**:
`hts --forward-port localhost:8888 1234`
**hts** server listents on port 1234
**--forward-port localhost:8888** redirect decapsulated HTTP stream to localhost port 8888, which thanks to previous command is redirect to Windows Targets RDP port.

Check
`ps aux | grep hts`
`ss -antp | grep "1234"`

Next, need an HTTPTunnel client that takes RDP traffic, encapsulates it into HTTP stream and sends it to listening HTTPTunnel server. 
`htc --forward-port 8080 10.11.0.128:1234`

Check:
`ps aux | grep htc`
`ss -antp | grep "8080"`

Now all traffic sent to TCP 8080 on Kali is redirected into HTTP tunnel, HTTP Encapsulated, sent across firewall to Linux Client, decapuslated, and redirected again to Win Server 2016 RDP. 

### Testing:
Sniff traffic with wireshark and RDP into our kali llinux machine on port 8080
`rdesktop 127.0.0.1:8080`

Should be given an RDP session and see HTTP-Encapsulated traffic in Wireshark. 