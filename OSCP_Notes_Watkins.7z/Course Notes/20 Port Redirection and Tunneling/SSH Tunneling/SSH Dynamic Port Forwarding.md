Dynamic Port Forwarding allows us to set a local listening port and have it tunnel incomming traffic ot any remote destination through the use of a proxy. 

### Scenario:
Compromised Linux target with elevated privs. No inbound/outbound traffic restrictions on teh fireway. 

Connected to an additional internal subnet on a different interface. Win Serv 2016 machine on this subnet with network shares available. 

With local port forwarding, we interacted with shares on Win Serv via a specific IP and port. We would like to target additional ports on Win Serv or other host on the internal network without establishing different tunnels per port/host of interest.

### Execution:

Syntax:
`ssh -N -D <address to bind to>:<port to bind to> <username>@<SSH server address>`

We can use **ssh -D** to specify local dynamic SOCKS4 application level port forwarding, tunneled within SSH:
`sudo ssh -N -D 127.0.0.1:8080 student@10.11.0.128`
**-N** No commands
**-D** Dynamic port forwarding, creating local SOCKS4 app proxy
**127.0.0.1:8080** Create proxy on our local machine on TCP 8080 which will tunnel all incoming traffic to any host through the compromised machine
**student@10.11.0.128** Compromised machine we are tunneling through, logged in as student

We now have an app proxy that can route application traffic to the target network through the SSH tunnel. 

We must direct our recon and attack tools to use this proxy. We can run any network apps through HTTP, SOCKS4 and SOCKS5 proxies with the help of **ProxyChains**.

To configure ProxyChains, edit **/etc/proxychains.conf** add our SOCKS4 proxy to it:
`cat /etc/proxychains.conf`
```
...
[ProxyList]
# add proxy here ...
# meanwile
# defaults set to "tor"
socks4 127.0.0.1 8080
Listing 641 -
```


![180c81f15195e5661ee49bf25d2b297e.png](../../../../../_resources/180c81f15195e5661ee49bf25d2b297e.png)

### Testing/Usage:
To run tools through the SOCKS4 proxy, prepend each command with **proxychains**.

Scanning Win Serv 2016 machine using nmap:
`sudo proxychains nmap --top-ports=20 -sT -Pn 192.168.1.110`

***
By default, ProxyChains will attempt to read its configuration file first from the
current directory, then from the user’s $(HOME)/.proxychains directory, and
finally from /etc/proxychains.conf. This allows us to run tools through multiple
dynamic tunnels, depending on our needs.
***



