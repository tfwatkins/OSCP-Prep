SSH supports bi-directional encrypted tunnels, making it ideal for sys admins and pentesters.

SSH Local Port Fowarding- Tunneling a local port to a remote server using SSH as the transport protocol. 

Similar to rinetd, with a few exceptions.

### Scenario:
We have root on a linux client that is only connected tothe current network via ports 22 and 3389. The firewall rules reflect this. No outbound traffic filtering.

We have access to passwords for both root and student users on the machine.

There is another network on a different interface with a Windows Server 2016 that has **network shares** available. 

We want to interact with the new Server from our Kali box, pivoting through the Linux client. That way we don't have to move tools to Linux client then move them again to the Win Server.

We will utilize *Port-Forwarding* using **ssh -L**, SSH's local port forwarding feature. 

Syntax:
`ssh -N -L [bind_address:]port:host:hostport [username@address]`

We know we want to forward port 445 (Windows networking without NetBIOS) on our Kali machine to 445 on Win Serv. Any microsoft file sharing queries directed at our Kali machine will be forwarded to the Win Serv target.

Being that the firewall and Linux Client are ONLY allowing TCP 22, 3389 and 8080 inbound and outbound, the way around this is to tunnel through an SSH session on our Linux Client on port 22, which can get through the firewall. The request will hit our Kali machine on port 445 and be forwarded across the SSH session, then passed on to port 445 on the Win Serv.

![5847ff74154dc7cd8c7ccdbceb70c605.png](../../../../../_resources/5847ff74154dc7cd8c7ccdbceb70c605.png)

### Execution
Kali>
`sudo ssh -N -L 0.0.0.0:445:192.168.1.110:445 student@10.11.0.128`
**-N** Don't actually issue any SSH commands
**-L** Port Forward
**0.0.0.0:445** Bind FROM port 445 on our local machine
**192.168.1.110:445** Bind TO port 445 on the Windows Server
**student@10.11.0.128** Bind THROUGH Linux Client, logging in as Student

Any incoming connection on the Kali linux box on TCP port 445 will be forwarded to TCP 445 on the Win Serv, passing through the Compromised Linux Client.

Before testing, we need to make a change to the Samba config file to set minimum SMB version to SMBv2 by adding **min protocol = SMB2**, since Win Serv 2016 no longer supports SMBv1 be default:
`sudo nano /etc/samba/smb.conf`
```
...
Please note that you also need to set appropriate Unix permissions
# to the drivers directory for these users to have write rights in it
; write list = root, @lpadmin
min protocol = SMB2
```
`sudo /etc/init.d/smbd restart`


### Testing
Finally, we will list remote shares on the Win Serv by pointing the request at our Kali machine using **smbclient** and providing either an IP or a NetBIOS name.

`smbclient -L 127.0.0.1 -U Administrator`
**-L 127.0.0.1** Use our local machine
**-U Administrator** Remote username 

We will be presented with available shares.




