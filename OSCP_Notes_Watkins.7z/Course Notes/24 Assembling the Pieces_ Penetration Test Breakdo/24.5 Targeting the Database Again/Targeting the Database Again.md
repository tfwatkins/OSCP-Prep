Now that we have root creds for Zora's MariaDB instance, we will try the UDF exploit again with a higher perm level. 

