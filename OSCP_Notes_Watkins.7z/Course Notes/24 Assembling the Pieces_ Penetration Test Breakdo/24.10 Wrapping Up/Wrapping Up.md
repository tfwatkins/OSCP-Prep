Started with hostname and basic target info.

Obtained access to WP web server and this allowed us to compromise a DB.

DB gave us a foothold on internal network where we were able to obtain access to a user's workstation. 

Did PrivEsc on user and obtained info about domain.

Used internal access to gain foothold on Jenkin's Dev Server.

Escalated privs on Jenkins, found domain admin was also logged in.

Impersonated domain admin to create a new Domain Admin and log into DC.

As always, very important to take notes and remove any exploits or shells created.