What we know:
- Ajla connects to the internal network via DB server Zora.
- Within internal network, a share is mounted to Zora from another computer named Poultry.
- We believe Poultry is running windows (part of domain), but unsure. 
- We found creds for a user within the sandbox domain, meanining there should be a DC somewhere on the network.

Before attempting to discover creds, we will first enumerate Poultry to discover what our next step should be.