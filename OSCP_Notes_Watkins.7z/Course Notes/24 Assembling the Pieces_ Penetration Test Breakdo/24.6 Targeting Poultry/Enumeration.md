We assume Poultry is running windows due to the existence of a Domain Name. Lets confirm via nmap.

