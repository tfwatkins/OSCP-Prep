To scan this box with nmap, we will have to use ProxyChains. 

Scanning with ProxyChains is quite slow, so we will only use the top 20 ports and expand scope if required. 

***
You can speed up network scanning through proxychains by modifying the timeout via the tcp_read_time_out and tcp_connect_time_out values in /etc/proxychains.conf. However, don’t set these too low or you will receive incorrect results.
***

Nmap scan with ProxyChains:
kali >
`proxychains nmap --top-ports=20 -sT -Pn 10.5.5.20`
**proxychains** scan with proxychains
**--top-ports=20** only scan the top 20 ports
**-sT** Connect scan (Required by SOCKS proxy)
**-Pn** SOCKS proxies require a TCP connection, so disable ICMP pinging
```
Nmap scan report for 10.5.5.20
Host is up (1.4s latency).
PORT STATE SERVICE
21/tcp closed ftp
22/tcp closed ssh
23/tcp closed telnet
25/tcp closed smtp
53/tcp closed domain
80/tcp closed http
110/tcp closed pop3
111/tcp closed rpcbind
135/tcp open msrpc
139/tcp open netbios-ssn
143/tcp closed imap
443/tcp closed https
445/tcp open microsoft-ds
993/tcp closed imaps
995/tcp closed pop3s
1723/tcp closed pptp
3306/tcp closed mysql
3389/tcp open ms-wbt-server
5900/tcp closed vnc
8080/tcp closed http-proxy
```

Findings:
- 135, 139, 445 and 3389 are open.
- 53 is closed, which is commonly open on DCs.

Ports strongly indicate a windows machine, but it's most likely not the DC.

We see and RDP (TCP 3389) is open. Lets try logging in with our discovered creds.
