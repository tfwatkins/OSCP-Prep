Web apps frequently have a DB config'd on another server as is the case with sandbox.local.

However, at this point we have network access to the DB host and for the most part can treat it as if we are on teh same network.  

As is always the case with tunnels... expect some lag.

