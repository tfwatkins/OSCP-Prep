Use does have perms for SELECT, INSERT, UPDATE and DELTE.. but the wp user is missing FILE perms to run **dumpfile**. 

We need higher access like root. 

We cannot move forward exploiting Zora with the current approach.

First option is to go back to Ajla to see if we can find root (or similar) MariaDB creds.