When looking for creds.. think like an admin or developer. 

Where would you store them? How would they be used? Log or history files where they could be accidentally saved?

Example:
- User accidentally attempts server login with pw in uname field. 
	- Logged in /var/log/auth.log

We start by looking in /etc/passwd, /etc/group and /etc/shadow to get a feel for how many users and groups have access to target.

Sadly, only useful piece of info is that a user named "ajla" exists. 

Lets look at the users home directory:
root@ajla:~#
`cd /home/ajla`
`ls -alh`
```
total 32K
drwxr-xr-x 3 ajla ajla 4.0K Dec 10 16:37 .
drwxr-xr-x 3 root root 4.0K Dec 10 16:22 ..
-rw------- 1 ajla ajla 15 Dec 10 16:40 .bash_history
-rw-r--r-- 1 ajla ajla 220 Oct 15 17:49 .bash_logout
-rw-r--r-- 1 ajla ajla 3.7K Oct 15 17:49 .bashrc
drwx------ 2 ajla ajla 4.0K Oct 15 17:52 .cache
-rw-r--r-- 1 ajla ajla 675 Oct 15 17:49 .profile
-rw-r--r-- 1 ajla ajla 0 Oct 15 17:57 .sudo_as_admin_successful
```

Not much.. but lets look at bash.history:
`cat ./.bash_history`
sudo poweroff

Interesting. Fairly empty history means account is rarely used. 

Server MUST have been administered somehow but we don't see any other users on system. 

Check root user's history:
`cat ~/.bash_history`
```
pwd
ls
cd /var/log/apache2/
tail -f error.log
tail -f access.log
mysql -u root -pBmDu9xUHKe3fZi3Z7RdMBeb -h 10.5.5.11 -e 'DROP DATABASE wordpress;'
cd /etc/mysql/
ls
cd ~/
ls
ls -alh
exit
```

Perfect. root user was used to do admin on Ajla and at one point, MySQL client was used to drop the "wordpress" DB. Luckily, the uname and pw were dropped directly into the command line!



