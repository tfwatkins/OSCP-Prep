Goal:
- Find something that will give us higher levels of access to Zora's MariaDB service.

We could try to continue enumerating Ajla with our current user "www-data", but something with a higher perm level might be very helpful. 

We will first concentrate our enum on priv esc, them move back to looking for creds. 

To look for a priv esc vector, we will go back to our Meterpreter shell on Ajla. 