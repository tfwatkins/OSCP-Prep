Start by looking at the Document-Object Model (DOM). We will also look at the HTML source code as it may differ from the DOM.

View DOM:
Right click on the login page -> "Inspect Element"
Right click on top HTML tag and select "Expand All"

Looks like a basic HTML form.

Review Source:
Right click and select "View Source"

It's possible for JS to alter the DOM, but the source and DOM look fairly similar here.

Next, we will run **dirb** to discover potential hidden files. Jenkins will respond with a 403 for any file we try to access when we are not logged in. We will run scan with **-w** to continue scanning past warnings:
Kali>
`proxychains dirb http://10.5.5.25:8080/ -w`

Our scan found some endpoints but nothing of value.

Next, we will use a little hacker intuition and enter some common creds. Weak PW configs are failry common in internal networks as only trusted users are expected to be able to access these servers. 

Additionally, trying a "few" pw combos will rarely set off alarms and regualr users do this all the time.

We try:
- admin:password (failed)
- admin:admin (success!)

Nice! now we need to find a way to exploit Jenkins to get a shell. 
