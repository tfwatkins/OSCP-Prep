Jenkins is pretty cool. It does a variety of nifty Software Development and Deployment things, meaning it has the ability to execute system commands. This is ideal was it will likely provide us a path to RCE.

Let's enumerate.