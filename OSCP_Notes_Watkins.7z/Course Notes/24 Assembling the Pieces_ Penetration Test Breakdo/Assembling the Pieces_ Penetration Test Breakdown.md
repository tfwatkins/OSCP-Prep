Goal of a pentest should be tailored to the client's data infrastructure and business model. 

In most (but not all) cases, Domain Admin access will allow us to accomplish any objective. 

Inital Taget:
sandbox.local

### etc/hosts
***
This domain is accessible via the PWK VPN but requires us to add an entry to our
/etc/hosts file. First, we’ll make a backup of the existing file by copying
/etc/hosts to hosts.orig in our home directory. Now we’ll append an entry that
will allow us to contact the domain via its DNS name by running sudo bash -c
" echo ‘10.11.1.250 sandbox.local’ >> /etc/hosts". With that set, we
can continue.
***


