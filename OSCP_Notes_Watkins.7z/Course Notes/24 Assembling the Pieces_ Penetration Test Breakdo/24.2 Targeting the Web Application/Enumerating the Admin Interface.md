Before we start exploring access elevation, lets investigate WP itself.

OS and DB Information:
Tools -> Site Health

Findings:
- Server: Linux 4.4.0-21-generic x86_64
- 	Apache/2.4.18 (ubunutu)
- PHP: 7.0.33-0ubunutu0.16.04.7
- DB: mysqli, 10.3.20-MariaDB
- DB Host: WP, 10.5.5.11

Now we can attempt to elevate access with WP plugings. 

WP plugins are writting in PHP and don't have many limitations. 

One plugin is **seclists**.

Install:
`sudo apt install seclists`

Listing seclists WP web shells:
`cd /usr/share/seclists/Web-Shells/WordPress`
`ls`

Examining the webshell **plugin-shell.php**. 

It's a fairly basic webshell that takes in user input into a $cmd variable. The program looks for the cmd variable and pushes it into an execution function that checks for the existence of various APIs to run the user input command. Has a few other neat features like an attempt at deletion protection.