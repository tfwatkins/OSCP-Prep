First step is to simply visit the web page in browser:
`http://sandbox.local`

Findings:
- Links in nav bar all point to anchors on home page
- Survery asking for feedback
- No other field for user-controlled input

Nmap returned WordPress 5.3, but this MUST be confirmed with deeper enumeration.

WordPress core has vulns, but is quickly patched. Themes and plugins however have MANY vulns that are often either improperly or NEVER patched.