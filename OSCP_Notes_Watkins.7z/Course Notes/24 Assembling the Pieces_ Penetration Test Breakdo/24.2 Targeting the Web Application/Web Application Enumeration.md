Basic directory brute force:
`dirb http://sandbox.local`

```
...
---- Scanning URL: http://sandbox.local/ ----
+ http://sandbox.local/index.php (CODE:301|SIZE:0)
+ http://sandbox.local/server-status (CODE:403|SIZE:278)
==> DIRECTORY: http://sandbox.local/wp-admin/
==> DIRECTORY: http://sandbox.local/wp-content/
==> DIRECTORY: http://sandbox.local/wp-includes/
+ http://sandbox.local/xmlrpc.php (CODE:405|SIZE:42)
---- Entering directory: http://sandbox.local/wp-admin/ ----
+ http://sandbox.local/wp-admin/admin.php (CODE:302|SIZE:0)
==> DIRECTORY: http://sandbox.local/wp-admin/css/
==> DIRECTORY: http://sandbox.local/wp-admin/images/
==> DIRECTORY: http://sandbox.local/wp-admin/includes/
+ http://sandbox.local/wp-admin/index.php (CODE:302|SIZE:0)
==> DIRECTORY: http://sandbox.local/wp-admin/js/
==> DIRECTORY: http://sandbox.local/wp-admin/maint/
==> DIRECTORY: http://sandbox.local/wp-admin/network/
==> DIRECTORY: http://sandbox.local/wp-admin/user/
---- Entering directory: http://sandbox.local/wp-content/ ----
+ http://sandbox.local/wp-content/index.php (CODE:200|SIZE:0)
==> DIRECTORY: http://sandbox.local/wp-content/plugins/
==> DIRECTORY: http://sandbox.local/wp-content/themes/
==> DIRECTORY: http://sandbox.local/wp-content/upgrade/
==> DIRECTORY: http://sandbox.local/wp-content/uploads/
---- Entering directory: http://sandbox.local/wp-includes/ ----
(!) WARNING: Directory IS LISTABLE. No need to scan it.
(Use mode '-w' if you want to scan it anyway)
---- Entering directory: http://sandbox.local/wp-admin/css/ ----
(!) WARNING: Directory IS LISTABLE. No need to scan it.
(Use mode '-w' if you want to scan it anyway)
...
-----------------
END_TIME: Mon Dec 9 13:00:40 2019
DOWNLOADED: 32284 - FOUND: 12
```

Findings:
- Common wordpress directories:
	- wp-admin
	- wp-content
	- wp-includes

We need a more specific scan, **WPScan** uses a DB of known WP vulns:
`wpscan --url sandbox.local --enumerate ap,at,cb,dbe`
**--url** Target url
**--enumerate** Configure enumeration options:
- **ap** All Plugins
- **at** All Themes
- **cb** Config Backups
- **dbe** Db exports
```
...
[i] Plugin(s) Identified:

[+] elementor
| Location: http://sandbox.local/wp-content/plugins/elementor/
| Last Updated: 2019-12-08T17:19:00.000Z
| [!] The version is out of date, the latest version is 2.7.6
|
| Found By: Urls In Homepage (Passive Detection)
|
| Version: 2.7.4 (100% confidence)
| Found By: Query Parameter (Passive Detection)
| - http://sandbox.local/wpcontent/
plugins/elementor/assets/css/frontend.min.css?ver=2.7.4
| - http://sandbox.local/wpcontent/
plugins/elementor/assets/js/frontend.min.js?ver=2.7.4
| Confirmed By: Readme - Stable Tag (Aggressive Detection)
| - http://sandbox.local/wp-content/plugins/elementor/readme.txt

[+] ocean-extra
| Location: http://sandbox.local/wp-content/plugins/ocean-extra/
| Last Updated: 2019-11-13T16:17:00.000Z
| [!] The version is out of date, the latest version is 1.5.19
|
| Found By: Urls In Homepage (Passive Detection)
|
| Version: 1.5.16 (100% confidence)
| Found By: Readme - Stable Tag (Aggressive Detection)
| - http://sandbox.local/wp-content/plugins/ocean-extra/readme.txt
| Confirmed By: Readme - ChangeLog Section (Aggressive Detection)
| - http://sandbox.local/wp-content/plugins/ocean-extra/readme.txt

[+] wp-survey-and-poll
| Location: http://sandbox.local/wp-content/plugins/wp-survey-and-poll/
| Last Updated: 2019-10-15T10:32:00.000Z
| [!] The version is out of date, the latest version is 1.5.8.2
|
| Found By: Urls In Homepage (Passive Detection)
|
| Version: 1.5.7.3 (50% confidence)
| Found By: Readme - ChangeLog Section (Aggressive Detection)
| - http://sandbox.local/wp-content/plugins/wp-survey-and-poll/readme.txt
[+] Enumerating All Themes (via Passive and Aggressive Methods)
...
```

Findings:
- Three plugins installed:
	- elementor
	- ocean-extra
	- wp-survery-and-poll

WPScan has a vuln database tool, but it requires registration. We won't use this, since it's only 3 findings and we don't want to register. Just use searchsploit:
`searchsploit -update`
`searchsploit elementor`
Exploits: No Result
`searchsploit ocean-extra`
Exploits: No Result
`searchsploit wp-survey-and-poll`
Exploits: No Result

No results. Lets refine the search:
`searchsploit ocean`
Plenty of results.. but none pertaining to WP.

`searchsploit survey poll`
```
------------------------------------------------------ -------------------------------
Exploit Title | Path (/usr/share/exploitdb/)
------------------------------------------------------ -------------------------------
MD-Pro 1.083.x - Survey Module 'pollID' Blind SQL Inj | exploits/php/webapps/9021.txt
PHP-Nuke CMS (Survey and Poll) - SQL Injection | exploits/php/webapps/11627.txt
Pre Survey Poll - 'catid' SQL Injection | exploits/asp/webapps/6119.txt
WordPress Plugin Survey and Poll 1.1 - Blind SQL Inje | exploits/php/webapps/36054.txt
Wordpress Plugin Survey & Poll 1.5.7.3 - 'sss_params' | exploits/php/webapps/45411.txt
nabopoll 1.2 - 'survey.inc.php?path' Remote File Incl | exploits/php/webapps/3315.txt
---------------------------------------------------------------- ---------------------
```


The fourth and fifth result seem to be for our WordPress plugin. The fifth result, titled “Wordpress Plugin Survey & Poll 1.5.7.3”, also matches the version of our plugin (1.5.7.3) that was found by WPScan.

Let's review the exploit:
`cat /usr/share/exploitdb/exploits/php/webapps/45411.txt`

Exploit doesn't metntion if further auth is required. It does mention a cookie needs to be set.

Let's review the plugin website for more info:
Google: “Wordpress Survey & Poll”
We found a similar survey on the home page of sandbox.local.

Let’s open up Burp Suite, configure the proxy settings in Firefox, and intercept the
communications when we interact with the survey.

Load up page and set Burp to intercept. Click one of the options of the surever, and the request will be captured in Burp. Click *forward* to continue the page load.

When we reload the page, we will see *wp_sap=\<cookievalue>*, which is mentioned as being vulnerable in the exploit code. With this cookie we can attempt to exploit the SQL vuln.

