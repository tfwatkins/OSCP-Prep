What we know:
- Ajla is in the external network behind one firewall
- Zora and Poultry are behind another firewall in the internal network, but we don't konw what the internal net looks like as a whole

Let's scan.

Running a full port scan is not going to effective. ICMP host discovery will NOT work through a proxychains tunnel. 

Instead, we can attempt to disocver what host exist using compromised WIndows host.

We will write a quick one liner to ping every possible host on the network w/ a for loop:
C:\Users\poultryadmin>
`for /L %i in (1,1,255) do @ping -n 1 -w 200 10.5.5.%i > nul && echo 10.5.5.%i is up.`
**for /L %i in (1,1,255)** Loop with replaceable parameter in form (start, step, end)
**-n 1** Single ping per host
**-w 200** short timeout
**> nul** output of ping to nul for tidy results
```
10.5.5.1 is up.
10.5.5.11 is up.
10.5.5.20 is up.
10.5.5.25 is up.
10.5.5.30 is up.
```

Findings:
- 5 hosts
- 5.1 is gateway, ignore for now
- 5.11 and 5.20 are already compromised
- Two new hosts to scan

Nmap scan top 1000 on two hosts:
Kali>
`proxychains nmap --top-ports=1000 -sT -Pn 10.5.5.25,30 --open`
```
Nmap scan report for 10.5.5.30
Host is up (0.80s latency).
Not shown: 988 closed ports
PORT STATE SERVICE
53/tcp open domain
88/tcp open kerberos-sec
135/tcp open msrpc
139/tcp open netbios-ssn
389/tcp open ldap
445/tcp open microsoft-ds
464/tcp open kpasswd5
593/tcp open http-rpc-epmap
636/tcp open ldapssl
3268/tcp open globalcatLDAP
3269/tcp open globalcatLDAPssl
3389/tcp open ms-wbt-server

Nmap scan report for 10.5.5.25
Host is up (0.80s latency).
Not shown: 996 closed ports
PORT STATE SERVICE
135/tcp open msrpc
139/tcp open netbios-ssn
445/tcp open microsoft-ds
8080/tcp open http-proxy
```
