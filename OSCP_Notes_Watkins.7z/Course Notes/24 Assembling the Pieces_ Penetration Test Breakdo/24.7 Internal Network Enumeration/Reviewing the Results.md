### Reviewing 10.5.5.30:

This appears to be the DC for sandbox.local. 
We see port 53, and a variety of LDAP services. 

Let's do a deeper scan on these open ports using nmap scripts:
kali@kali:~/poultry$
`proxychains nmap - p53,88,135,139,389,445,464,593,636,3268,3269,3389 -sC -sT -Pn 10.5.5.30`

```
PORT STATE SERVICE
53/tcp open domain
88/tcp open kerberos-sec
135/tcp open msrpc
139/tcp open netbios-ssn
389/tcp open ldap
445/tcp open microsoft-ds
464/tcp open kpasswd5
593/tcp open http-rpc-epmap
636/tcp open ldapssl
3268/tcp open globalcatLDAP
3269/tcp closed globalcatLDAPssl
3389/tcp open ms-wbt-server
| rdp-ntlm-info:
| Target_Name: sandbox
| NetBIOS_Domain_Name: sandbox
| NetBIOS_Computer_Name: SANDBOXDC
| DNS_Domain_Name: sandbox.local
| DNS_Computer_Name: SANDBOXDC.sandbox.local
| DNS_Tree_Name: sandbox.local
| Product_Version: 10.0.14393
|_ System_Time: 2019-12-12T10:36:29+00:00
| ssl-cert: Subject: commonName=SANDBOXDC.sandbox.local
| Not valid before: 2019-11-25T06:48:49
|_Not valid after: 2020-05-26T06:48:49
|_ssl-date: 2019-12-12T10:36:28+00:00; +8h00m01s from scanner time

Host script results:
|_clock-skew: mean: 9h36m01s, deviation: 3h34m42s, median: 8h00m00s
| smb-os-discovery:
| OS: Windows Server 2016 Standard 14393 (Windows Server 2016 Standard 6.3)
| Computer name: SANDBOXDC
| NetBIOS computer name: SANDBOXDC\x00
| Domain name: sandbox.local
| Forest name: sandbox.local
| FQDN: SANDBOXDC.sandbox.local
|_ System time: 2019-12-18T10:08:27-08:00
| smb-security-mode:
| account_used: <blank>
| authentication_level: user
| challenge_response: supported
|_ message_signing: required
| smb2-security-mode:
| 2.02:
|_ Message signing enabled and required
| smb2-time:
| date: 2019-12-12T10:36:38
|_ start_date: 2019-12-11T12:02:08
Nmap done: 1 IP address (1 host up) scanned in 67.55 seconds
```

Findings:
- DC seems a newer build: WinServ 2006
- Does not seem to be running any services other than those intended for a DC

Possibly vulnerable through specific vulns.. but highly unlikely as DCs are usually fairly hardened.

### Reviewing 10.5.5.25:

Nmap Scripts:
kali@kali:~/poultry$
`proxychains nmap -p135,139,445,8080 -sC -sT -Pn 10.5.5.25`
```
PORT STATE SERVICE
135/tcp open msrpc
139/tcp open netbios-ssn
445/tcp open microsoft-ds
8080/tcp open http-proxy
| http-robots.txt: 1 disallowed entry
|_/
|_http-title: Site doesn't have a title (text/html;charset=utf-8).
Host script results:
|_clock-skew: mean: 2h40m01s, deviation: 4h37m11s, median: -1s
| smb-os-discovery:
| OS: Windows 10 Pro 15063 (Windows 10 Pro 6.3)
| OS CPE: cpe:/o:microsoft:windows_10::-
| Computer name: CEVAPI
| NetBIOS computer name: CEVAPI\x00
| Domain name: sandbox.local
| Forest name: sandbox.local
| FQDN: CEVAPI.sandbox.local
|_ System time: 2020-01-01T15:03:40-08:00
| smb-security-mode:
| account_used: guest
| authentication_level: user
| challenge_response: supported
|_ message_signing: disabled (dangerous, but default)
| smb2-security-mode:
| 2.02:
|_ Message signing enabled but not required
| smb2-time:
| date: 2020-01-01T23:03:37
|_ start_date: 2020-01-01T22:07:03
Nmap done: 1 IP address (1 host up) scanned in 19.77 seconds
```

Findings:
- Target named "Cevapi"
- Running Win10 Pro
- 8080 is open with an HTTP-proxy service running on it

We can gather more info on the web page, but we need to configure Firefox to use our SOCKS proxy.

Open Firefox preferences and search "proxy".

The “Use this proxy server for all protocols” option should be unchecked and the SOCKS host must be set to 127.0.0.1 with the port of 1080. Finally, we will click the SOCKS v4 radio button and click OK.

Open a new tab and visit http://10.5.5.25:8080.

We are presented with a Jenkins login page. Jenkins is a powerful piece of software that might expose some attack surface.


