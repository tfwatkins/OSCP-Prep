We now need to use impersonation to obtain access to the DC on 10.5.5.30.



