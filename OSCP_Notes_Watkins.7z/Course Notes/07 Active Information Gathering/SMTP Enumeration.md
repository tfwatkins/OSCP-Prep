Simple Mail Transport Protocol (SMTP)

Supports several interesting commands:
*VRFY*- Request asking the server to verify an email address
*EXPN*- Asks server for the membership of a mailing list

These can often be abused to verify exisiting users on a mail server:

`nc -nv 10.11.1..217 25` Scan for and open SMTP port
```
(UNKNOWN) [10.11.1.217] 25 (smtp) open
220 hotline.localdomain ESMTP Postfix
```
`VRFY root`
```
252 2.0.0 root
```
`VRFY idontexist`
```
550 5.1.1 <idontexist>: Recipient address rejected: User unknown in local recipient
table
```

Since we  receive feedback one way or the other, we can automate this task with a python script to guess valid usernames:

```
#!/usr/bin/python
import socket
import sys

if len(sys.argv) != 2:
	print "Usage: vrfy.py <username>"
	sys.exit(0)

# Create a Socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the Server
connect = s.connect(('10.11.1.217',25))

# Receive the banner
banner = s.recv(1024)

print banner

# VRFY a user
s.send('VRFY ' + sys.argv[1] + '\r\n')
result = s.recv(1024)

print result

# Close the socket
s.close()

```