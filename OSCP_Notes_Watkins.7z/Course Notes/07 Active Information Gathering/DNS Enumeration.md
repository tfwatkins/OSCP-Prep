*DNS recursor*- First server in chain. Interacts with DNS infrastructure and returns results to DNS client  Contacts one of the servers in the *DNS root zone*. Root server responds with the address of the server responsible for the zone containing the TLD (usuall .com).

Once the recursor gets the address of the *Top Level Domain (TLD) DNS server*, it queries it for the address of the *authoritative nameserver* for the queried domain. The *Authoritative Name Server* is the final step and contains the DNS records in a local database known as a *zone file*. Typically two zones: forward and reverse lookup zones. 

*DNS Caching* is used to store local copies of DNS records to speed up the lookup process. Domain owners can control how long DNS records are cached with the TTL field of a DNS record.

# Interactive with a DNS Server
Common DNS Record Types:
- NS- Name Server records contain the name of authoritative servers hosting DNS records for the domain. 
- A- host record. Contains IP of hostname. 
- MX- Mail Exchange. servers for handling mail. A domain may have multiple. 
- PTR- Pointer records used for reverse lookups
- CNAME- Canonical Name Records used to create aliases to other host records. 
- TXT- Text records contain arbitrary data such as domain ownership verfication. 

`host www.megacorpone.com` Finds the A host record (default)
`host -t mx www.megacorpone.com` finds MX records
`host -t txt www.megacorpone.com` find TXT records

# Automating Lookups
If you query and invalid hostname,  you will get an (NXDOMAIN) indicating that a public DNS record does not exist. 

ex.
`host idontexist.megacorpone.com`
```
host idontexist.megacorpone.com not found: 3(NXDOMAIN)
```

## Forward Lookup Brute Force
We can utilize a custom wordlist to bruteforce hostnames.

**list.txt:**
www
ftp
mail
owa
proxy
router

`for ip in $(cat list.txt); do host $ip.megacorpone.com; done` Utilizing a for loop and replacing the hostname with words from our list
***
Much more comprehensive wordlists are
available as part of the SecLists project.190 These wordlists can be installed to the
/usr/share/seclists directory using the sudo apt install seclists command.
***

## Reverse Lookup brute force
`for ip in $(seq 50 100); do host 38.100.193.$ip; done | grep -v "not
found"` Replace the 1st octet with numbers 50-100 and "grep out"  the not found items with **-v**

# DNS Zone Transfers

A database replication between related DNS servers in which the *Zone File* is copied from the Master DNS server to a Slave server. 

This should ONLY be allowd to an authorized Slave DNS Server, but this is a common misconfiguration. 

`host -l <domain name> <dns server address>` DNS Zone Transfer with host

`host -t ns megacorpone.com | cut -d " " -f 4` Using host to cut out the DNS servers for a given domain

We can create a script to automate the process of finding relevant nameservers and attempting to Zone transfer each:

```
#!/bin/bash
# Simple Zone Transfer Bash Script
# $1 is the first argument given after the bash script
# Check if argument was given, if not, print usage

if [ -z "$1" ]; then
	echo "[*] Simple Zone transfer script"
	echo "[*] Usage : $0 <domain name> "
	exit 0
fi

# if argument was given, identify the DNS servers for the domain

for server in $(host -t ns $1 | cut -d " " -f4); do

	# For each of these servers, attempt a
	zone transfer
	host -l $1 $server |grep "has address"
	
done
```

`chmod +x dns-axfr.sh` Make script executable
`./dns-axfr.sh megacorpone.com` Run 

## Relevant Tools in Kali Linux
Several tools can automate DNS Enumeration

### DNS Recon
Advanced, modern DNS enumeration script written in Python. 

`dnsrecon -d megacorpone.com -t axfr`
**-d** specify a domain name
**-t** specify enumeration type (axfr for zone transer)

You can also brute force:
`dnsrecon -d megacorpone.com -D ~/list.txt -t brt` 
**-D** Specify a filename containing potential subdomain strings
**-t brt** brute force enumeration

### DNSenum
`dnseum zonetransfer.me` Example run against a site setup for practicing zonetransfers.