The process of inspecting TCP and/or UDP ports to detect services and potential attack vectors.

***
Port Scanning may not be legal depending on target and jurisdiction. Don't do it unless you OWN the network or have some type of permission.

More specifically, it is prohibited by almost all ISPs and a heavy scan **could** in theory crash a service/box.. which could definitely be seen as an attack, thus illegal. 

Tread Lightly...
***

### Scanning Methodology
A good strategy would be to start scanning for 443 and 80 ONLY, then do full scans on those servers. 

The more specific we can make our heavy scans the lighter the network load, which lowers detection percentages and reduces risk. 


# TCP/UDP Scanning

Netcat is not a port scanner, but it can be used in a rudimentary way.
It is often already present on systems. 

## TCP Scanning

### TCP Connect Scan
SYN
SYN-ACK
ACK

If the handhshake completes successfully, the port is considered "open"

`nc -nvv -w 1 -z 10.11.1.220 3388-3390` nc TCP port scan
**-w 1** timeout in seconds (1)
**-z** zero-I/O mode (no data used for scanning)

## UDP Scanning
UDP is stateless, no 3-way handshake

`nc -nv -u -z -w 1 10.11.1.115 160-162` UDP Scan
**-u** UDP scan
***
Generally (but not always) the application layer will respond to a UDP scan with no response if the port is open. **This also happens when the port is filtered by a firewall.** 

If the port is closed, it should respond with "ICMP Port Unreachable". 
***

### Common UDP Port Scanning Pitfalls
- UDP Scanning is unrealiable: firewalls and routers often drop ICMP packets, leading to false positives
- Many port scanners work of a pre-set list of "interesting ports", no all ports. Using a protocol-specific UDP port scanner may help. 
- Many pentesters forget UDP. Don't do this, plenty of attack vectors are lurking there.

# Port Scanning with Nmap 
Many nmap scans require **sudo**, due to them needing access to *raw sockets*. Without access to sudo, Nmap is limited and falls back on using the standard Berkely socket api. 

## Accountability for our Traffic
Default nmap scan targets 1000 most popular ports. 

We can monitor amount of traffic sent to host using **iptables**:
**-I** insert new rule into a given chain, including **INPUT** (inbound) and **OUTPUT**(outbound) chains followed by the fule number. 
**-s** source IP
**-d** dest ip
**-j** to **ACCEPT** traffic
**-z** zero the packet and byte counters in all chains

Configuring IP tables for the scan
`sudo iptables -I INPUT 1 -s 10.11.1.220 -j ACCPET`
`sudo iptables -I OUTPUT 1 -d 10.11.1.220 -j ACCEPT`
`sudo iptables -Z`

Generate traffic with nmap
`nmap 10.11.1.220` Scanning IP for 1000 most popular TCP ports

Get iptables stats:
`sudo iptables -vn -L` Our scan output ~78KB of traffic 
**-v** verbose output
**-n** numeric output
**-L** list rules present in all chains

Zero the iptable in prep for another scan
`sudo iptables -Z`

scan:
`nmap -p 1-65535 10.11.1.220` Scan ALL tcp ports

Check stats:
`sudo iptables -vn -L` Our scan generated about 4MB of traffic. (4000KB)

***
As a general rule:
A FULL scan of a class C network (254) hosts generates about: 1000MB of traffic
***

Balancing speed/detail is a skill determined by the needs of the scan, the uplink speed and how many hosts (Class A and B are significantly larger).

## Stealth/SYN Scanning
Default scan when no technique is specified and user has raw socket privs. 

Involves sending SYN packets and never completeing the TCP handshake. The SYN-ACK indicates the port is open.

`sudo nmap -sS 10.11.1.220` Stealth/SYN scan

Because no TCP handshake is completed, info is NOT passed to app layer and thus will not appear in any logs. However, modern firewalls WILL still log a failed TCP connection.

## TCP Connect Scanning
When a user DOES NOT have rawsocket privs, nmap wil default to a TCP connect scan. (3 way handshake).  MUCH Slower than a Stealth/SYN scan. This is however a useful scan for scanning via certain types of proxies. 

`nmap -sT 10.11.1.220` Connect Scan

## UDP Scanning
Uses two methods to determine if port is open or closed:
- standard "ICMP Port Unreacheable method" by sending an empty packet to a port
- For common ports like 161 (SNMP) it will send a protocol specific SNMP packet to get a response from an app bound to the port

`sudo nmap -sU 10.11.1.115`

You can also do a combo UDP/SYN Scan for a more complete picture:
`sudo nmap -sS -sU 10.11.1.115`

## Network Sweeping
To deal with large volumes of hosts, or to conserve tetwork traffic, we can probe via *Network Sweeping*. 

Broad scans-> specific scans on hosts of interest

`nmap -sn 10.11.1.1-254` Network "ping" sweep: will send ICMP echo request and other probes and timestamp request to test various ports. 

Nmap allows you to save results in a "greppable" format:
`nmap -v -sn 10.11.1.1-254 -oG ping-sweep.txt`
**-oG** output in "greppable" format

`grep Up ping-sweep.txt | cut -d " " -f 2` grep for "up" hosts and cut the results

We can also sweep specific TCP/UDP ports:
`nmap -p 80 10.11.1.1.-254 -oG web-sweep.txt` 
**-p** probe sweep, often more accurate then a ping sweep

`grep open web-sweep.txt | cut -d " " -f2`

We can also scan multiple IPs, probing for a short list of common ports:
`nmap -sT -A --top-ports=20 10.11.1.1-254 -oG top-port-sweetp.txt` TCP Connect scan for the top twenty TCP ports with the *--top-ports* option. 
**-A** Enable OS version detection, script scanning and traceroute

Top twenty ports determined with:
**/usr/share/nmap/nmap-services** file

## OS Fingerprinting
Attempts to guess OS based on returned packets via TTL, TCP windows sizes, etc. 
NOT 100% accurate. 

`sudo nmap -O 10.11.1.220`
**-O** OS fingerprinting

## Banner Grabbing/Service Enumeration

`nmap -sV -sT -A 10.11.1.220`
**-sV** Service Banners
**-A** service enumeration scripts (and other things)

***
Banners can be modified by sys admins to remove information or mislead attackers 
***

## Nmap Scripting Engine (NSE)
Used to launch user created scripts to automate scanning. 

Scripts located in:
**/user/share/nmap/scripts** directory

`nmap 10.11.1.220 --script=smb-os-discovery` using the NSE to launch a script for SMB service connection and OS discovery

`nmap --script=dns-zone-transfer -p 53 ns2.megacorpone.com` DNS Zone Transfer script

`nmap --script-help dns-zone-transfer`
**--script-help** Get script help

# Masscan
The fastest portscanner in the world.

`sudo apt install masscan`

`sudo masscan -p80 10.0.0.0/8` An example scan to look for port 80 in an entire class A subnet

***
DO NOT DO THIS ON THE PWK Internal Lab Network!! You only have access to certain subnets.
***

`sudo masscan -p80 10.11.1.0/24 --rate=1000 -e tap0 --router-ip 10.11.0.1` Scan a class C subnet with more advanced options
**--rate=1000** desired rate of packet transmission
**-e** raw network interface to use
**--router-ip** specify IP of appropriate gateway




















