SMB has a poor track record but has been updated and improved in parallell with windows OS releases

# Scanning for NetBios Service

Listens on TCP port 139 and several UDP ports.

NetBIOS and SMB (TCP 445) are two seperate protocols. 

NetBIOS is an independent session layer protocol and service allowing hosts on a local network to communicate. 

Modern implementation of SMB can work without NetBIOS, though NetBIOS over TCP (NBT) is required for backwards compatibility and is often enabled together. *This is why enumeration of both services often goes hand-in-hand*.

`nmap -v -p 139,445 -oG smb.txt 10.11.1.1-254` scanning for NetBIOS service.

Alternatively there are specialized tools:
`sudo nbtscan -r 10.11.1.0/24`
**-r** specify originating port as 137, which is used to query NetBIOS NS for NetBIOS names. 

# Nmap SMB NSE Scripts
**/usr/share/nmap/scripts**

`ls -l /usr/share/nmap/scripts/smb*` See all nmap scripts in the directory

`nmap -v -p 139, 445 --script=smb-os-discovery 10.11.1.227` Using NSE to perform OS discovery

We can also check for SMB protocl vulns, and even pass arguments to the script.

`nmap -v -p 139,445 --script=smb-vuln-ms08-067 --script-args=unsafe=1
10.11.1.5`
***
Passing **unsafe=1** will be 100% garunteed to crash vulnerable systems.... don't do this unless required for some reason.
***



