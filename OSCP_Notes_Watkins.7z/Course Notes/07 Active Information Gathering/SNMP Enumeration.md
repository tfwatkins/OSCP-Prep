Simple Network Management Protocol (SNMP) is not well understood by many network admins. Often results in misconfigs resulting in information leakage. 

Based on UDP (stateless), thus susceptible to IP spoofing and replay attacks. Also, SNMP protocols 1, 2 an 2c offer no traffic encryption, leaving info and creds easily intercepted. 

SNMP protocols alos have weak authentication schemes and are commonly left configured with defualt public and private community strings.

Enterprise routing hardware often supports configuration file read and write through private SNMP community string access. Compromising one device may allow access to all the router configs and a network compromise.


# SNMP MIB Tree
The SNMP Management Information Base (MIC) is a database containing network mgmt info. This is organized like a tree:

Branches = different orgs or network functions
Leaves (final endpoints) = specific variable values that can be access/probed by an external user

Ex. Microsoft Windows SNMP Parameters:
![d3a309de26829667b0229bf3a6491610.png](../../../../_resources/d3a309de26829667b0229bf3a6491610.png)
![d9dec81392fbb6e0bd4d4c9b9ac0a04c.png](../../../../_resources/d9dec81392fbb6e0bd4d4c9b9ac0a04c.png)

As you can see, this contains much more than network-based information.

# Scanning for SNMP
`sudo nmap -sU --open -p 161 10.11.1.1-254 -oG open-snmp.txt` UDP scanning for SNMP
**-open** limit output to only open ports

Alternatively we can use a tools such as *onesixtyone*, which will attempt a bruteforce against a list of IP addresses. 

First build a list of community strings and IPs to try. 

`echo public > community`
`echo private >> community`
`echo manager >> commuinity`

`for ip in $(seq 1 254); do echo 10.11.1.$ip; done > ip_list`

`onesixtyone -c community -i ips` Bruteforcing with onesixtyone using our lists
**-c** specify community string list
**-i** specify ip list
```
Scanning 254 hosts, 3 communities
10.11.1.14 [public] Hardware: x86 Family 6 Model 12 Stepping 2 AT/AT COMPATIBLE -
Software: Windows 2000 Version 5.1 (Build 2600 Uniprocessor Free)

10.11.1.13 [public] Hardware: x86 Family 6 Model 12 Stepping 2 AT/AT COMPATIBLE -
Software: Windows 2000 Version 5.1 (Build 2600 Uniprocessor Free)

10.11.1.22 [public] Linux barry 2.4.18-3 #1 Thu Apr 18 07:37:53 EDT 2002 i686
...
```


# Windows SNMP Enumeration Example

Once we find SNMP services, we can start querying them for specific MIB data that might be interesting.

We can probe and query SNMP values using a tool like **snmpwalk**, provided we know the SNMP read-only community string (usually "public").

## Enumerating the Entire MIB Tree

`snmpwalk -c public -v1 -t 10 10.11.1.14` Ennumerating entire tree
**-c** specify community string
**-v** specify version number
**-t** increase timeout period by seconds

## Enumerating Windows Users
`snmpwalk -c public -v1 10.11.1.14 1.3.6.1.4.1.77.1.2.25`

## Enumerating Running Windows Processes
`snmpwalk -c public -v1 10.11.1.73 1.3.6.1.2.1.25.4.2.1.2`

## Enumerating Open TCP Ports
`snmpwalk -c public -v1 10.11.1.14 1.3.6.1.2.1.6.13.1.3`

## Enumerating Installed Software
`snmpwalk -c public -v1 10.11.1.50 1.3.6.1.2.1.25.6.3.1.2`






















