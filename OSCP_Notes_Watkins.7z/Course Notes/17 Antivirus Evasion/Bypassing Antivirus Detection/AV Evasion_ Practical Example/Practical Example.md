Finding a universal solution to bypass all AV products is difficult and timeconsuming, if not impossible. 

Considering time limitations during a pentest, it is more efficient to target a specific AV product deployed on the customers network.

We will install Avira Free AV Version 15.0.34.16 on our Windows 10 client. 

Found in:
C:\Tools\antivirus_evasion\

Once installed, we can check its configuration by searching for “Start Avira Antivirus” in the Windows 10 search bar.

Manually enable "Real-Time Protection" in the AV software.

Transfer the previously made malicious Meterpreter PE to the windows client. Attempt to run it an observer the results. 

AV will pop it.