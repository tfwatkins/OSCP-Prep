Shellter is a dynamic shellcode injection tool. Free. Capable of bypassing AV software. 

Essentially backdoor's a valid, non-malicious exe with malicious shellcode payload. 

Essentailly performs analysis fo target PE file and execution paths. Then determines where it can inject shellcode. Includes chaniging of PE file section permissions, creating new sections, etc.

Finaly, Shellter attempts to use the existing PE IAT (Import address table) entries to locate function sthat will be used for the memory allocation, transfer and exeuction of our payload. 

Let's install and try it out:
`apt-cache search shellter`
`sudo apt install shellter`

Shellter is designed to run on Windows, so we will install *wine*, a compatability layer capable of running w32 apps on several POSIX-compliant OSs.
`apt install wine`

Run it:
`shellter`

Can run in either Auto or Manual mode.

Manual will launch the PE we want to use for injection and allow us to manipulate it on a more granular level. Highly customizable. 

We will use Auto (A at the prompt).

Netxt target a PE. Lets target WinRAR. Shellter will create a backup of the file
PE Target: /home/kali/Desktop/wrar571.exe

Stealth Mode will attempt to restore execution flow of the PE after payload is done.

There is a list of common payloads. Custom payloads MUST terminate by execint the current thread.

Given Avira previously detected our meterpreter PE, lets try it. 

Injection will occur, and test. 

Setup a meterpreter listener on our Kali machine.

Do a scan with Avira, come up clean.

Run the exe. We see that normal WinRAR installation shows, but loking at Kali shows we received a Meterpreter session but it died after the installation was either cancelled or finished.
 This makes sense as the process was terminated.
 
 We will use the AutoRunScript to migrate our meterpreter to a seperate process immediately after session creation. 
 
 msf exploit(multi/handler) >
 set AutoRunScript post/windows/manage/migrate
 exploit.
 
 Now when we run the WinRAR exe, we get a succesful shell. 
 
 