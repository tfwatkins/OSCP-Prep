Unlike regular DLL inejction, (loading a malicious DLL from disk using **LoadLibrary** API), this technique attempts to load a DLL stored by the attacker in the process memory.

Main issue is that LoadLibrary doesn't support loading a DLL from memory. Also the Windows OS doesn't expose any APIs that can handle this feature. 

Attackers who use this technique must write their own version of the API that doesn't rely on a disk-based DLL