Attackers first launch a non-malicious process in a suspended state. 

Once launched, the image of the process is removed from memory and replaced with a malicious exe image. 

Finally the process is then resumed and malicious code is executed.

