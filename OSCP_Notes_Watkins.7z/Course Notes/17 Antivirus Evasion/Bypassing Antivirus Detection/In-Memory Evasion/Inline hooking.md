Involves modifying memory and introducing a 'hook' (instruction that redirects code execution) into a function to point the execution flow to our malicious code.

Upon executing malicious code, flow will return back to the modified function and resume exeuction, appearing as if only the original code had executed.