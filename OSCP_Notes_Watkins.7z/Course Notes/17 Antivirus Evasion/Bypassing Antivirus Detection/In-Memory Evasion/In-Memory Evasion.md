In Memory Injection (PE Injection) is a popular bypass. 

Focuses on manipulating volatile memory. Does not require any files written to disk, where most AV products focus. 

We will only cover powrshell but other techniques rely on C/C++.

