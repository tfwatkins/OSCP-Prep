Attempts to inject a payload into another valid PE that is not malicious. 

Most commonly done leveraging a set of Windows APIs.

First we use the **OpenProcess** function to obtain a valid **HANDLE** to a target process the we have permission to access. 

After obtaining **HANDLE**, we allocate memory in the context of that process by calling Windows API such as **VirtualAllocEx**.

Once memory has been allocated, we would copy melicious payload to the newly allocated memory use **WriteProcessMemory**.

After payload has been copied, it's usually executed in memory in a seperate thread use **CreateRemoteThread** Api.

