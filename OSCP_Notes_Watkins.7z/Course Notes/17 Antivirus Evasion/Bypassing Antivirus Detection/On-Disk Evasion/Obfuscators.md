Reorganize and mutate code, making it difficult to reverse engineer. 

Can replace instructions with semantically equivalent ones, insert "dead code", split and re-order functions, etc.

Primarily used by Software Devs to protect their IP, it is also marginally effective against sig-based AV detections.