Cryptographically alter the exe, adding a decrypting stub that restores code to original on exeuction.

Decryption happens in memory, leaving only the encrypted code on-disk. 

Has become the foundation for modern AV evasion techniques. 

