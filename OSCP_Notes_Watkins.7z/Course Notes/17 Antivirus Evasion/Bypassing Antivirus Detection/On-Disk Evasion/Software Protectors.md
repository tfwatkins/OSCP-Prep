Highly effective AV evasion requires combination of all previous techniques including advanced ones such as anti-reversing, anti-debugging, VM detection and more. 

Software protectors were designed for legitimate purposes but can be used for AV evasion. 

Among commercially available tools, *The Enigma Protector* in particular can
successfully be used to bypass antivirus products.

