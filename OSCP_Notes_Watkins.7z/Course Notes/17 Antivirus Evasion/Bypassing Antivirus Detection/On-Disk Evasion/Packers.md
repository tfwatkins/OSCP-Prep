One of the earliest ways of on-disk obfuscation.

Packers reduce the size of an executable, generating a new exe that is smaller but functionally equivalent. (Unlike generating a ZIP file)

UPX is an example.

This is only effective at getting past older and more simplistic AV scanners.