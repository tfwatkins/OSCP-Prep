Two main categories of evasion:
- On-disk: Focuses on modifying malicious files stores on disk
- In-Memory: Modern malware often attempts to avoid disk completely to reduce the possiblity of being detected.