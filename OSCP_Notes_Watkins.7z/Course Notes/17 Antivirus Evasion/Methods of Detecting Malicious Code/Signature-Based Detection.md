AV Signature- Continuous sequence of bytes within malware that uniquely IDs it.

Considered a "Blacklist" techonology:
Scans filesystem, ID files then quarantines them.

We can bypass SigDetect fairly easily by changing or obfuscating contents fo known malicious files to break the signature (byte sequence.)

Sometimes we can get away with changing a few strings from upper to lowercase.

Different vendors use different techniques, so there really isn't a one-size-fits-all approach. Trial and Error are required.

During a pentest, you should ID the presecne, type and version of the deployed AV software. Ideally replicating the environment as closely as possible and testing AV bypass techniques. 

