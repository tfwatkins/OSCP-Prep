**Heuristic-Based Detection** relies on rules and algorithms to determine if "actions" are considered malicious. 

Often achieved by stepping through the instructions of a binary or by attempting to decompile and analyze source code. 

Looking for patters and program calls that are malicious. 

**Behaviour-Based Detection** dynamically analyzes the behaviour of a file. Often by executing file in an emulated enviroment like a small VM sandbox and looking at behaviour. 

These techniques are more effective for identifiying unknown malware or variations. 

Most AV manufacturers implement some combination of all AV detection techniques.


