Designed to prevent, detect and remove malicious malware. 

Typically includes firewalls, website scanners and more.