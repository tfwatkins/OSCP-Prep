Lateral movement techniques:
`usemodule lateral_movement/technique`

Use *invoke_smbexec* module:
`usemodule lateral_movement/invoke_smbexec`

***
We can use either the set CredID command to specify the ID number of the entry
from the credentials store or manually enter all the credentials. Note that in this
case, the passwords for both Offsec and Jeff_admin coincide.
***

Once we enter the options and execute, we can switch to the active agent and interact.