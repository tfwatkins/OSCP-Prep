List all modules:
`usemodule + [SPACE] + [double TAB]`



