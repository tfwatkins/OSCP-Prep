***
The Active Directory enumeration modules are found in the network subcategory
with a prefix of PowerView. This is a reference to @harmj0y’s original
Veil-PowerView724 project.
***

***
Pay close attention to the syntax in this example. To select a module from the
“empire base prompt”, we include the full path to the module. If we were not at
this base prompt, we would prepend the module path with powershell/.
***

Get_User module information:
`usemodule situational_awareness/network/powerview/get_user`
`info`

- If the NeedsAdmin field is set to “True”, the script requires local Administrator permissions. 
- If the OpsecSafe field is set to “True”, the script will avoid leaving behind indicators of compromise, such as temporary disk files or new user accounts. This stealth-driven approach has a greater likelihood of evading endpoint protection mechanisms.
- The MinLanguageVersion field describes the minimum version of PowerShell required to execute the script. This is especially relevant when working with Windows 7 or Windows Server 2008 R2 targets as they ship with PowerShell version 2.
- Background tells us if the module executes in the background without visibility for the victim, while OutputExtension tells us the output format if the module returns output to a file.


***
The Bloodhound module is especially noteworthy. It automates much of PowerView’s
functionality, collecting all computers, users, and groups in the domain as well as all currently logged-in users. The output is stored in CSV files suitable for use with the backend BloodHound application,725 which uses graph theory726 to highlight often-overlooked and highly complex attack paths in an Active Directory environment.
***