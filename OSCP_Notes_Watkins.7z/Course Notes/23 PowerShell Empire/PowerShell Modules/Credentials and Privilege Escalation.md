**powerup/allchecks** is a useful privesc module- Check for misconfigs.

**bypassuac_fodehlper** is useful if we have acces to a local amdin. Can bypass UAC and launch a high-integrity PS Empire Agent.

Once we have a high-integrity session, we can perform local admin or SYSTEM rights command slike executing Mimikatz to dump creds:

List Mimikatz commands:
`usemodule credentials/`

Note that an asterisk denotes those requiring high-integrity Empire agent.

Empire uses reflective DLL injection to load Mimikatz library into agent directly from memory, thus minimizing risk of detection since most EDR solutions only analyze files stored on the harddrive. 

***
This method is custom-coded into the agent as Windows does not expose any
official APIs (similar to LoadLibrary) that would allow us to achieve the same
objective.
***

Ex.
`usemodule credentials/mimikatz/logonpasswords`
`execute`
`sekurlsa::logonpasswords`

Write collected creds to the *Credential Store*
`creds`

Manually add an entry to the Cred Store:
`creds add corp.com jeff_admin Qwerty09!`