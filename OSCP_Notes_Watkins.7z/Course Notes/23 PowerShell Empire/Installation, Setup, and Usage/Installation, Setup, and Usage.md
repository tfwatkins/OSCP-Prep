Install and setup:
kali>
`cd /opt`
`sudo git clone https://github.com/PowerShellEmpire/Empire.git`
`cd Empire/`
`sudo ./setup/install.sh`

Empire allows for collaboration between penetration testers across multiple servers using shared
private keys and by extension, shared passwords. However, we are installing a single instance, so
we’ll press I at the password prompt to generate a random password.

Launch:
`sudo ./empire`