
Empire is a powershell and python post-exploitation agent with a heavy focus on client-side exploit/post-exploit of AD deployments.

Uses Powershell on windows and python on linux/macOS.

Relies heavily on pre-installed libraries and features. 

PowerShell execution requires only PowerShell version 2 (pre-installed since Windows 7) and Linux and Mac modules require Python 2.6 or 2.7.

***
Historically, PowerShell Empire focused on Windows exploitation, while a separate project, known as EmPyre,720 targeted Mac OS X/macOS and Linux. In the second major release of PowerShell Empire, these projects were merged,
maintaining the original name, often simply referred to as Empire. The PowerShell Empire project is no longer supported by the original developers, but updated forks have been created such as BC-SECURITY.721 The forked version has recently released a version 3.0.722
***