# The Bash Environment

Bash is an sh-compatible shell that incorporates useful features from the KornShell (ksh) and the C Shell (csh).

## Environment Variables
Each new terminal window (a bash process) has it's own **environment variables**.

`echo $PATH` PATH is a colon-seperated list of directory paths that Bash will search when a command is run without a full path.

Other useful env. variables:
`$USER` User's username
`$PWD` Present working directory
`$HOME` Home Directory

`export b=10.11.1.220` Export can be used to define a new env. variable, available to any subproccess
`ping -c 2 $b` Using our previously made variable (the IP address)
`echo "$$"` Display the PID of the current shell instance
`env` Show all environmental variables

## History
`history` view history of commands entered
`!1` Re-run the first command entered (known as history expansion)
`!!` Repeate the last command entered
***
Command history is saved in the .bash_hisory file in the user's home directory. Two variables control the history size:

- HISTSIZE: Controls number of commands stored in memory for current session
- HISTFILESIZE: Configues how many commands are kepy in history file.

Variables can be edited in **.bashrc**
***
`[ctrl+r] c` Used to reverse-i-search command history for commands starting with 'c'.
- Can also navigate with arrow keys.



