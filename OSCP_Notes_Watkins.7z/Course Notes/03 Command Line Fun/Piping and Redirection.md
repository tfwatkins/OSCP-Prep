## Piping and Redirection

3 Data streams-
**STDIN
STDOUT (Defaults to terminal)
STDERR (Defaults to terminal)**

`|` Used to feed output of one program into another
`>` Save output to a file
`<` Input from a file
`>>` Append to a file

## File Descriptors
**STDIN- 0
STDOUT- 1
STDERR- 2**

`ls ./test 2>error.txt` Redirect output of STDERR on the ls command to a txt file.






