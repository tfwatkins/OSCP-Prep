## tail
Most commonly used to monitor log file entries as they are written.
`tail -f /var/log/apache2/access.log` Monitor apache log
**-f** Continously update the output as target file grows
**-nX** outputs last "X" number of lines instead of default 10

## watch
Used to run a designated command at regular interavals. Defualt is every 2 seconds.
`watch -n 5 w` Run the `w` command to monitor logged in users every 5 seconds.
**-n \<time>** Set time interval in seconds