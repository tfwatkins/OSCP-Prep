# 3.4 Editing Files from the Command Line

## Nano
`nano test.txt` Open/create a file
`crtl+0` Write Changes
`ctrl+k` Cut entire line
`ctrl+U` Uncut line and paste
`ctrl+w` Search
`ctrl+x` Exit

## Vi
`vi test.txt` Open/create a file
**Command Mode**
**dd**- delete current line
**yy** - copy current line
**p** - Paste clipboard
**x** - delete current char
**:w** - write file and stay in vi
**q!** - quit without writing
**wq!** - Save and quit

