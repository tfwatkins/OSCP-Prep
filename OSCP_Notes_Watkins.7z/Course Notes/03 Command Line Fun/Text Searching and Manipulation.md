## grep

Seaches text for a regex and output any mathcing line to standard output
**-r** Recursive Searching
**-i** Ignore Text case

`ls -la /usr/bin | grep zip` Search for files with "zip" in the name

## sed

Powerful and complex. Performs text editing on a stream of text: either specific lines or standard output.

`echo "I need to try hard" | sed 's/hard/harder/'` Will replace all occurences of "hard" with "harder".

## cut

Extract text form a line and ouput it to standard output. 
**-f** field number we are cutting
**-d** field delimeter

`echo "I hack binaries, web apps, mobiles apps." | cut -f 2 -d ","` Extract the second filed using a comma delimeter: 
Result:
"web apps"

`cut -d ":" -f 1 /etc/password` Get a list of users (field 1) using the colon as a delimeter

## awk

Programming tool used for text processing and data extraction. Powerful and complex.
**-F** field seperator
**print** outputs results text

`echo "hello::there""friend" | awk -F "::" '{print $1, $3}'` Extract fields using a multi-character seperator
**$n** deisignates field
Result: "hello friend"


