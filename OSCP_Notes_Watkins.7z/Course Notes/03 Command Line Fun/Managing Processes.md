Kernel manages process multitasking. Each process is assigned a process ID (PID).

**Jobs**- The shell considers two processes pipelined together to be a single job. 
ex. `cat error.txt | wc -m`

## Backgrounding Processes (bg)
Appending an **&** at the end a process backgrounds it:
`ping -c 400 localhost > pingresults.txt & `

`ctrl+c` Cancel a job
`ctrl+z` Suspend a job
`bg` resume a supended job
`jobs` Display jobs running in current terminal session
`fg <JobID>` Bring a job to the foreground
***
Ways to represent jobID:
- %number: %1, %2, etc.
- %string: like $ping
- %+ OR %%: Current job
- %-: Previous Job
***

## Process Control: ps and kill
`ps` Process Status- list processes system-wide
**-e** Select all processes
**-f** Display full format listing (UID, PID, PPID, etc.)
**-C** Select command name
`ps -fC leafpad` Show leafpad process

`kill 1307` Kill process with PID of 1307