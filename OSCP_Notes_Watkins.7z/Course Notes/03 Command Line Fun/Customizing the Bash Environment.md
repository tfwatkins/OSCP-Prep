## Bash History Customization
**HISTCONTROL** variable defines whether or not to remove duplicate commands, commands that begin with spaces or both. Default is: both are removed. 

`export HISTCONTROL=ignoredups` Remove duplicates from bash history

**HISTIGNORE** Very useful for filetering out basic commands that are run often like cd and ls. 

`export HISTIGNORE="&:ls:[bf]g:exit:history"` Ignores common listed commands

**HISTTIMEFORMAT** Controls date/time spatmps in output of history command. 

`export HISTTIMEFORMAT='%F %T'` 
**%F** Year-month-day ISO 8601 format
**%T** 24-hour time
Other formats found in `strftime` man page.

## Alias
String that can replace a command name. 
`alias lsa='ls -la'` Creation of an alias for a command with switch options

`unalias lsa` Remove an alias. Useful if you accidentally alias a command with another commands name.

## Persistent Bash Customization
Behavior of interactie shells in Bash is determined by system-wide **bashrc** file located in **/etc/bash.bashrc**. You can override setting by editing the **.bashrc** file in a user's home directory.

An example would be inserting an alias into the **.bashrc** file to keep it persistent. 






