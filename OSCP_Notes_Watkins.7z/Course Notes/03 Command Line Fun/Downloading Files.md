## wget
Downloads files using HTTP/HTTPS and FTP protocols.
`wget -O report.pdf https://www.testpage.com//big_long_report_name.pdf` Gets the requested resource and saves it with a different name by using the **-0** switch.

## curl
Transfers data _to_ or _from_ a server using a host of protocols:
* IMAP/S
* POP3/S
* SCP
* SFTP
* SMB/S
* SMTP/S
* TELNET
* TFTP

`curl -o report.pdf https://www.testpage.com//big_long_report_name.pdf` Download and rename a file with curl

## axel
Download accelerator that tranfers a file from an HTTP or FTP server through multiple connections. 
**-n** Specify number of connections used
**-a** Concise progress indicator
**-o** Specify file output name
`axel -a -n 20 -o report.pdf https://www.testpage.com//big_long_report_name.pdf` Download via axel with 20 connections and rename