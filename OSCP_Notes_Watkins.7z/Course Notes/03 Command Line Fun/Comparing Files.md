## comm
Compares two text files, displaying unique lines  to each one as well as lines they have in common. 

Outputs three spaced-offset columns:
1. Unique lines to first file/argument
2. Lines unique to second file/argument
3. Lines shared by both

**-n** Where n is 1,2 or 3: Supress a column.

`comm -12 test.txt test2.txt` Compare two files and supress columns 1 and 2

# diff
Detect differences between files, simlar to comm but more complex and supports many output formats. 

Most popular formats:
**-c** Context Format
**-u** Unified Format: Does not show lines that match both files, making results shorter.

Output:
"-" Line appears in first file, but not in second
"+" Line appears in second file, but not first

## vimdiff
Opens vim with multiple files with differences between files highlighted. 
Shortcuts:
**do** Gets changes from other window into current window
**dp** puts changes from current into other window
**]c** Jumps to next change
**\[c** Jumps to previous change
`ctrl+w` Switches to other split window
