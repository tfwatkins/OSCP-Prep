The IP addresses of the lab machines are not signficant. For example, you do not need to start
with 10.11.1.1 and work your way through the machines in numerical order. One of the most
important skills you will need to learn as a penetration tester is how to scan a number of
machines in order to find the lowest-hanging fruit. Also, keep in mind that you may not be able to
fully compromise a particular network without first moving into another.