Spending an excessive amount of time cracking the root or administrator passwords of all
machines in the lab is not required. If you have tried all of the available wordlists in Kali, and used
information gathered throughout the labs, stop and consider a different attack vector. If you have
significant cracking hardware, then feel free to continue on to crack as many passwords as you
can.