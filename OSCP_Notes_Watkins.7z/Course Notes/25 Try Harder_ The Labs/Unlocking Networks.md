Initially, the PWK control panel will allow you to revert machines on the Student Network as well
as your own dedicated lab client machines. Certain vulnerable machines in the lab will contain a
network-secret.txt file with a MD5 hash in it. These hashes will unlock additional networks in your
control panel.