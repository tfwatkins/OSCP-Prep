The firewalls and other networking devices that connect the networks together are not directly
exploitable. Although they are in scope and you may attempt to gain access to them, they are not
intentionally created for you to do so. In addition, lengthy attacks such as bruteforcing or
DOS/DDOS are highly discouraged as they will render the firewalls, along with any additional
networks connected to them, inaccessible to you and other students.
A number of machines in the labs have software firewalls enabled and may not respond to ICMP
echo requests. If an IP address does not respond to ICMP echo requests, this does not
necessarily mean that the target machine is down or does not exist.