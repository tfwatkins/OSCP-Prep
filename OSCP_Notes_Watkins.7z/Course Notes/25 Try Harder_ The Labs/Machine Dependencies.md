Some targets can not be exploited without first gathering specific additional information on
another lab machine. Others can only be exploited through a pivot. Student administrators will not
provide details about machine dependencies. Determining whether or not a machine has a
dependency is an important part of the information gathering process, so you’ll need to discover
this information on your own.