The IT, Dev, and Admin networks are not directly routable from the public student network but the
public student network is routable from all other networks. You will need to use various
techniques covered in the course to gain access to the other networks. For example, you may
need to exploit machines NAT’d behind firewalls, leveraging dual-homed hosts or client-side
exploits.