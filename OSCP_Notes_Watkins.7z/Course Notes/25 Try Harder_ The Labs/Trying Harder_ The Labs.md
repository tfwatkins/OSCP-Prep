You have been hired to perform a penetration test on the internal VPN lab network for the
duration of the course. The main objective is to get as many shells on as many machines and
subnets as possible. Your goal is to obtain the highest possible privilege level (administrator/root)
on each machine.
You may alter administrator or root passwords on lab machines as needed or add additional
users to the system, provided you revert the machine back to its pristine state via your student
control panel once you have finished attacking it. Some machines have multiple attack vectors,
so it is highly recommended that you take the time to locate as many as possible. While you may
certainly use web shells to get an initial foothold on a machine, your real goal is a reverse shell
back to your Kali virtual machine or GUI access to the target.
Note: The proof.txt files that are located on each machine are to be documented in your lab
report, should you opt to submit one. These files should not be seen as the end goal (this is a
penetration test, not a capture the flag event). There is no greater feeling than getting highprivileged
shells on lab machines, and you will soon be experiencing that feeling.