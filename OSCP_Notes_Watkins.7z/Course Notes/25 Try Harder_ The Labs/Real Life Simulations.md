The internal VPN lab network contains a number of simulated clients that can be exploited using
client-side attacks. These clients are programmed to simulate common corporate user activity.
Subtle hints throughout the lab can help you locate these simulated clients. Thorough postexploitation
information gathering may also reveal communication between client machines.
The various simulated clients will perform their task(s) at different time intervals. The most
common interval is five minutes.
Some of the lab machines contain clean-up scripts. These are used in client-side attack vectors in
particular to help ensure that the machine/service remains available for use by other students.