# Program Memory

Lowest memory address (0x00000000) to highest (0x7FFFFFFFF)
![6ff9832b440d10e404bcfd28ad354d97.png](../../../../_resources/6ff9832b440d10e404bcfd28ad354d97.png)

There are many important areas of memory, but we will focus on the **Stack**.

## The Stack
When a thread is running, it executes code from within the Program Image or from various DLLs. Threads require short-term data areas for functions, local vars and program control information, which is known as the Stack. To facilititate independing execution of multiple threads, each thread in a running application has it's own stack. 

Stack is viewed by the CPU as LIFO. x86 uses PUSH and POP.

***
Long term, dynamic data storage is done on the **heap**. We will not discuss heap memory in this module.**

### Function Return Mechanics
The return address of functions calls by a thread is stored on the stack, along with the functions parameters and local vars. The collectino of data associated with one function call is stored in a section of stack memory known as a *stack frame*. Ex.
![bce5a1fe6454511dbac582b1db8b42d8.png](../../../../_resources/bce5a1fe6454511dbac582b1db8b42d8.png)

When a function ends, the return address is taken from the stack and exeuction flow is restored back to main or the calling function. 

# CPU Registers

CPU maintains nine, 32-bit registers (on a 32-but platform).

Registers are small, extremely fast CPU storage locations for data reading or manipulation. 
![1e0b8d5ee41c55db715a69d09162db6c.png](../../../../_resources/1e0b8d5ee41c55db715a69d09162db6c.png)

Register names were established for 16-bit architectecture and then extended to 32bit (x86) platform, using the "E" register acronyms. Each register may contain a 32-bit value (0 through 0xFFFFFFFF) or may contain 16-bit or 8-bit values in their sub registers.
![cd0b3cb0325e5390d3a93c0ab82243e5.png](../../../../_resources/cd0b3cb0325e5390d3a93c0ab82243e5.png)

***
Since the purpose of this module is to demonstrate a buffer overflow, we will not
delve into the details of assembly, but will highlight some of the elements that
are important to our specific discussion. For more detail, or to advance beyond
the basic techniques discussed here, refer to these online resources.

296 (Tutorials Point, 2020), https://www.tutorialspoint.com/assembly_programming/
***

Several registers, including EAX, EBX, ECX, EDX, ESI and EDI are often-used as general purpose registers to store temp data. 
297 (SkullSecurity, 2012), https://wiki.skullsecurity.org/Registers

**Primary Registers:**
- EAX (accumulator): Arithmetical and logical instructions
- EBX (base): Base pointer for memory addresses
- ECX (counter): Loop, shift, and rotation counter
- EDX (data): I/O port addressing, multiplication, and division
- ESI (source index): Pointer addressing of data and source in string copy operations
- EDI (destination index): Pointer addressing of data and destination in string copy operations

## ESP- The Stack Pointer
The stack is used for storage of data, pointers and arugments. The stack is dynamic and changes constantly during program execution. The **ESP** (stack pointer) keeps track of the most recently referenced location on the stack (the top) by storing a pointer to it. 

A pointer is a reference to an address (or location) in memory. When we say a
register “stores a pointer” or “points” to an address, this essentially means that
the register is storing that target address.

## EBP- The Base Pointer
Since the stack is in constant flux during thread exeuction, it can become difficult for a function to locate it's own stack frame. the **EBP** (base pointer) stores a pointer to the top of the stack when a function is called. when accessing EBP, a function can easily reference information from it's own stack frame (via offsets) while exeuction. 

## EIP- The Instruction Pointer
**EIP (instruction pointer)** is one of the MOST important registers for our purpose, as it always points to the NEXT code instruction to be executed. EIP directs the flow of the program, and is an attacker's primary target when exploiting any memory corruption vulnerability such as a buffer overflow. 

