Imporoper input santization can lead to a buffer overflow, corrupting data on the stack and leading to a return address overwrite and complete control over the EIP register. 

Controlling EIP is the first step to a buffer overflow. 

# Sample Vulnerable Code
```
#include <stdio.h>
#include <string.h>

//accept arguments from the command line
int main(int argc, char *argv[])
{
//local variable since defined in a function
char buffer[64];
if (argc < 2)
{
printf("Error - You must supply at least one argument\n");
return 1;
}

// if the correct num of inputs are give, take the 2nd and put it into the buffer
strcpy(buffer, argv[1]);
return 0;
}
```
Notes:
- The buffer[] is locally defined (inside a function). As such, the C compiler wil reserver 64 bytes of space for it on the stack, specifically within the *main* function stack frame.
- This is in contrast to global variables that are stored in the program *.data* section.
- the *strcpy()* function is considered insecure, as it allows direct access to the input address with no checks on input size.
- C treats strings a series of chars terminated by a null (\0). 

Notice that the buffer[64] has no check on the size of the input. Anything larger than 64 will overwrite part of the stack adjacent to the target.
![5eedc71c81622addda56a6066cf20e8c.png](../../../../../_resources/5eedc71c81622addda56a6066cf20e8c.png)

The effects of this memory corruption depend on multiple factors including the size of the overflow and the data included in that overflow.  