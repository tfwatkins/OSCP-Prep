# Overflowing the Buffer

The offset between the buffer address (0x0065FE70) and the main function return address is 76 bytes (0x4C in hex). So if we supply 80 'A's as an argument, they will all copy onto the stack and write past the bounds of the assigned buffer into the return address.
![0c192031fb61a552a54870b9eeba2ec6.png](../../../../../_resources/0c192031fb61a552a54870b9eeba2ec6.png)

Continue execution until you see that the stack has been written with all 80 A's. Contunue execution until you hit the RETN function in main. 

We can see that the overwritten return address has been overwritten with "0x41414141" aka "AAAA". This sits at the ESP.

Step in again and the CPU tries to read this next instruction. EIP will be "0x41414141" It's not a valid address in process memory space, so the CPU triggers and access violation and crashes.

The EIP register is used by the CPU to direct code exectuion at the ASM level. Therefore, reliable controllling EIP will allow us to execute any assembly code we want, and eventually shellcode to obtain a reverse shell in the context of a vulnerable application. 

