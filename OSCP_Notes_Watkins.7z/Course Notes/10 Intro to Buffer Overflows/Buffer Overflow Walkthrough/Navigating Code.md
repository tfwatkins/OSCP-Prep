## Navigating Code

Note the word **Paused** in the lower right hand corner. Debugger will automatically pause at the program entry point.

Execute Instructions:
Debug>Step Into (**F7**): Follows execution flow into a given function call
Debug>Step Over (**F8**): Execute entire functino and return from it

The first thing to do is to find the main function location in memory. 

One way to do this is to search for known text from the program, like:
`printf("Error - You must supply at least one argumenr\n");`

**To search:**
R-Click in the Dissasembly window and select *Search for > All referenced text strings*:
Double click the line we are looking for and we are returned to the dissasembly window but inside of main.

We care about the *strcpy* fuinction call itself, so lets place a breakpoint.
Select the line at address: 0x004015AA and press **F2**.
The breakpoint will be highlighted light blue.

Continue flow with Debug>Run (**F9**). We will hit our breakpoint. 

Note **EIP** = 0x004015AA  
**ESP** points to the top of the stack containing the address of the 64-byte buffer where the "AAA" chars will be copied. (dest = 0065FE70).

Step with **F7** x2. We are now in the *strcpy* call.

Monitor the 1st RETURN to strcpy in the stack pane by Double-Clicking it. We now see pos/neg offsets instead of the addresses in the left hand column.

Our array buffer is 64 bytes, which is at offset +40 (hex). Inlucding null terminator. 
Notice various oddities (other returns) at +C, +1C and +2C. This is residual data that is left over since we didnt' intialize our array in the program. Immunity interprets this as input and fills it in. It will be overwritten once the copy is done. 

Notice return address 0x004015AF at the top of the stack. 
This is the return address when strcpy is done, and correlates to a *MOV EAX,0* instruction. This is the instruction immediately following the CALL <JMP.&msvcrt.strcpy> instruction that brought us here, and that CALL instruction pushed this address on the stack automatically for us.

We can let execution continue to the end of the strcpy function with *Debug>Exec till return* or **ctrl+F9**

We can see now that there are twelve 'A's copied to the stack, into the buffer. This indicates we are clearly within the 64byte limit.

***
Make a mental note of the address located at 0x4C ((004013E3) from the buffer variable. This si the main return address, the address of the instrruction we will return to once main has completed execution.
***

Now that all data is copied, the **RETN** instruction will be executed.
The RETN pops the value at the top of the stack (0x004015AF, relative offset -0x20) to the EIP register, instructing CPU to execute code at that location next.

Single Step **F7** and we arrive back at main (0x004015AF) as expected., since this is the next address after strcpy.

The next instrction MOV EAX,0 is equivalent to return 0; sends exit status 0.

Now we have reached main function epilogue. Main wil return execution to first piece of code created by compiler that intially setup and called main. 

Next instruction, LEAVE puts return address at ofset 0x4C onto top of stack. Then the RETN instruction pop main function odress from top of stack and executes code there.

***
The point is that when strcpy copied our input string (12 bytes) onto the stack buffer variable, it started at addres 0x0065FE70 and onwards. **There were not boundary checks in the program**. If we pass a longer strong, enough data will be written to the stack to overwrite the return address of the *main* parent function located at offset 0x4C from the buffer var. This means the EIP will end up under our control as it will contain some of our arugment data when main returns to the parent.