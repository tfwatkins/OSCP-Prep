# Introducing the Immunity Debugger

The debugger allows us to stop execution flow at any time and inspect contents of registers, execute assembly instructions one at a time and execute Python scripts to automate tasks. 

## Launch Immunity
File>Open
Navigate to **c:\Tools\windows_buffer_overflow\\**
Add twelve "A" chars to the *Arguments* field
Open **strcpy.exe**

Immunity will run, but note that it does not set the break point at *main*. It's paused at the *entry point*, which is fairly common. This is a section created to help prepare for execution of the program, like setting up all the arguments that main may expect. 

### Immunity Layout

- Upper Left- Assembly Instructions that make up the app
	- Instruction highlighted in **blue** is the next instruction to be executed with it's address space
- Upper Right- All registers. Note **ESP** and **EIP**. 
	- Note that **EIP** contains the address of the next instruction, which is the same as we see in the top left pane (highlighted in blue).
- Lower Right- The stack and it's contents. Four Columns:
	- 1. Memory address
		- Note that the top of the stack address correlates to the **ESP**
	- 2. Hex data at that address. Displayed as a 32-bit value, called a *DWORD* displayed as four hex bytes.
	- 3. ASCII representing data
	- 4. Dynamic Commentary/additional info about stack entry
- Lower Left- Contents of memory at given address. Helpful while searching for or analyzing specific values in process memory. R-click for different data formats. 3 Columns:
	- 1. Memory Address
	- 2. Hex
	- 3. ASCII

 