Utilizing search functions on sites like GitHub, GitLab and SourceForge can give us potentially critical information about the code behind programming languages and frameworks used by the organization.

Ex. Github Serach:
`filename:users`

There are tools that can automate this type of search and find secrets:
recon-ng
Gitleaks
Gitrob
etc.

They generally rely on regex or entropy (looking for long, random strings).