Gethering info on users allows the possibility of:
- compiling user/pw list
- pretext for social engineering
- augmented phishing
- client-side attacks
- credential stuffing
- and more..


## Email Harvesting 
*theHarvester* is a tool we can use to gather basic email info as well as names, subdomains, IPs and URLs from public data sources. 

`theharvester -d megacorpone.com -b google` 
**-d** specifies target domain
**-b** set data source

## Credential Dumps
Pastebin (and other sites) are often used for cred bumps, like rockyou.txt.

