Netcraft is an Internet Services Company that offers a free web portal that performs various information gathering functions.

Ex.
*https://searchdns.netcraft.com*
Search for `site contains: *.megacorpone.com`

This will provide us with "site reports" for each server, including registration info and even Site Technology, aka **Software** running on the servers... and crucial finding. 
