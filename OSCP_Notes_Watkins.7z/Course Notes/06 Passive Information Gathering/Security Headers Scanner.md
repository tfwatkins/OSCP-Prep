https://securityheaders.com/

Analyzes HTTP response headers and provides basic analysis of the targets security posture. 

Common mistakes in *server hardening* include not: disabling unneded services, removing unused services and accounts, rotating default PWs, setting appropriate server headers, etc.