Website for storing and sharing text.

You can use the website for basic searches or the API for advanced searching.