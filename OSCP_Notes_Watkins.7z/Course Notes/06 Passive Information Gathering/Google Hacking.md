Book:
"Google Hacking for Penetration Testers" - Johnny Long

`site:megacorpone.com` Limits searches to a single domain
`site:megacorpone.com filetype:php` Specify a filetype
`ext:jsp` Attempt to determing the programming language: Java Server Pages
`site:megacorpone.com -filetype:php` use **-** to exclude results
`intitle:"index of" "parent directory"` Serach page titles for strings


Google Hacking Database (GHDB) contains more information:
https://www.exploit-db.com/google-hacking-database

