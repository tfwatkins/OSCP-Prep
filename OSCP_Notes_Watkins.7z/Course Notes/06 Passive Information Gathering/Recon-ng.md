Module-based framework for web-based info gathering. 

Displays results but also stores in a database.

`recon-ng` Starts the program
`marketplace search github` Serach the "Marketplace" for modules related to github
***
Modules with an *\** in the "K" column require creds for API keys. The recon-ng wiki keeps a short list of keys used by its modules, somre free some paid. 
***

`marketplace info recon/domains-hosts/google_site_web`  Get more info on a module

`marketplace install recon/domains-hosts/google_site_web ` Install the module

`marketplace load recon/domains-hosts/google_site_web` Load the module

`info` Get info and parameters for the module

`options set SOURCE megacorpone.com` Set parameters

`run` start the module

`back` exit the module

`show` Shows various framework items

`show hosts` show the item

*** 
If when setting up module parameters there is a *default*  value listed under current value, it will iterate through your database filling in the parameter with info you've already gathered. Just **run** it.
***