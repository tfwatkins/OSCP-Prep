Good for looking at the type of questions a specific user is asking. Can derive software/programming language information, or spot a misconfiguration/vulnerability. 



