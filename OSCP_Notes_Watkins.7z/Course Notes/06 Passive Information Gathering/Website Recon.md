Start with the main page:
https://www.megacorpone.com/

Dig down to get more info:
https://www.megacorpone.com/about.html

I'mportant info would be things like email addresses, username schemes.

Look for links to social media.