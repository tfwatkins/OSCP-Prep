TCP Service, tool, and type of database that can provide domain name info like the *name server* and *registrar*.
***
This information is usually public since private registration requires a fee.
***

## forward search
`whois megacorpone.com` Standard forward search returning: Domain name, Registry Domain ID, Registrar WHOIS Server, Registrar URL, creation, expiry, and other Registratnt Info, and very importantly, the **Name Servers**.

## reverse lookup
`whois 38.100.192.70` Returns netrange, CIDR, NetName, OrgName, Address, City, Etc.