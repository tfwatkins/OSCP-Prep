Both *recon-ng* and *theHarvester* can be used against Social Media, as well as:

## Social Searcher
Search engine for Social Media sites. This can be an alternative to setting up API keys on multiple more specialized services.

## Site-Specific Tools
*Twofi*- Scans user's Twitter feed and generates a personalized wordlist used for password attacks against the user. Requires a Twitter API key.

*linkedin2username*- Script for generating username list based on LinkedIn data. Required valid LinkedIn creds and depends in LinkedIn connection to individuals targeted. 