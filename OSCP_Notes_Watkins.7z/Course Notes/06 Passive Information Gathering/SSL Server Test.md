https://www.ssllabs.com/ssltest/

Analyzes a server's SSL/TLS config and compares against current best practices. Also can identify some SSL/TLS vulns such as *Poddle* or *Heartbleed*.

