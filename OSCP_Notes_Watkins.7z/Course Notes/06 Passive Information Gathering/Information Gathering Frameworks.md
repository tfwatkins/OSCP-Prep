## OSINT Framework
https://osintframework.com/
Includes recon tools and websites in one central location. 

## Maltego
Very powerful data mining tool. Performs "transforms" to derive one piece of information from another. Has a community version (included with Kali) and commercial versions for larger datasets. 

