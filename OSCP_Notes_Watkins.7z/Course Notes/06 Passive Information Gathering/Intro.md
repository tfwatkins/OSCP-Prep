AKA OSINT

Two different approaches to "Passive":
1. We NEVER interact with our target
2. We interact only in the context of a normal user (Offsec's preference)

Completely depends on the mission, scope, ROE, etc.