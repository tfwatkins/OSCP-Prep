We will demonstrate how to exploit a vuln in the SyncBreeze application. 

We will first focus on discovering the vuln and expliting it for remote buffer overflow. 

Step one is to discover the vuln, then we have to create input to gain control of the critical CPU registers, then we have to manipulate memory to gain reliable remote code execution. 