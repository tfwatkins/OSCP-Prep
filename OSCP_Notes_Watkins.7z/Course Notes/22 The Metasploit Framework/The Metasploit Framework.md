Most frameworks offer dynamic payload capabilities, meaning for each exploit you can choose various payloads to deploy.

Frameworks:
- Metasploit
- Core Impact
- Immunity Canvas
- Cobalt Strike
- Powershell Empire

