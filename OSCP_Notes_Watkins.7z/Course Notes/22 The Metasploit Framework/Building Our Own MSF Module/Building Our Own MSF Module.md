Ex.
Port the SyncBreeze Python exploit to Ruby (Metasploit format)

Creating template for the exploit:
`sudo mkdir -p /root/.msf4/modules/exploits/windows/http`

`sudo cp /usr/share/metasploitframework/
modules/exploits/windows/http/disk_pulse_enterprise_get.rb
/root/.msf4/modules/exploits/windows/http/syncbreeze.rb`

`sudo nano/root/.msf4/modules/exploits/windows/http/syncbreeze.rb`

Reference pages 707-709 for details on conversion.

