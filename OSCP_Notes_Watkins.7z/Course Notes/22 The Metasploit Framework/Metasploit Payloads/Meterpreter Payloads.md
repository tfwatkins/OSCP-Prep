Meterpreter is a multi-function payload. A shell provides many more features than a regular command shell like file transfer, keyloggin and others.

Very useful in post-exploitation phase. 

Search meterpreter payloads:
`search meterpreter type:payload`

You choose, set and execute meterpreter payloads like any other. 
