Example:
- windows/shell_reverse_tcp - Connect back to attacker and spawn a command shell
- windows/shell/reverse_tcp - Connect back to attacker, Spawn cmd shell (staged)

Suble but important difference.

A non-staged payload is sent entirely along wtih exploit.

A staged payload is sent in two parts:
- First part contains a small primary payload that causes victim machine to connect back to attacker and transfer a larger secondary paylod that contains the rest of th shellcode, which is then executed

Reasons to use a staged payload:
- Vuln we are exploiting does not have enough buffer space to hold a full payload
- AV softare will often detect embedded shellcode

Note that in Metasploit the "/" char is used to denote wheether a payload is staged. Ex:
- shell_reverse_tcp is not staged
- shell/reverse_tcp is staged

