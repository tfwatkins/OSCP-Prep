View executable formats:
`msfvenom -l formats`

MSF contains many browser exploits, like flash for example:
`search flash`