posgresql service that metasploit depends on is neither active or enabled on boot. Start and enable it:
`sudo systemctl start postgresql`
`sudo systemctl enable postgresql`

Create and initialize the MSF database:
`sudo msfdb init`

Update:
`sudo apt update; sudo apt install metasploit-framework`

Launch, hiding banner art and version output:
`sudo msfconsole -q`