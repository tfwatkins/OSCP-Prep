If postgresql service is running, Metasploit will log findings and info discovered from hosts, services or creds in a convenient accessible DB. 

View ALL results of tcp port scan:
`services`

Results can be filtered with things like port number **-p** or service name **-s**.

Execute nmap inside metaslpot to save findings to DB:
`db_nmap`

Display all discovered hosts:
`hosts`

List all services running on port 445:
`services -p 445`

Metasploit allows us to store info in workspaces, allowing us to manage DB info.

List workspaces:
`workspace`

Change to different workspace
`workspace <workspace_name>`

add/delete workspace:
`workspace -a <workspace_name>`
`workspace -d <workspace_name>`


