Help flag for 'show' command:
`show -h`

Activating and exiting a module:
`use auxiliary/scanner/portscan/tcp`
`back` or `previous`

Options for module:
`show options`

Set/unset options:
`set <option> <parameter>`
`unset <option>`

set/unset global options:
`setg`
`unsetg`

Running a module:
`run`
or
`exploit`



