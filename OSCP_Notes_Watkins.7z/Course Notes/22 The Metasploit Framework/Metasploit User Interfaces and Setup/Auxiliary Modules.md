The modules all follow a common slash-delimited hierarchical syntax:
module type/os, vendor, app, or protocol/module name

Useful module heirarchys:
- gather/
- scanner/
- etc

To list all auxiliary modules:
`show auxiliary`

Use search to filter for smb aux modules:
`search type:auxiliary name:smb`

Use a module and get more info:
msf5 >
`use scaner/smb/smb2`
msf5 auxiliary(scanner/smb/smb2) >
`info`

**options** will let you know which options are required and which are optional to be set

***
One parameter that we often change for auxiliary modules is THREADS. This parameter tells the framework how many threads to initiate when running the module, increasing the concurrency, and the speed. We don’t want to go too crazy with this number, but a slight increase will dramatically decrease the run time.
***

Example of credential retrieval using an SMB login module:
`creds`
