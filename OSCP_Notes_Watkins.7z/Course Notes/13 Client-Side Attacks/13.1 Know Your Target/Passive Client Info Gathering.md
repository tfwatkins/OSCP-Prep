Passive = no direct interaction. 

Ex. Searching web for companies external corporate IPs. Finding out user-agent data from a site that host affiliate data.

Other info may be found on social media, forums, etc. 

