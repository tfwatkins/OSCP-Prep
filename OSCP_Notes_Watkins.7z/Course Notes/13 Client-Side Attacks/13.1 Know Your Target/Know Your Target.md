Clien-side attacks exploit weaknesses in client software such as browser, instead of exploiting server software. 

They do not require direct or routable access to the victim's machine.

Ex. Phishing email with a macro sent to an employee inside a non-routable internal network. 


Primary difficulty is enumerating victim's client software. Not as easy as enumerating a WWW or FTP server. 

