Active = Making direct contact with target machine or users. 

Ex. Phone call, or targeted email. 

### Social Engineering and Client-side attacks

Ex. Send malformed resume to HR that won't open. They email us back. We (hopefully by phone) attempt to resolve the issue by getting MS office version, security features, OS, etc. 
***
This process is known as pretexting
***
Now that we have version information and have hopefully convinced them to allow macros, we send a new resume armed with powershell macros to open a reverse shell. 

### Client Fingerprinting

Fingerprinting = gathering info on target machine itself.

This is either a standalone step or is incorporated into the first stage of the exploit itsefl. 

Ex. We have convinced victim to visit malicious web page. Goal is to identify web browser and os information.

There  are many open-source fingerpringint projects relying on common client-side components such as javascript. 

Ex. *fingerprintjs2*
```
kali@kali:/var/www/html$ sudo wget
https://github.com/Valve/fingerprintjs2/archive/master.zip
--2019-07-24 02:42:36-- https://github.com/Valve/fingerprintjs2/archive/master.zip
...
2019-07-24 02:42:41 (116 KB/s) - ‘master.zip’ saved [99698]
kali@kali:/var/www/html$ sudo unzip master.zip
Archive: master.zip
eb44f8f6f5a8c4c0ae476d4c60d8ed1015b2b605
creating: fingerprintjs2-master/
inflating: fingerprintjs2-master/.eslintrc
...
kali@kali:/var/www/html$ sudo mv fingerprintjs2-master/ fp
```

We can incorporate this library into an HTML file. we can include the .js library from within the index.html file located in /var/www/html/fp directory of kali web server. 

```
kali@kali:/var/www/html/fp$ cat index.html
<!doctype html>
<html>
<head>
<title>Fingerprintjs2 test</title>
</head>
<body>
<h1>Fingerprintjs2</h1>
<p>Your browser fingerprint: <strong id="fp"></strong></p>
<p><code id="time"/></p>
<p><span id="details"/></p>
<script src="fingerprint2.js"></script>
<script>
var d1 = new Date();
var options = {};
Fingerprint2.get(options, function (components) {
var values = components.map(function (component) { return component.value })
var murmur = Fingerprint2.x64hash128(values.join(''), 31)
var d2 = new Date();
var timeString = "Time to calculate the fingerprint: " + (d2 - d1) + "ms";
var details = "<strong>Detailed information: </strong><br />";
if(typeof window.console !== "undefined") {
for (var index in components) {
var obj = components[index];
var value = obj.value;
if (value !== null) {
var line = obj.key + " = " + value.toString().substr(0, 150);
details += line + "<br />";
}
}
}
document.querySelector("#details").innerHTML = details
document.querySelector("#fp").textContent = murmur
document.querySelector("#time").textContent = timeString
});
</script>
</body>
</html>
```

Using the information returned we can query the User-Agent and get an idea of the OS. 

This script displays data to the victim, not us. we need a way to transfer extracted data to our attacking web server. 

Some Ajax code should do the trick. 
We can use the *XMLHttpRequest* JavaScript API to interact with the attacking web sever via a POST issued against the same server where the malicious web page is stored. 

`sudo chown www-data:www-data fp` Used to allow the Apache www-data user to write to the fp directory. 

After making modifications and getting the victim to browse to the webpage, the **fingerprint.txt** file on our attack server contains victim information. The XMLHttpRequest silently transferred data to our attack server with no interaction from the victim. 