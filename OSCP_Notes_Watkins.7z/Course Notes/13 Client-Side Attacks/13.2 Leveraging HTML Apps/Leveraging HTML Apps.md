If a file is created with the extension of **.hta** instead of **.html**, internet explorer will automatically interpret it as an HTML app and offer the ability to execute it using the **.mshta.exe** program.

The purpose of HTML apps is to allow the exeuction of apps directly from the browser, rather than downlaoding and running. 

This means that HTML apps are ALWAYS executed outisde of the security context of the browser by the self signed binary **.mshta.exe**. If the user allows this to happen, RCE with user's permissions can occur, avoiding restriction normally imposed by internet expolorer. 

***
Note that this attack vector ONLY works against IE, and to an extent MS Edge. This is an attack feature directly built into Windows OS and is compatibly with less ecure MS legacy web projects such as ActiveX.
***

